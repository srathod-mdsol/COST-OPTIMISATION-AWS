# SQL Server to PostgreSQL Migration Blueprint
## Enterprise Database Migration from On-Premises to AWS RDS
### Complete Architecture and Execution Plan for Mods (120GB) and Modsdw (40GB) Databases

---

## Table of Contents

1. [Executive Overview](#1-executive-overview)
2. [Complete Architecture Design](#2-complete-architecture-design)
3. [Lucidchart-Style Flow Diagram](#3-lucidchart-style-flow-diagram)
4. [Deep Pre-Migration Assessment](#4-deep-pre-migration-assessment-object-level)
5. [Schema Conversion & Object Migration Strategy](#5-schema-conversion--object-migration-strategy)
6. [Implementation Phase](#6-implementation-phase-console-level-detailed-steps)
7. [Data Validation & Complete Verification Strategy](#7-data-validation--complete-verification-strategy)
8. [Monitoring & Handling Errors](#8-monitoring--handling-errors)
9. [Cutover Strategy with Full Verification](#9-cutover-strategy-with-full-verification)
10. [Performance Optimization & Cost Planning](#10-performance-optimization--cost-planning)
11. [Final Go-Live Checklist](#11-final-go-live-checklist)

---

## 1. Executive Overview

### 1.1 Overall Migration Strategy

This migration blueprint establishes a comprehensive, production-ready strategy for migrating two on-premises SQL Server databases to Amazon RDS PostgreSQL:

| Database | Size | Type | Migration Approach |
|----------|------|------|-------------------|
| **Mods** | 120GB | OLTP | Full Load + CDC |
| **Modsdw** | 40GB | Data Warehouse | Full Load + CDC |

The total workload of **160GB** with heavy object dependencies requires a methodical, phased approach that prioritizes:

- **Schema-first migration**: Converting and validating all database objects before data movement
- **Zero-data-loss**: Ensuring complete referential integrity and data accuracy
- **Minimal downtime**: Using CDC (Change Data Capture) to enable continuous replication
- **Full traceability**: Maintaining audit-level validation throughout the process

### 1.2 Why Full Load + CDC Ensures Minimal Downtime

The Full Load + CDC (Change Data Capture) methodology is the industry standard for enterprise database migrations because it operates in two distinct phases:

**Phase 1: Full Load (Initial Bulk Migration)**
- DMS reads the entire source database and bulk-inserts into the target
- Runs in parallel using multiple threads for performance
- Tables are loaded independently without maintaining transaction consistency across tables
- Typical duration: 1-4 hours depending on data volume and network bandwidth

**Phase 2: CDC (Continuous Replication)**
- Captures ongoing changes from SQL Server transaction logs
- Applies changes to PostgreSQL in near real-time
- Maintains synchronization during and after full load
- When CDC lag reaches zero, the databases are transactionally consistent

**Downtime Window:**
- Application freeze only required during final cutover (typically 5-30 minutes)
- All historical data loaded via Full Load
- All changes during migration captured via CDC
- Final catch-up takes seconds to minutes

### 1.3 Why Schema-First Migration is Mandatory

For object-heavy databases like Mods (120GB) and Modsdw (40GB) with extensive dependencies, schema-first migration is not optional—it is mandatory for success:

1. **Dependency Resolution**: SQL Server objects have complex interdependencies (stored procedures calling functions, triggers on tables, views referencing views). PostgreSQL may require different resolution orders.

2. **Conversion Validation**: Many SQL Server features require manual conversion or cannot be auto-converted. Identifying these early prevents data migration failures.

3. **Application Compatibility**: Schema changes may require application code modifications. Early detection allows adequate testing time.

4. **Performance Tuning**: PostgreSQL index structures and query plans differ from SQL Server. Schema validation enables performance optimization before data loads.

5. **Rollback Planning**: If schema conversion fails, you need time to develop workarounds without rushing the cutover decision.

---

## 2. Complete Architecture Design

### 2.1 On-Premises SQL Server Environment

```
┌─────────────────────────────────────────────────────────────┐
│                    ON-PREMISES DATA CENTER                   │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │              SQL Server Instance                     │    │
│  │                                                      │    │
│  │   ┌──────────────┐        ┌──────────────┐          │    │
│  │   │    Mods      │        │   Modsdw     │          │    │
│  │   │  (120GB)     │        │   (40GB)     │          │    │
│  │   │              │        │              │          │    │
│  │   │ • 450 Tables │        │ • 120 Tables │          │    │
│  │   │ • 2,100 Idx  │        │ • 450 Idx    │          │    │
│  │   │ • 80 Views  │        │ • 35 Views   │          │    │
│  │   │ • 150 Procs │        │ • 45 Procs   │          │    │
│  │   │ • 30 Funcs  │        │ • 15 Funcs   │          │    │
│  │   │ • 25 Trigs  │        │ • 8 Trigs    │          │    │
│  │   └──────────────┘        └──────────────┘          │    │
│  │                                                      │    │
│  │   SQL Server Version: 2016/2019 Enterprise          │    │
│  │   Recovery Model: FULL                               │    │
│  │   CDC Enabled: YES                                   │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │         AWS SCT Workstation (EC2)                   │    │
│  │   • Assessment Report Generation                     │    │
│  │   • Schema Conversion                                │    │
│  │   • Conversion Scripts Export                        │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Network Connectivity Options

**Option A: Site-to-Site VPN (Recommended for Proof of Concept)**

```
On-Premises Firewall                    AWS VPC
┌─────────────────────┐               ┌─────────────────────┐
│  Public IP: x.x.x.x │◄─────────────►│  Virtual Private    │
│  UDP Port 500       │   IPSec VPN   │  Gateway (VPG)     │
│  UDP Port 4500      │               └─────────────────────┘
└─────────────────────┘                        │
                                              │ Private Subnet
                                              ▼
                                      ┌─────────────────────┐
                                      │  Transit Gateway   │
                                      │  (if using Direct   │
                                      │   Connect)          │
                                      └─────────────────────┘
```

**Option B: AWS Direct Connect (Recommended for Production)**

```
On-Premises                  AWS Direct Connect              AWS VPC
Data Center                  Location                       
┌─────────────┐            ┌─────────────┐              ┌─────────────────┐
│   Router    │───────────►│  Direct     │─────────────►│  Virtual        │
│  (1Gbps+)   │  Dedicated │  Connect    │   Private    │  Private        │
│             │  1G/10G    │  Location   │   VIF        │  Gateway        │
└─────────────┘            └─────────────┘              └─────────────────┘
                                                                  │
                                                                  ▼
                                                         ┌─────────────────┐
                                                         │  Private Subnet │
                                                         │  10.0.1.0/24    │
                                                         └─────────────────┘
```

**Network Requirements:**
- Minimum bandwidth: 100Mbps for 160GB migration
- Recommended: 500Mbps+ for production workloads
- Latency: < 50ms for optimal CDC performance
- Ports required: 443 (HTTPS), 3306 (MySQL compatible for DMS)

### 2.3 AWS VPC Design

```
┌──────────────────────────────────────────────────────────────────────────┐
│                              AWS VPC (10.0.0.0/16)                       │
│                                                                          
│  ┌────────────────────────────────────────────────────────────────────┐   │
│  │                      Public Subnet (Public Access)                 │   │
│  │  10.0.0.0/24 (AZ-a)              10.0.1.0/24 (AZ-b)                │   │
│  │                                                                       │   │
│  │  • NAT Gateway (HA)          • NAT Gateway (HA)                    │   │
│  │  • Application Load Balancer                                      │   │
│  │  • Bastion Host (if needed)                                        │   │
│  └────────────────────────────────────────────────────────────────────┘   │
│                                    │                                      │
│                                    │                                      │
│  ┌────────────────────────────────────────────────────────────────────┐   │
│  │                    Private Subnets (Database Tier)                │   │
│  │  10.0.10.0/24 (AZ-a)              10.0.11.0/24 (AZ-b)              │   │
│  │                                                                       │   │
│  │  ┌─────────────────────┐         ┌─────────────────────┐            │   │
│  │  │ RDS PostgreSQL     │         │ RDS PostgreSQL     │            │   │
│  │  │ • db.r6g.4xlarge   │         │ • db.r6g.4xlarge   │            │   │
│  │  │ • 2TB gp3 storage  │         │ • Multi-AZ         │            │   │
│  │  │ • Mods Database    │         │ • Modsdw Database  │            │   │
│  │  └─────────────────────┘         └─────────────────────┘            │   │
│  │                                                                       │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐ │   │
│  │  │              DMS Replication Instance                          │ │   │
│  │  │  • dms.r6g.4xlarge                                            │ │   │
│  │  │  • 32 vCPU, 128GB RAM                                         │ │   │
│  │  │  • 50GB storage                                               │ │   │
│  │  └─────────────────────────────────────────────────────────────────┘ │   │
│  └────────────────────────────────────────────────────────────────────┘   │
│                                                                          
│  ┌────────────────────────────────────────────────────────────────────┐   │
│  │                    Management Subnet                               │   │
│  │  10.0.100.0/24 (AZ-a)           10.0.101.0/24 (AZ-b)             │   │
│  │                                                                       │   │
│  │  • CloudWatch Logs                                               │   │
│  │  • Systems Manager                                              │   │
│  │  • AWS Config                                                   │   │
│  └────────────────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────────────┘
```

### 2.4 Security Groups Configuration

**RDS PostgreSQL Security Group (sg-postgres)**

| Direction | Protocol | Port | Source/Destination | Purpose |
|-----------|----------|------|-------------------|---------|
| Inbound | TCP | 5432 | DMS Security Group | DMS connectivity |
| Inbound | TCP | 5432 | Application SG | Application access |
| Inbound | TCP | 5432 | Bastion/SCT SG | Administrative access |
| Outbound | ALL | ALL | 0.0.0.0/0 | Default |

**DMS Replication Instance Security Group (sg-dms)**

| Direction | Protocol | Port | Source/Destination | Purpose |
|-----------|----------|------|-------------------|---------|
| Inbound | TCP | 3306 | On-Premises VPN | Source SQL Server |
| Inbound | TCP | 443 | AWS DMS Service | DMS API calls |
| Inbound | TCP | 5432 | RDS PostgreSQL SG | Target connectivity |
| Outbound | ALL | ALL | 0.0.0.0/0 | Default |

**Application Security Group (sg-application)**

| Direction | Protocol | Port | Source/Destination | Purpose |
|-----------|----------|------|-------------------|---------|
| Inbound | TCP | 443 | ALB Security Group | HTTPS traffic |
| Outbound | TCP | 5432 | RDS PostgreSQL SG | Database access |

### 2.5 IAM Roles and Permissions

**DMS Service Role (dms-service-role)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "dms.amazonaws.com"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "aws:SourceAccount": "123456789012"
        },
        "ArnEquals": {
          "aws:SourceArn": "arn:aws:dms:us-east-1:123456789012:*"
        }
      }
    }
  ]
}
```

**Required IAM Policies:**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DMSCloudWatchLogs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:DescribeLogGroups",
        "logs:CreateLogStream",
        "logs:DescribeLogStreams",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    },
    {
      "Sid": "DMSS3Access",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::dms-*/ *"
    },
    {
      "Sid": "DMSVPCAccess",
      "Effect": "Allow",
      "Action": [
        "ec2:DescribeVpcAttribute",
        "ec2:DescribeSubnets",
        "ec2:DescribeSecurityGroups",
        "ec2:DescribeNetworkInterfaces"
      ],
      "Resource": "*"
    }
  ]
}
```

### 2.6 RDS PostgreSQL Configuration

**Database Instance: Mods**

| Parameter | Value | Notes |
|-----------|-------|-------|
| Instance Class | db.r6g.4xlarge | 16 vCPU, 128GB RAM |
| Storage | 500GB gp3 | 3000 IOPS, 125MB/s throughput |
| Multi-AZ | Yes | Automatic failover |
| Engine Version | PostgreSQL 15.4 | Latest stable |
| DB Name | mods | |
| Master Username | dbadmin | |
| Port | 5432 | Default |
| Parameter Group | custom.postgres15.mod | |
| Option Group | default:postgres-15 | |
| Backup Retention | 30 days | Point-in-time recovery |
| Encryption | Enabled (KMS) | AES-256 |

**Database Instance: Modsdw**

| Parameter | Value | Notes |
|-----------|-------|-------|
| Instance Class | db.r6g.2xlarge | 8 vCPU, 64GB RAM |
| Storage | 200GB gp3 | 3000 IOPS, 125MB/s throughput |
| Multi-AZ | Yes | Automatic failover |
| Engine Version | PostgreSQL 15.4 | |
| DB Name | modsdw | |
| Storage Encryption | Enabled (KMS) | |

### 2.7 DMS Replication Instance Configuration

| Parameter | Value | Justification |
|-----------|-------|---------------|
| Instance Class | dms.r6g.4xlarge | 16 vCPU, 128GB RAM |
| Storage | 50GB | Sufficient for 160GB workload |
| Multi-AZ | Yes | High availability |
| Engine Version | 3.5.1 | Latest stable |
| Network Type | IPV4 | |
| VPC | migration-vpc | Same as RDS |
| Replication Subnet Group | dms-subnet-group | Private subnets |
| Security Group | sg-dms | |

**Sizing Rationale for 160GB Object-Heavy Workload:**
- r6g.4xlarge provides 16 cores for parallel processing
- 128GB RAM handles large transaction caches
- Supports up to 100 concurrent tasks
- Can handle 40,000+ rows/second for full load

### 2.8 DMS Endpoints Configuration

**Source Endpoint (SQL Server - Mods)**

```json
{
  "EndpointIdentifier": "source-mods",
  "EndpointType": "source",
  "EngineName": "sqlserver",
  "ServerName": "10.0.254.10",
  "Port": 1433,
  "DatabaseName": "mods",
  "Username": "dms_user",
  "Password": "********",
  "ExtraConnectionAttributes": "capture_identity=true;security_database=master",
  "MicrosoftSQLServerSettings": {
    "Port": 1433,
    "ServerName": "10.0.254.10",
    "DatabaseName": "mods"
  }
}
```

**Source Endpoint (SQL Server - Modsdw)**

```json
{
  "EndpointIdentifier": "source-modsdw",
  "EndpointType": "source",
  "EngineName": "sqlserver",
  "ServerName": "10.0.254.10",
  "Port": 1433,
  "DatabaseName": "modsdw",
  "Username": "dms_user",
  "Password": "********"
}
```

**Target Endpoint (PostgreSQL - Mods)**

```json
{
  "EndpointIdentifier": "target-mods",
  "EndpointType": "target",
  "EngineName": "postgres",
  "ServerName": "postgres-mods.xxxx.us-east-1.rds.amazonaws.com",
  "Port": 5432,
  "DatabaseName": "mods",
  "Username": "dbadmin",
  "Password": "********",
  "ExtraConnectionAttributes": "dbschema=public"
}
```

### 2.9 CloudWatch Monitoring Configuration

**CloudWatch Dashboards:**

1. **DMS Migration Dashboard**
   - CDC Latency (source and target)
   - Full Load Progress (tables completed, rows loaded)
   - CDC Changes Pending
   - Task State (running, stopped, error)
   - CPU and Memory Utilization

2. **RDS PostgreSQL Dashboard**
   - Read/Write IOPS
   - Database Connections
   - CPU Utilization
   - Memory Utilization
   - Storage Usage
   - Replication Lag (for Multi-AZ)

**CloudWatch Alarms:**

| Alarm Name | Metric | Threshold | Action |
|------------|--------|-----------|--------|
| DMS-High-Latency | CDCQueueDuration | > 300 seconds | SNS Alert |
| DMS-Task-Error | TaskErrorCount | > 0 | SNS Alert |
| RDS-IOPS-High | ReadIOPS | > 5000 | SNS Alert |
| RDS-Connections-High | DatabaseConnections | > 80% max | SNS Alert |
| RDS-Storage-Low | FreeStorageSpace | < 50GB | SNS Alert |

---

## 3. Lucidchart-Style Flow Diagram

### 3.1 Complete Migration Architecture

```
┌──────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    ON-PREMISES DATA CENTER                                     │
│  ┌────────────────────────────────────────────────────────────────────────────────────────┐   │
│  │                           SQL Server Production Instance                               │   │
│  │  ┌──────────────────────────────────────────────────────────────────────────────────┐  │   │
│  │  │                                                                                  │  │   │
│  │  │    ┌─────────┐         ┌─────────┐         ┌─────────┐         ┌─────────┐      │  │   │
│  │  │    │  Mods   │         │Modsdw   │         │  Temp   │         │  Log    │      │  │   │
│  │  │    │ (120GB) │         │ (40GB)  │         │  DB     │         │ Backup  │      │  │   │
│  │  │    │         │         │         │         │         │         │         │      │  │   │
│  │  │    │ Tables  │         │ Tables  │         │ For     │         │ For     │      │  │   │
│  │  │    │ Indexes │         │ Indexes │         │ Testing │         │ Rollback│      │  │   │
│  │  │    │ Views   │         │ Views   │         │         │         │         │      │  │   │
│  │  │    │ Procs   │         │ Procs   │         │         │         │         │      │  │   │
│  │  │    │ Funcs   │         │ Funcs   │         │         │         │         │      │  │   │
│  │  │    │ Trigs   │         │ Trigs   │         │         │         │         │      │  │   │
│  │  │    └─────────┘         └─────────┘         └─────────┘         └─────────┘      │  │   │
│  │  │                                                                                  │  │   │
│  │  │                                    SQL Server Transaction Log                   │  │   │
│  │  │                              (CDC captures changes from here)                    │  │   │
│  │  └──────────────────────────────────────────────────────────────────────────────────┘  │   │
│  │                                                                                           │   │
│  │  ┌───────────────────────────────────────────────────────────────────────────────────┐   │   │
│  │  │                           AWS SCT Workstation (EC2 t3.xlarge)                     │   │   │
│  │  │                                                                                   │   │   │
│  │  │    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────────────┐   │   │   │
│  │  │    │  Assessment    │    │   Schema        │    │   Conversion             │   │   │   │
│  │  │    │  Report        │───►│   Conversion    │───►│   Scripts Export         │   │   │   │
│  │  │    │  (HTML/PDF)    │    │   (SCT)         │    │   (.sql files)           │   │   │   │
│  │  │    └─────────────────┘    └─────────────────┘    └─────────────────────────┘   │   │   │
│  │  │                                                                                   │   │   │
│  │  │    • Scans SQL Server metadata                                                   │   │   │
│  │  │    • Identifies unsupported features                                             │   │   │
│  │  │    • Generates action items                                                     │   │   │
│  │  └───────────────────────────────────────────────────────────────────────────────────┘   │   │
│  └────────────────────────────────────────────────────────────────────────────────────────┘   │
│                                              │                                                  │
│                                              │ VPN/Direct Connect                              │
│                                              │ 100-500Mbps                                     │
│                                              │ <50ms latency                                   │
└──────────────────────────────────────────────│──────────────────────────────────────────────────┘
                                               │
                                               ▼
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    AWS CLOUD                                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────────────────┐    │
│  │                                    AWS VPC (10.0.0.0/16)                                 │    │
│  │                                                                                          │    │
│  │    ┌─────────────────────────────────────────────────────────────────────────────────┐    │    │
│  │    │                          PUBLIC SUBNET (10.0.0.0/24)                          │    │    │
│  │    │                                                                                 │    │    │
│  │    │    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │    │    │
│  │    │    │   NAT GW    │    │   NAT GW    │    │     ALB     │    │   Bastion   │    │    │    │
│  │    │    │  (AZ-a)     │    │  (AZ-b)     │    │             │    │   Host      │    │    │    │
│  │    │    └─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘    │    │    │
│  │    └─────────────────────────────────────────────────────────────────────────────────┘    │    │
│  │                                              │                                              │    │
│  │    ┌─────────────────────────────────────────────────────────────────────────────────┐    │    │
│  │    │                          PRIVATE SUBNET (10.0.10.0/24 - AZ-a)                   │    │    │
│  │    │                          PRIVATE SUBNET (10.0.11.0/24 - AZ-b)                   │    │    │
│  │    │                                                                                 │    │    │
│  │    │    ┌─────────────────────────────────────────────────────────────────────────┐  │    │    │
│  │    │    │                    DMS REPLICATION INSTANCE                           │  │    │    │
│  │    │    │                    dms.r6g.4xlarge                                     │  │    │    │
│  │    │    │                                                                         │  │    │    │
│  │    │    │   ┌─────────────────────────────────────────────────────────────────┐  │  │    │    │
│  │    │    │   │                    MIGRATION TASKS                               │  │  │    │    │
│  │    │    │   │                                                                  │  │  │    │    │
│  │    │    │   │   ┌────────────────────┐      ┌────────────────────┐               │  │  │    │    │
│  │    │    │   │   │  mods-full-load   │      │ mods-cdc-capture  │               │  │  │    │    │
│  │    │    │   │   │                    │      │                    │               │  │  │    │    │
│  │    │    │   │   │  • 450 tables      │      │  • CDC from        │               │  │  │    │    │
│  │    │    │   │   │  • Parallel load  │      │    transaction log │               │  │  │    │    │
│  │    │    │   │   │  • 32 threads     │      │  • Ongoing changes │               │  │  │    │    │
│  │    │    │   │   └────────────────────┘      └────────────────────┘               │  │  │    │    │
│  │    │    │   │                                                                  │  │  │    │    │
│  │    │    │   │   ┌────────────────────┐      ┌────────────────────┐               │  │  │    │    │
│  │    │    │   │   │modsdw-full-load   │      │modsdw-cdc-capture  │               │  │  │    │    │
│  │    │    │   │   │                    │      │                    │               │  │  │    │    │
│  │    │    │   │   │  • 120 tables     │      │  • CDC from        │               │  │  │    │    │
│  │    │    │   │   │  • Parallel load  │      │    transaction log │               │  │  │    │    │
│  │    │    │   │   │  • 16 threads     │      │  • Ongoing changes │               │  │  │    │    │
│  │    │    │   │   └────────────────────┘      └────────────────────┘               │  │  │    │    │
│  │    │    │   └─────────────────────────────────────────────────────────────────┘  │  │    │    │
│  │    │    │                                                                         │  │    │    │
│  │    │    │   ┌─────────────────────────────────────────────────────────────────┐  │  │    │    │
│  │    │    │   │              ENDPOINTS CONFIGURATION                           │  │  │    │    │
│  │    │    │   │                                                                  │  │  │    │    │
│  │    │    │   │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │  │  │    │    │
│  │    │    │   │  │ source-mods  │  │source-modsdw │  │ target-mods  │          │  │  │    │    │
│  │    │    │   │  │ (SQL Server) │  │(SQL Server)  │  │(PostgreSQL)  │          │  │  │    │    │
│  │    │    │   │  └──────────────┘  └──────────────┘  └──────────────┘          │  │  │    │    │
│  │    │    │   │                                                                  │  │  │    │    │
│  │    │    │   │  ┌──────────────┐  ┌──────────────┐                            │  │  │    │    │
│  │    │    │   │  │target-modsdw │  │              │                            │  │  │    │    │
│  │    │    │   │  │(PostgreSQL)  │  │              │                            │  │  │    │    │
│  │    │    │   │  └──────────────┘  └──────────────┘                            │  │  │    │    │
│  │    │    │   └─────────────────────────────────────────────────────────────────┘  │  │    │    │
│  │    │    └───────────────────────────────────────────────────────────────────────────┘  │    │
│  │    │                                              │                                              │    │
│  │    │    ══════════════════════════════════════════╪══════════════════════════════════════       │    │
│  │    │                                              │                                              │    │
│  │    │    ┌─────────────────────────────────────────────────────────────────────────────────┐  │    │
│  │    │    │                        RDS POSTGRESQL INSTANCES                              │  │    │
│  │    │    │                                                                                 │  │    │
│  │    │    │    ┌─────────────────────────────────────┐   ┌─────────────────────────────────┐│  │    │
│  │    │    │    │         PRIMARY (AZ-a)              │   │       REPLICA (AZ-b)           ││  │    │
│  │    │    │    │                                     │   │                                 ││  │    │
│  │    │    │    │  ┌─────────────────────────────┐   │   │  ┌─────────────────────────────┐││  │    │
│  │    │    │    │  │    Database: mods           │   │   │  │    Database: mods           │││  │    │
│  │    │    │    │  │    (120GB migrated data)     │   │   │  │    (Standby - Sync)        │││  │    │
│  │    │    │    │  │                             │   │   │  │                             │││  │    │
│  │    │    │    │  │  • 450 Tables               │   │   │  └─────────────────────────────┘││  │    │
│  │    │    │    │  │  • 2,100 Indexes            │   │   │                                 ││  │    │
│  │    │    │    │  │  • 80 Views                │   │   │                                 ││  │    │
│  │    │    │    │  │  • 150 Stored Procs        │   │   │                                 ││  │    │
│  │    │    │    │  │  • 30 Functions            │   │   │                                 ││  │    │
│  │    │    │    │  │  • 25 Triggers             │   │   │                                 ││  │    │
│  │    │    │    │  │  • Sequences               │   │   │                                 ││  │    │
│  │    │    │    │  └─────────────────────────────┘   │   │                                 ││  │    │
│  │    │    │    └─────────────────────────────────────┘   └─────────────────────────────────┘│  │    │
│  │    │    │                                                                                 │  │    │
│  │    │    │    ┌─────────────────────────────────────┐   ┌─────────────────────────────────┐│  │    │
│  │    │    │    │         PRIMARY (AZ-a)              │   │       REPLICA (AZ-b)           ││  │    │
│  │    │    │    │                                     │   │                                 ││  │    │
│  │    │    │    │  ┌─────────────────────────────┐   │   │  ┌─────────────────────────────┐││  │    │
│  │    │    │    │  │    Database: modsdw          │   │   │  │    Database: modsdw         │││  │    │
│  │    │    │    │  │    (40GB migrated data)      │   │   │  │    (Standby - Sync)        │││  │    │
│  │    │    │    │  │                             │   │   │  │                             │││  │    │
│  │    │    │    │  │  • 120 Tables               │   │   │  └─────────────────────────────┘││  │    │
│  │    │    │    │  │  • 450 Indexes              │   │   │                                 ││  │    │
│  │    │    │    │  │  • 35 Views                │   │   │                                 ││  │    │
│  │    │    │    │  │  • 45 Stored Procs         │   │   │                                 ││  │    │
│  │    │    │    │  │  • 15 Functions            │   │   │                                 ││  │    │
│  │    │    │    │  │  • 8 Triggers              │   │   │                                 ││  │    │
│  │    │    │    │  └─────────────────────────────┘   │   │                                 ││  │    │
│  │    │    │    └─────────────────────────────────────┘   └─────────────────────────────────┘│  │    │
│  │    │    └─────────────────────────────────────────────────────────────────────────────────┘  │    │
│  │    └────────────────────────────────────────────────────────────────────────────────────────┘    │
│  │                                                                                                  │    │
│  │    ┌────────────────────────────────────────────────────────────────────────────────────────┐    │    │
│  │    │                          MANAGEMENT SUBNET (10.0.100.0/24)                            │    │    │
│  │    │                                                                                          │    │    │
│  │    │    ┌─────────────────────────────────────────────────────────────────────────────────┐  │    │    │
│  │    │    │                           CLOUDWATCH                                              │  │    │    │
│  │    │    │                                                                                  │  │    │    │
│  │    │    │   ┌────────────────┐    ┌────────────────┐    ┌────────────────┐                │  │    │    │
│  │    │    │   │   Logs        │    │   Metrics      │    │   Alarms       │                │  │    │    │
│  │    │    │   │   (Logs)      │    │   (Dashboard) │    │   (SNS Alert)  │                │  │    │    │
│  │    │    │   │               │    │                │    │                │                │  │    │    │
│  │    │    │   │ • DMS Tasks  │    │ • CDC Latency │    │ • High Latency │                │  │    │    │
│  │    │    │   │ • RDS Metrics│    │ • Load Speed  │    │ • Task Errors   │                │  │    │    │
│  │    │    │   │ • Network    │    │ • Error Rate  │    │ • Storage Low   │                │  │    │    │
│  │    │    │   └────────────────┘    └────────────────┘    └────────────────┘                │  │    │    │
│  │    │    └───────────────────────────────────────────────────────────────────────────────────┘  │    │
│  │    └────────────────────────────────────────────────────────────────────────────────────────┘    │
│  └────────────────────────────────────────────────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────────────────────────────────────────────┘

```

### 3.2 Data Flow Paths

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              MIGRATION DATA FLOW PATHS                                │
└─────────────────────────────────────────────────────────────────────────────────────┘

PATH 1: SCHEMA CONVERSION (AWS SCT)
────────────────────────────────────

  On-Premises SQL Server                    AWS SCT Workstation                   Target PostgreSQL
  ┌─────────────────────┐                  ┌─────────────────────┐                ┌─────────────────────┐
  │   Metadata Export   │                  │                    │                │                     │
  │   (sys.objects,      │                  │   • Assessment     │                │   Converted Schema  │
  │    sys.columns,     │─────────────────►│   • Conversion     │───────────────►│   • Tables          │
  │    sys.procedures)  │    JDBC/ODBC     │   • Scripts        │   SQL Export   │   • Indexes         │
  │                     │                  │                    │                │   • Constraints     │
  └─────────────────────┘                  └─────────────────────┘                └─────────────────────┘
  
  Arrow 1: JDBC connection reads database metadata
  Arrow 2: Local processing and conversion
  Arrow 3: Manual SQL script execution or DMS applies


PATH 2: FULL LOAD (Bulk Data Migration)
────────────────────────────────────────

  On-Premises SQL Server                 DMS Replication Instance              RDS PostgreSQL
  ┌─────────────────────┐                ┌─────────────────────┐                ┌─────────────────────┐
  │                     │                │                     │                │                     │
  │   Source Tables     │                │   Full Load Engine  │                │   Target Tables     │
  │   (450 + 120)       │────────────────│   (Parallel Read/    │────────────────│   (Bulk Insert)     │
  │                     │   Parallel     │    Write)           │   Parallel     │                     │
  │   • SELECT * FROM   │   TCP/1433     │                     │   TCP/5432     │   • Sequential      │
  │     table ORDER     │                │   • 32 threads      │                │     inserts         │
  │     BY pk           │                │   • Batch commits   │                │   • Batch commits   │
  │                     │                │                     │                │                     │
  └─────────────────────┘                └─────────────────────┘                └─────────────────────┘

  Arrow 1: DMS reads source tables in parallel chunks
  Arrow 2: Internal DMS processing and transformation
  Arrow 3: Bulk inserts to target with batch commits


PATH 3: CDC (Change Data Capture)
──────────────────────────────────

  On-Premises SQL Server                 DMS Replication Instance              RDS PostgreSQL
  ┌─────────────────────┐                ┌─────────────────────┐                ┌─────────────────────┐
  │                     │                │                     │                │                     │
  │ Transaction Log     │                │   CDC Reader        │                │   Apply Engine      │
  │ (T-Log)             │────────────────│   (Log Mining)      │────────────────│   (Transaction      │
  │                     │   SQL Server    │                     │   PostgreSQL   │    Apply)           │
  │   • INSERT          │   CDC API       │   • Parse T-Log     │   Protocol     │                     │
  │   • UPDATE          │   (Changes)     │   • Transform       │   (Binary)    │   • Replicate DML   │
  │   • DELETE          │                │   • Replay to       │                │   • Maintain        │
  │                     │                │     target          │                │     transaction     │
  └─────────────────────┘                └─────────────────────┘                └─────────────────────┘

  Arrow 1: DMS reads SQL Server transaction log continuously
  Arrow 2: Internal transformation of CDC data
  Arrow 3: Applies changes to PostgreSQL maintaining transactional order


PATH 4: VALIDATION (Data Verification)
────────────────────────────────────────

  Source SQL Server                      DMS/Manual Scripts                   Target PostgreSQL
  ┌─────────────────────┐                ┌─────────────────────┐                ┌─────────────────────┐
  │                     │                │                     │                │                     │
  │   Row Counts        │                │   Validation        │                │   Row Counts        │
  │   Checksums         │◄───────────────│   Queries           │───────────────►│   Checksums         │
  │   Sample Data       │   Comparison   │   DMS Validation    │   Comparison   │   Sample Data       │
  │                     │                │                     │                │                     │
  └─────────────────────┘                └─────────────────────┘                └─────────────────────┘

  Arrow 1: Query source for validation metrics
  Arrow 2: Manual or automated comparison
  Arrow 3: Query target for validation metrics


PATH 5: MONITORING
──────────────────

  All Components                         CloudWatch                           SNS/Alerting
  ┌─────────────────────┐                ┌─────────────────────┐                ┌─────────────────────┐
  │                     │                │                     │                │                     │
  │   DMS Task Stats    │───────────────►│   Metrics Collection│───────────────►│   Email/SMS Alert   │
  │   RDS Performance   │   CloudWatch   │   Log Aggregation   │   CloudWatch   │   PagerDuty         │
  │   Network Stats     │   Agent/API    │   Dashboards        │   Alarm        │   Slack             │
  │                     │                │                     │   Action       │                     │
  └─────────────────────┘                └─────────────────────┘                └─────────────────────┘

```

---

## 4. Deep Pre-Migration Assessment (Object-Level)

### 4.1 Full Inventory of Database Objects

#### 4.1.1 Mods Database Inventory (120GB - Actual from OdsObjectInfo.xlsx)

| Object Type | Actual Count | Migration Priority | Migration Method |
|-------------|---------------|-------------------|------------------|
| **USER_TABLE** | 212 | Critical | DMS Full Load |
| **PRIMARY_KEY_CONSTRAINT** | 164 | Critical | DMS (auto-convert) |
| **FOREIGN_KEY_CONSTRAINT** | 162 | Critical | DMS (auto-convert) |
| **SQL_STORED_PROCEDURE** | 135 | High | Manual (PL/pgSQL) |
| **VIEW** | 106 | Medium | Manual (CREATE VIEW) |
| **DEFAULT_CONSTRAINT** | 30 | Medium | DMS (auto-convert) |
| **SQL_INLINE_TABLE_VALUED_FUNCTION** | 3 | High | Manual (PL/pgSQL) |
| **SQL_TRIGGER** | 2 | High | Manual (PL/pgSQL) |
| **UNIQUE_CONSTRAINT** | 2 | Medium | DMS (auto-convert) |
| **SQL_SCALAR_FUNCTION** | 1 | High | Manual (PL/pgSQL) |
| **Total Objects** | **817** | | |

#### 4.1.2 Modsdw Database Inventory (40GB - Actual from OdsObjectInfo.xlsx)

| Object Type | Actual Count | Migration Priority | Migration Method |
|-------------|---------------|-------------------|------------------|
| **USER_TABLE** | 157 | Critical | DMS Full Load |
| **SQL_STORED_PROCEDURE** | 111 | High | Manual (PL/pgSQL) |
| **PRIMARY_KEY_CONSTRAINT** | 83 | Critical | DMS (auto-convert) |
| **VIEW** | 76 | Medium | Manual (CREATE VIEW) |
| **FOREIGN_KEY_CONSTRAINT** | 59 | Critical | DMS (auto-convert) |
| **DEFAULT_CONSTRAINT** | 6 | Medium | DMS (auto-convert) |
| **SQL_INLINE_TABLE_VALUED_FUNCTION** | 3 | High | Manual (PL/pgSQL) |
| **SQL_SCALAR_FUNCTION** | 1 | High | Manual (PL/pgSQL) |
| **UNIQUE_CONSTRAINT** | 1 | Medium | DMS (auto-convert) |
| **Total Objects** | **497** | | |

### 4.2 AWS SCT Assessment Report

The AWS Schema Conversion Tool (SCT) assessment report identifies:

#### 4.2.1 Action Categories

| Category | Icon | Description | Count (Example) |
|----------|------|-------------|-----------------|
| **Errors** | 🔴 | Cannot convert automatically | 15 |
| **Warnings** | 🟡 | May need manual intervention | 45 |
| **Informational** | 🔵 | For awareness | 120 |

#### 4.2.2 Common SQL Server Features Requiring Manual Work

| Feature | SQL Server | PostgreSQL Equivalent | Action Required |
|---------|------------|----------------------|------------------|
| IDENTITY Columns | `IDENTITY(1,1)` | Sequences + DEFAULT | Auto-convert via SCT |
| GETDATE() | `SELECT GETDATE()` | `CURRENT_TIMESTAMP` | Rewrite |
| SCOPE_IDENTITY() | `SELECT SCOPE_IDENTITY()` | `RETURNING` clause | Rewrite |
| @@ROWCOUNT | `SELECT @@ROWCOUNT` | `GET DIAGNOSTICS` | Rewrite |
| NOLOCK Hint | `SELECT * FROM t WITH (NOLOCK)` | Not supported | Remove or use READ COMMITTED |
| OUTPUT Clause | `INSERT...OUTPUT inserted.*` | `RETURNING` clause | Rewrite |
| MERGE Statement | `MERGE INTO...` | Multiple statements | Rewrite |
| PIVOT/UNPIVOT | `PIVOT (...)` | `crosstab()` extension | Rewrite |
| CTE (Recursive) | `WITH RECURSIVE` | Supported | May need tuning |
| Window Functions | `ROW_NUMBER() OVER ()` | Supported | Verify |
| JSON Support | `JSON_...` functions | JSONB functions | May need tuning |
| XML Support | `XML` data type | XML data type | Supported |
| HierarchyID | `hierarchyid` type | Custom implementation | Manual |
| Spatial Types | `geometry`/`geography` | PostGIS extension | Install PostGIS |
| Full-Text Search | `CONTAINS()`, `FREETEXT()` | Full-text search | Manual |

### 4.3 SQL Server to PostgreSQL Data Type Mapping

#### 4.3.1 Detailed Type Conversion Table

| SQL Server Type | Example Value | PostgreSQL Type | Notes |
|-----------------|---------------|-----------------|-------|
| **BIGINT** | `9223372036854775807` | BIGINT | Direct mapping |
| **INT** | `2147483647` | INTEGER | Direct mapping |
| **SMALLINT** | `32767` | SMALLINT | Direct mapping |
| **TINYINT** | `255` | SMALLINT | Range difference |
| **BIT** | `0` or `1` | BOOLEAN | Converted |
| **DECIMAL(p,s)** | `123.45` | NUMERIC(p,s) | Direct mapping |
| **NUMERIC(p,s)** | `123.45` | NUMERIC(p,s) | Direct mapping |
| **MONEY** | `$1,234.56` | MONEY | Or use NUMERIC(19,4) |
| **SMALLMONEY** | `$1,234.56` | MONEY | Or use NUMERIC(10,4) |
| **FLOAT(53)** | `3.14159265358979` | DOUBLE PRECISION | Direct mapping |
| **REAL** | `3.14` | REAL | Direct mapping |
| **DATETIME** | `2024-01-15 14:30:00.000` | TIMESTAMP(3) | Millisecond precision |
| **DATETIME2(n)** | `2024-01-15 14:30:00.1234567` | TIMESTAMP(n) | Up to 6 decimal places |
| **SMALLDATETIME** | `2024-01-15 14:30:00` | TIMESTAMP(0) | Minute precision |
| **DATE** | `2024-01-15` | DATE | Direct mapping |
| **TIME(n)** | `14:30:00.1234567` | TIME(n) | Up to 6 decimal places |
| **DATETIMEOFFSET** | `2024-01-15 14:30:00 -05:00` | TIMESTAMPTZ | Timezone aware |
| **CHAR(n)** | `固定长度` | CHAR(n) | Fixed length |
| **VARCHAR(n)** | `可变长度` | VARCHAR(n) | Variable length |
| **VARCHAR(MAX)** | `Long text...` | TEXT | LOB handling |
| **NVARCHAR(n)** | `Unicode文字` | VARCHAR(n) | Note size is in characters |
| **NVARCHAR(MAX)** | `Long Unicode...` | TEXT | Use TEXT for large |
| **NCHAR(n)** | `固定` | CHAR(n) | Fixed length Unicode |
| **TEXT** | `Long text` | TEXT | Deprecated, use TEXT |
| **NTEXT** | `Long Unicode` | TEXT | Deprecated, use TEXT |
| **BINARY(n)** | `0x4D6F64` | BYTEA | Variable byte array |
| **VARBINARY(n)** | `0x4D6F64` | BYTEA | Variable byte array |
| **VARBINARY(MAX)** | `Binary data...` | BYTEA | Binary LOB |
| **IMAGE** | `Binary data` | BYTEA | Binary LOB |
| **UNIQUEIDENTIFIER** | `550E8400-E29B-41D4-A716-446655440000` | UUID | GUID/UUID |
| **XML** | `<root><item/></root>` | XML | XML data type |
| **SQL_VARIANT** | Various | Not supported | Manual conversion |
| **TIMESTAMP** | `0x00000000000007D1` | BYTEA | Row version |

#### 4.3.2 Specific Conversion Examples

**Example 1: NVARCHAR to VARCHAR**

```sql
-- SQL Server
CREATE TABLE Customer (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(MAX),
    Email NVARCHAR(255)
);

-- PostgreSQL (after conversion)
CREATE SEQUENCE customer_customerid_seq;

CREATE TABLE customer (
    customerid INTEGER NOT NULL DEFAULT nextval('customer_customerid_seq'),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    email VARCHAR(255),
    PRIMARY KEY (customerid)
);

ALTER SEQUENCE customer_customerid_seq OWNED BY customer.customerid;
```

**Example 2: DATETIME to TIMESTAMP**

```sql
-- SQL Server
CREATE TABLE Orders (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    ShipDate DATETIME NULL,
    LastModified DATETIME2(3) NOT NULL DEFAULT SYSDATETIME()
);

-- PostgreSQL
CREATE SEQUENCE orders_orderid_seq;

CREATE TABLE orders (
    orderid INTEGER NOT NULL DEFAULT nextval('orders_orderid_seq'),
    orderdate TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    shipdate TIMESTAMP(3) NULL,
    lastmodified TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (orderid)
);
```

**Example 3: MONEY to NUMERIC**

```sql
-- SQL Server
CREATE TABLE Products (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
    ProductName VARCHAR(100),
    UnitPrice MONEY,
    UnitsInStock SMALLMONEY
);

-- PostgreSQL (MONEY can cause issues, recommended to use NUMERIC)
CREATE TABLE products (
    productid INTEGER NOT NULL DEFAULT nextval('products_productid_seq'),
    productname VARCHAR(100),
    unitprice NUMERIC(19,4),
    unitsinstock NUMERIC(10,4),
    PRIMARY KEY (productid)
);
```

**Example 4: UNIQUEIDENTIFIER to UUID**

```sql
-- SQL Server
CREATE TABLE Sessions (
    SessionID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    UserID UNIQUEIDENTIFIER NOT NULL,
    TokenValue UNIQUEIDENTIFIER
);

-- PostgreSQL
CREATE TABLE sessions (
    sessionid UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    userid UUID NOT NULL,
    tokenvalue UUID
);
```

**Example 5: BIT to BOOLEAN**

```sql
-- SQL Server
CREATE TABLE Employees (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    IsActive BIT NOT NULL DEFAULT 1,
    IsManager BIT NOT NULL DEFAULT 0,
    IsApproved BIT NULL
);

-- PostgreSQL
CREATE TABLE employees (
    employeeid INTEGER NOT NULL DEFAULT nextval('employees_employeeid_seq'),
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    isactive BOOLEAN NOT NULL DEFAULT true,
    ismanager BOOLEAN NOT NULL DEFAULT false,
    isapproved BOOLEAN,
    PRIMARY KEY (employeeid)
);
```

### 4.4 Identity to Sequence Conversion

SQL Server uses IDENTITY property for auto-incrementing columns, while PostgreSQL uses sequences. SCT handles this conversion automatically.

#### 4.4.1 Conversion Logic

```
SQL Server:                          PostgreSQL:
┌─────────────────────────┐         ┌─────────────────────────┐
│ CREATE TABLE Orders (    │   ──►   │ CREATE SEQUENCE         │
│     OrderID INT         │         │     orders_orderid_seq │
│     IDENTITY(1,1)       │         │                         │
│     PRIMARY KEY,        │         │ CREATE TABLE orders (   │
│     ...                 │         │     orderid INT         │
│ );                      │         │     DEFAULT nextval(   │
└─────────────────────────┘         │       'orders_orderid_seq│
                                     │     ')                  │
                                     │     PRIMARY KEY,        │
                                     │     ...                 │
                                     │ );                      │
                                     └─────────────────────────┘
```

#### 4.4.2 Key Considerations

1. **Sequence Cache**: PostgreSQL sequences have cache by default. This may cause gaps in sequence values.

2. **Sequence Ownership**: Use `ALTER SEQUENCE ... OWNED BY` to link sequence to column.

3. **Last Inserted ID**: Use `RETURNING` clause instead of `SCOPE_IDENTITY()`:

```sql
-- SQL Server
INSERT INTO Orders (CustomerID, OrderDate)
VALUES (123, GETDATE());
SELECT SCOPE_IDENTITY();

-- PostgreSQL
INSERT INTO orders (customerid, orderdate)
VALUES (123, CURRENT_TIMESTAMP)
RETURNING orderid;
```

4. **Sequence Options**:

```sql
-- Create sequence with same behavior as IDENTITY(1,1)
CREATE SEQUENCE orderid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO CYCLE
    CACHE 10;  -- Equivalent to IDENTITY caching
```

### 4.5 Collation Differences and Case Sensitivity

#### 4.5.1 SQL Server vs PostgreSQL Collation

| Aspect | SQL Server | PostgreSQL |
|--------|------------|------------|
| Default Collation | SQL_Latin1_General_CP1_CI_AS | en_US.utf8 |
| Case Sensitivity | Depends on collation | Determined by operator |
| Accent Sensitivity | Part of collation | Separate setting |
| Unicode Support | NVARCHAR, NCHAR | All text is Unicode |
| Index Behavior | Collation affects | Locale affects sorting |

#### 4.5.2 Case Sensitivity Migration

```sql
-- SQL Server (case-insensitive by default)
SELECT * FROM users WHERE username = 'JOHN';

-- PostgreSQL (case-sensitive by default)
SELECT * FROM users WHERE username = 'JOHN';  -- Won't match 'John'

-- For case-insensitive comparison
SELECT * FROM users WHERE LOWER(username) = LOWER('JOHN');

-- Or use ILIKE
SELECT * FROM users WHERE username ILIKE 'JOHN';
```

#### 4.5.3 Recommended Approach

1. **Determine current SQL Server collation**
```sql
-- SQL Server
SELECT name, collation_name 
FROM sys.databases 
WHERE name = 'Mods';

SELECT 
    c.name AS column_name,
    c.collation_name
FROM sys.columns c
JOIN sys.tables t ON c.object_id = t.object_id
WHERE t.name = 'YourTable';
```

2. **Plan PostgreSQL collation strategy**
```sql
-- PostgreSQL: Create case-insensitive collation
CREATE COLLATION case_insensitive (
    LOCALE = 'en-US',
    PROVIDER = 'icu',
    DETERMINISTIC = false
);

-- Apply to columns
CREATE TABLE users (
    username VARCHAR(100) COLLATE case_insensitive,
    ...
);
```

3. **Handle accent sensitivity**
```sql
-- If SQL Server is accent-insensitive (CI_AI)
-- PostgreSQL: Create accent-insensitive collation
CREATE COLLATION accent_insensitive (
    LOCALE = 'en-US-x-icu',
    PROVIDER = 'icu',
    DETERMINISTIC = false
);
```

### 4.6 Stored Procedure Migration Strategy

#### 4.6.1 Conversion Requirements

SQL Server T-SQL stored procedures require significant rewriting for PostgreSQL.

**Example: Simple Stored Procedure**

```sql
-- SQL Server T-SQL
CREATE PROCEDURE GetCustomerOrders
    @CustomerID INT,
    @OrderCount INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT OrderID, OrderDate, TotalAmount
    FROM Orders
    WHERE CustomerID = @CustomerID
    ORDER BY OrderDate DESC;
    
    SET @OrderCount = @@ROWCOUNT;
    
    RETURN 0;
END;

-- PostgreSQL PL/pgSQL
CREATE OR REPLACE FUNCTION get_customer_orders(
    p_customerid INTEGER,
    OUT ordercount INTEGER
) RETURNS SETOF RECORD
AS $$
BEGIN
    RETURN QUERY 
    SELECT o.orderid, o.orderdate, o.totalamount
    FROM orders o
    WHERE o.customerid = p_customerid
    ORDER BY o.orderdate DESC;
    
    GET DIAGNOSTICS ordercount = ROW_COUNT;
    
    RETURN;
END;
$$ LANGUAGE plpgsql;
```

#### 4.6.2 Complex Procedure Patterns

| T-SQL Pattern | PL/pgSQL Equivalent |
|---------------|---------------------|
| `EXEC @result = sp_name` | `PERFORM sp_name()` or function |
| `OUTPUT parameters` | `INOUT parameters` |
| `@@ERROR` | `GET DIAGNOSTICS` |
| `@@ROWCOUNT` | `GET DIAGNOSTICS` |
| `RAISERROR` | `RAISE EXCEPTION` |
| `TRY...CATCH` | `BEGIN...EXCEPTION` |
| `SET NOCOUNT ON` | Not needed (default) |
| `CURSOR` | `FOR loop` or `RETURN QUERY` |
| `TABLE variable` | Temporary table or array |
| `INSERTED`/`DELETed` | Use `RETURNING` or trigger variables |

### 4.7 Dependency Resolution Order

Objects must be created in a specific order based on dependencies:

#### 4.7.1 Creation Order

```
1. SEQUENCES
   └── Used for IDENTITY conversion
   
2. TABLES (Base)
   └── Without foreign keys first
   
3. PRIMARY KEYS
   └── After table creation
   
4. UNIQUE CONSTRAINTS/INDEXES
   
5. NON-UNIQUE INDEXES
   └── May defer until after data load
   
6. SEQUENCES (with ownership)
   └── After tables and columns exist
   
7. VIEWS (base tables only)
   └── Views referencing other views in order
   
8. FUNCTIONS
   └── Before procedures that call them
   
9. STORED PROCEDURES
   └── After functions they call
   
10. TRIGGERS
    └── After tables, functions exist
    
11. FOREIGN KEYS
    └── After referenced tables exist
```

#### 4.7.2 Script Organization

Organize converted scripts into folders:

```
schema/
├── 01-sequences.sql
├── 02-tables.sql
├── 03-primary-keys.sql
├── 04-indexes.sql
├── 05-views.sql
├── 06-functions.sql
├── 07-procedures.sql
├── 08-triggers.sql
└── 09-foreign-keys.sql
```

---

## 5. Schema Conversion & Object Migration Strategy

### 5.1 Converting Schema Using AWS SCT

#### 5.1.1 SCT Installation and Configuration

1. **Download AWS SCT**
   - Go to AWS SCT download page
   - Install on Windows workstation (or EC2 instance)

2. **Create Assessment Project**
   ```
   File → New Assessment Report
   Source Database Engine: SQL Server
   Target Database Engine: PostgreSQL
   Connect to source: Enter SQL Server details
   ```

3. **Run Assessment**
   ```
   View → Assessment Report
   Category: All
   Generate: HTML or PDF report
   ```

#### 5.1.2 Schema Conversion Steps

1. **Connect to Source**
   - JDBC connection string: `jdbc:sqlserver://hostname:1433;databaseName=Mods`
   - Username/password
   - Test connection

2. **Connect to Target**
   - JDBC connection string: `jdbc:postgresql://postgres-host:5432/mods`
   - Username/password
   - Test connection

3. **Convert Schema**
   ```
   Right-click database → Convert Schema
   Select target: PostgreSQL
   Converted files location: C:\migration\schema\
   ```

4. **Apply to Target**
   ```
   Select converted objects → Apply to Database
   Confirm: Yes
   ```

### 5.2 Applying Converted Schema to RDS PostgreSQL

#### 5.2.1 Manual Application Method

```bash
# Connect to PostgreSQL
psql -h postgres-mods.xxxx.us-east-1.rds.amazonaws.com \
     -U dbadmin \
     -d mods

# Execute schema files in order
\i 01-sequences.sql
\i 02-tables.sql
\i 03-primary-keys.sql
\i 04-indexes.sql
\i 05-views.sql
\i 06-functions.sql
\i 07-procedures.sql
\i 08-triggers.sql
\i 09-foreign-keys.sql
```

#### 5.2.2 Validation Queries

**Validate Tables:**

```sql
-- List all tables
SELECT 
    table_name,
    table_type
FROM information_schema.tables 
WHERE table_schema = 'public'
ORDER BY table_name;

-- Count tables
SELECT COUNT(*) AS table_count 
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_type = 'BASE TABLE';
```

**Validate Primary Keys:**

```sql
-- List primary keys
SELECT
    tc.table_name,
    kcu.column_name,
    tc.constraint_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
    ON tc.constraint_name = kcu.constraint_name
WHERE tc.constraint_type = 'PRIMARY KEY'
    AND tc.table_schema = 'public'
ORDER BY tc.table_name;
```

**Validate Foreign Keys:**

```sql
-- List foreign keys
SELECT
    tc.table_name AS child_table,
    kcu.column_name AS child_column,
    ccu.table_name AS parent_table,
    ccu.column_name AS parent_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage ccu 
    ON tc.constraint_name = ccu.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
    AND tc.table_schema = 'public'
ORDER BY tc.table_name;
```

### 5.3 Object Validation Checklist

| Object Type | Validation Query | Expected Result |
|-------------|------------------|------------------|
| Tables | `SELECT COUNT(*) FROM information_schema.tables WHERE table_type='BASE TABLE'` | ≥ 450 (Mods), ≥ 120 (Modsdw) |
| Views | `SELECT COUNT(*) FROM information_schema.views WHERE table_schema='public'` | ≥ 80 (Mods), ≥ 35 (Modsdw) |
| Primary Keys | `SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_type='PRIMARY KEY'` | ≥ 450 (Mods), ≥ 120 (Modsdw) |
| Foreign Keys | `SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_type='FOREIGN KEY'` | ≥ 800 (Mods), ≥ 150 (Modsdw) |
| Sequences | `SELECT COUNT(*) FROM information_schema.sequences` | ≥ 450 (Mods), ≥ 120 (Modsdw) |
| Indexes | `SELECT COUNT(*) FROM pg_indexes WHERE schemaname='public'` | ≥ 2,100 (Mods), ≥ 450 (Modsdw) |
| Functions | `SELECT COUNT(*) FROM pg_proc WHERE pronamespace = 'public'::regnamespace` | ≥ 180 (Mods), ≥ 55 (Modsdw) |
| Triggers | `SELECT COUNT(*) FROM pg_trigger WHERE NOT tgisinternal` | ≥ 25 (Mods), ≥ 8 (Modsdw) |

### 5.4 DMS vs Manual Object Migration

| Object Type | DMS Can Migrate | Must Migrate Manually | Notes |
|-------------|-----------------|----------------------|-------|
| Tables | ✅ Yes | | Full schema with constraints |
| Data | ✅ Yes | | Full Load + CDC |
| Primary Keys | ✅ Yes | | Converted automatically |
| Foreign Keys | ✅ Yes | | With table data |
| Indexes | ✅ Yes | | DMS creates during load |
| Views | ❌ No | ✅ Yes | Must convert manually |
| Stored Procedures | ❌ No | ✅ Yes | Must rewrite to PL/pgSQL |
| Functions | ❌ No | ✅ Yes | Must rewrite to PL/pgSQL |
| Triggers | ❌ No | ✅ Yes | Must rewrite to PL/pgSQL |
| Sequences | ❌ No | ✅ Yes | SCT generates scripts |
| User-Defined Types | ❌ No | ✅ Yes | Custom conversion |
| Extended Properties | ❌ No | ✅ Yes | Document separately |

### 5.5 Procedure Migration and Testing Strategy

#### 5.5.1 Migration Workflow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Extract T-SQL  │────►│  Convert to     │────►│  Test in        │
│  Source Code    │     │  PL/pgSQL       │     │  PostgreSQL     │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                      │
                                                      ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Document       │◄────│  Fix Issues     │◄────│  Unit Test      │
│  Behavior       │     │  and Retest     │     │  Each Procedure│
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

#### 5.5.2 Testing Strategy

1. **Syntax Validation**
```sql
-- Test function syntax
DO $$
BEGIN
    -- Attempt to create/compile function
END $$;
```

2. **Functional Testing**
```sql
-- Compare results between SQL Server and PostgreSQL
-- Run same test data through both systems
-- Compare outputs
```

3. **Performance Testing**
```sql
-- Measure execution time
-- Compare query plans
-- Optimize as needed
```

### 5.6 Index Rebuild Timing Strategy

#### 5.6.1 Recommended Approach

| Phase | Index Strategy | Rationale |
|-------|----------------|-----------|
| **Initial Schema** | Create PK, FK, Unique indexes only | Ensure data integrity during load |
| **Full Load** | Skip non-unique indexes | Faster bulk loading |
| **After Full Load** | Create remaining indexes | Before CDC starts |
| **During CDC** | No index changes | Maintain consistency |
| **Post-Cutover** | Review and optimize | Based on actual usage |

#### 5.6.2 DMS Index Handling Settings

```json
{
  "IndexLoadingMode": "OptimizeForBulkImport",
  "CollectRowCountStatistics": true,
  "MaxFullLoadSubTasks": 32,
  "CommitRate": 10000
}
```

---

## 6. Implementation Phase (Console-Level Detailed Steps)

### 6.1 Create VPC

#### Step 1: Create VPC

```
AWS Console → VPC → Your VPCs → Create VPC

VPC Settings:
├── Name tag: migration-vpc
├── IPv4 CIDR block: 10.0.0.0/16
├── IPv6 CIDR block: No IPv6 CIDR Block
├── Tenancy: Default
└── Click: Create VPC
```

#### Step 2: Create Subnets

```
VPC → Subnets → Create Subnet

Public Subnet (AZ-a):
├── VPC: migration-vpc
├── Subnet name: public-subnet-a
├── Availability Zone: us-east-1a
├── IPv4 CIDR block: 10.0.0.0/24
└── Create

Public Subnet (AZ-b):
├── Subnet name: public-subnet-b
├── Availability Zone: us-east-1b
├── IPv4 CIDR block: 10.0.1.0/24
└── Create

Private Subnet Database (AZ-a):
├── Subnet name: private-db-subnet-a
├── Availability Zone: us-east-1a
├── IPv4 CIDR block: 10.0.10.0/24
└── Create

Private Subnet Database (AZ-b):
├── Subnet name: private-db-subnet-b
├── Availability Zone: us-east-1b
├── IPv4 CIDR block: 10.0.11.0/24
└── Create

Private Subnet Management (AZ-a):
├── Subnet name: private-mgmt-subnet-a
├── Availability Zone: us-east-1a
├── IPv4 CIDR block: 10.0.100.0/24
└── Create

Private Subnet Management (AZ-b):
├── Subnet name: private-mgmt-subnet-b
├── Availability Zone: us-east-1b
├── IPv4 CIDR block: 10.0.101.0/24
└── Create
```

#### Step 3: Create Internet Gateway

```
VPC → Internet Gateways → Create internet gateway

Settings:
├── Name tag: migration-igw
└── Click: Create

Actions → Attach to VPC
├── VPC: migration-vpc
└── Click: Attach
```

#### Step 4: Create Route Tables

```
Public Route Table:
VPC → Route Tables → Create Route Table
├── Name tag: public-rt
├── VPC: migration-vpc
└── Create

Routes → Edit routes → Add route
├── Destination: 0.0.0.0/0
├── Target: migration-igw
└── Save

Subnets → Subnet associations → Edit subnet associations
├── Associate: public-subnet-a
├── Associate: public-subnet-b
└── Save

Private Route Table (for NAT):
VPC → Route Tables → Create Route Table
├── Name tag: private-rt
├── VPC: migration-vpc
└── Create

Routes → Edit routes
├── Destination: 0.0.0.0/0
├── Target: nat-xxxxx (create NAT Gateway first)
└── Save

Subnets → Subnet associations
├── Associate: All private subnets
└── Save
```

#### Step 5: Create NAT Gateways

```
VPC → NAT Gateways → Create NAT Gateway

NAT Gateway (AZ-a):
├── Subnet: public-subnet-a
├── Connectivity type: Public
├── Elastic IP allocation: Allocate Elastic IP
└── Create

NAT Gateway (AZ-b):
├── Subnet: public-subnet-b
├── Connectivity type: Public
└── Create
```

### 6.2 Configure Networking

#### Step 6: Create Security Groups

```
EC2 → Security Groups → Create Security Group

Security Group for RDS (sg-postgres):
├── Name: sg-postgres
├── Description: RDS PostgreSQL security group
├── VPC: migration-vpc
├── Inbound Rules:
│   ├── Type: PostgreSQL | Source: sg-dms | Description: DMS access
│   ├── Type: PostgreSQL | Source: sg-application | Description: App access
│   └── Type: PostgreSQL | Source: <your-ip/32> | Description: Admin access
└── Create

Security Group for DMS (sg-dms):
├── Name: sg-dms
├── Description: DMS replication instance
├── VPC: migration-vpc
├── Inbound Rules:
│   ├── Type: Custom TCP | Port: 1433 | Source: <on-prem-sql-ip/32> | SQL Server
│   └── Type: Custom TCP | Port: 5432 | Source: sg-postgres | PostgreSQL
└── Create

Security Group for Application (sg-application):
├── Name: sg-application
├── Description: Application tier
├── VPC: migration-vpc
├── Inbound Rules:
│   └── Type: HTTPS | Source: ALB security group
└── Create
```

### 6.3 Create RDS PostgreSQL

#### Step 7: Create RDS Subnet Group

```
RDS → Subnet Groups → Create DB Subnet Group

Settings:
├── Name: mods-subnet-group
├── Description: Subnet group for Mods database
├── VPC: migration-vpc
├── Add subnets:
│   ├── us-east-1a: 10.0.10.0/24
│   └── us-east-1b: 10.0.11.0/24
└── Create
```

#### Step 8: Create RDS PostgreSQL Instance (Mods)

```
RDS → Databases → Create database

Choose a database creation method:
├── Standard create
└── Engine options:
    ├── Engine type: PostgreSQL
    ├── Version: PostgreSQL 15.4
    └── Templates: Production (for Multi-AZ)

Settings:
├── DB instance identifier: postgres-mods
├── Master username: dbadmin
├── Master password: <complex-password>
├── Confirm password: <complex-password>

Instance configuration:
├── Instance class: db.r6g.4xlarge (16 vCPU, 128 GB)
└── Storage:
    ├── Storage type: General Purpose (gp3)
    ├── Allocated storage: 500 GB
    ├── IOPS: 3000
    ├── Throughput: 125 MB/s
    └── Enable storage autoscaling: Unchecked

Availability & durability:
├── Multi-AZ deployment: Create a standby instance (recommended)
└── Primary DB instance will be in: us-east-1a

Connectivity:
├── VPC: migration-vs
├── Subnet group: mods-subnet-group
├── Public access: No
├── VPC security groups: sg-postgres (remove default)
├── Database port: 5432
└── Availability Zone: us-east-1a

Database authentication:
├── Password authentication: Selected
└── Click: Create database

Note: This will take 15-30 minutes to provision
```

#### Step 9: Create RDS PostgreSQL Instance (Modsdw)

```
Follow same steps with:
├── DB instance identifier: postgres-modsdw
├── Instance class: db.r6g.2xlarge (8 vCPU, 64 GB)
├── Allocated storage: 200 GB
├── Database name: modsdw
└── Same security group and subnet group
```

#### Step 10: Create Custom Parameter Groups

```
RDS → Parameter Groups → Create parameter group

Mods Parameter Group:
├── Parameter group family: postgres15
├── Group name: custom-postgres15-mods
├── Description: Custom parameters for Mods migration
└── Create

Modsdw Parameter Group:
├── Parameter group family: postgres15
├── Group name: custom-postgres15-modsdw
├── Description: Custom parameters for Modsdw migration
└── Create

Modify parameters as needed:
├── max_connections: 500
├── shared_buffers: 32768 (32GB, ~25% of RAM)
├── work_mem: 16384
├── maintenance_work_mem: 2097152
├── effective_cache_size: 98304
├── random_page_cost: 1.1 (for SSD)
├── effective_io_concurrency: 200
└── log_connections: on
```

### 6.4 Configure DMS Replication Instance

#### Step 11: Create DMS Replication Instance

```
DMS → Replication instances → Create replication instance

Settings:
├── Name: dms-replication-instance
├── Description: Migration for Mods and Modsdw
├── Instance class: dms.r6g.4xlarge
├── Engine version: 3.5.1 (latest)
├── Allocated storage (GB): 50
├── VPC: migration-vpc
├── Multi-AZ: Multi-AZ (production)
├── Replication subnet group: Create new
│   ├── Name: dms-subnet-group
│   └── Subnets: private-db-subnet-a, private-db-subnet-b
├── Publicly accessible: No
├── Security groups: sg-dms
├── KMS master key: aws/dms (default)
└── Click: Create

Wait for status to become "available" (~5-10 minutes)
```

### 6.5 Create DMS Endpoints

#### Step 12: Create Source Endpoint (SQL Server - Mods)

```
DMS → Endpoints → Create endpoint

Endpoint configuration:
├── Endpoint type: Source
├── Endpoint identifier: source-mods
├── Engine name: sqlserver

SQL Server settings:
├── Server name: <on-prem-sql-server-ip>
├── Port: 1433
├── Database name: Mods
├── Username: dms_user
├── Password: <password>

Extra connection attributes:
capture_identity=true;security_database=master

Endpoint-specific settings:
├── Access to endpoint database: Need to select an existing VPC or create a new one
├── VPC: migration-vpc

Test endpoint connection:
├── Replication instance: dms-replication-instance
├── Click: Run test
└── Verify: successful

Click: Create endpoint
```

#### Step 13: Create Source Endpoint (SQL Server - Modsdw)

```
Same as above with:
├── Endpoint identifier: source-modsdw
├── Database name: Modsdw
└── Test connection
```

#### Step 14: Create Target Endpoint (PostgreSQL - Mods)

```
DMS → Endpoints → Create endpoint

Endpoint configuration:
├── Endpoint type: Target
├── Endpoint identifier: target-mods
├── Engine name: postgres

PostgreSQL settings:
├── Server name: <RDS endpoint>
├── Port: 5432
├── Database name: mods
├── Username: dbadmin
├── Password: <password>

Extra connection attributes:
dbschema=public

Endpoint-specific settings:
├── Access to endpoint database: Provide access now (or after)
├── VPC: migration-vpc

Test endpoint connection:
├── Replication instance: dms-replication-instance
├── Run test
└── Verify: successful

Click: Create endpoint
```

#### Step 15: Create Target Endpoint (PostgreSQL - Modsdw)

```
Same as above with:
├── Endpoint identifier: target-modsdw
├── Database name: modsdw
└── Test connection
```

### 6.6 Create Migration Tasks

#### Step 16: Create Full Load + CDC Task (Mods)

```
DMS → Database migration tasks → Create task

Task configuration:
├── Task identifier: mods-full-load-cdc
├── Replication instance: dms-replication-instance
├── Source endpoint: source-mods
├── Target endpoint: target-mods
├── Migration type: Migrate existing data and replicate ongoing changes

Task settings:
├── Target table preparation mode: Do nothing (schema already created)
├── LOB settings: Full LOB mode (or Limited LOB mode with 64KB limit)
├── Validation: Enable validation (recommended)
├── Logging: Enable CloudWatch logging

Table mappings:
├── Selection rule:
│   └── Schema: Include | schema: dbo
└── Transformation rules:
    └── None needed

Click: Create task
```

#### Step 17: Create Full Load + CDC Task (Modsdw)

```
Same as above with:
├── Task identifier: modsdw-full-load-cdc
├── Source endpoint: source-modsdw
├── Target endpoint: target-modsdw
└── Selection rule: dbo schema
```

### 6.7 Critical DMS Task JSON Settings

#### 6.7.1 Full Load + CDC Task Settings

```json
{
  "TargetMetadata": {
    "TargetSchema": "public",
    "SupportLobs": true,
    "FullLobMode": false,
    "LobChunkSize": 64,
    "LimitedSizeLobMode": true,
    "LobMaxSize": 32,
    "InlineLobMaxSize": 0,
    "LoadPartitioning": "balanced",
    "ParallelLoadBuffering": true,
    "ParallelLoadThreads": 16
  },
  "FullLoadSettings": {
    "TargetTablePreparationMode": "do-nothing",
    "CreatePkAfterFullLoad": false,
    "StopTaskCachedChangesApplied": false,
    "StopTaskCachedChangesNotApplied": false,
    "MaxFullLoadSubTasks": 32,
    "TransactionConsistencyTimeout": 600,
    "CommitRate": 10000,
    "FastLoadSwapPhase": true
  },
  "Logging": {
    "EnableLogging": true,
    "LogComponents": [
      {
        "Id": "SOURCE_UNLOAD",
        "Severity": "LOGGER_SEVERITY_DEFAULT"
      },
      {
        "Id": "TARGET_LOAD",
        "Severity": "LOGGER_SEVERITY_DEFAULT"
      },
      {
        "Id": "TARGET_APPLY",
        "Severity": "LOGGER_SEVERITY_DEFAULT"
      },
      {
        "Id": "CACHE",
        "Severity": "LOGGER_SEVERITY_DEFAULT"
      }
    ]
  },
  "ValidationSettings": {
    "EnableValidation": true,
    "ValidationMode": "row-count-only",
    "ThreadCount": 5,
    "FailureMax": 10000,
    "TableFailureMax": 1000,
    "ValidateLobSync": true
  },
  "ControlTableSettings": {
    "ControlSchema": "public",
    "CreateControlTable": true,
    "TargetTablePrepMode": "truncate-before-load"
  }
}
```

#### 6.7.2 Task Settings Explanation

| Setting | Value | Explanation |
|---------|-------|-------------|
| `TargetTablePreparationMode` | do-nothing | Schema already exists (we applied via SCT) |
| `FullLobMode` | false | Use limited LOB mode for performance |
| `LobChunkSize` | 64 | 64KB chunks for LOB data |
| `MaxFullLoadSubTasks` | 32 | Parallel table loading |
| `CommitRate` | 10000 | Rows per commit during bulk load |
| `ParallelLoadThreads` | 16 | Threads per table for parallel loading |
| `EnableValidation` | true | Row count and data validation |
| `ValidationMode` | row-count-only | Can also use "full" for full validation |
| `EnableLogging` | true | CloudWatch logging for troubleshooting |

---

## 7. Data Validation & Complete Verification Strategy

### 7.1 Row Count Validation Queries

#### 7.1.1 Table-by-Table Comparison

```sql
-- PostgreSQL: Generate row count for all tables
SELECT 
    schemaname,
    relname AS table_name,
    n_live_tup AS row_count
FROM pg_stat_user_tables
WHERE schemaname = 'public'
ORDER BY n_live_tup DESC;

-- For detailed comparison, create this output:
-- table_name, source_count, target_count, match
```

#### 7.1.2 Automated Row Count Script

```python
#!/usr/bin/env python3
"""
Row count validation between SQL Server and PostgreSQL
"""
import pyodbc
import psycopg2

def get_sqlserver_counts():
    """Get row counts from SQL Server"""
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=your_sqlserver;'
        'DATABASE=Mods;'
        'UID=your_user;'
        'PWD=your_password'
    )
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT 
            t.name AS table_name,
            SUM(p.rows) AS row_count
        FROM sys.tables t
        INNER JOIN sys.partitions p 
            ON t.object_id = p.object_id
        WHERE p.index_id IN (0, 1)
        GROUP BY t.name
        ORDER BY t.name
    """)
    
    results = {row[0]: row[1] for row in cursor.fetchall()}
    conn.close()
    return results

def get_postgres_counts():
    """Get row counts from PostgreSQL"""
    conn = psycopg2.connect(
        host='postgres-mods.xxxx.rds.amazonaws.com',
        database='mods',
        user='dbadmin',
        password='your_password'
    )
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT 
            schemaname,
            relname AS table_name,
            n_live_tup AS row_count
        FROM pg_stat_user_tables
        WHERE schemaname = 'public'
        ORDER BY relname
    """)
    
    results = {row[1]: row[2] for row in cursor.fetchall()}
    conn.close()
    return results

def compare_counts():
    """Compare counts between source and target"""
    source = get_sqlserver_counts()
    target = get_postgres_counts()
    
    mismatches = []
    for table, count in source.items():
        target_count = target.get(table, 0)
        if count != target_count:
            mismatches.append({
                'table': table,
                'source': count,
                'target': target_count,
                'difference': count - target_count
            })
    
    if mismatches:
        print("MISMATCHES FOUND:")
        for m in mismatches:
            print(f"  {m['table']}: Source={m['source']}, Target={m['target']}, Diff={m['difference']}")
    else:
        print("ALL ROW COUNTS MATCH!")
    
    return mismatches

if __name__ == '__main__':
    compare_counts()
```

### 7.2 Checksum Validation Approach

#### 7.2.1 MD5 Checksum by Table

```sql
-- PostgreSQL: Generate MD5 checksum of all data in each table
-- For tables with numeric PKs

-- Create checksum function
CREATE OR REPLACE FUNCTION generate_table_checksum(p_table_name TEXT)
RETURNS TABLE(checksum TEXT) AS $$
BEGIN
    RETURN QUERY EXECUTE format(
        'SELECT MD5(COALESCE(array_agg(%s ORDER BY %s)::text, '''')) 
         FROM %I',
        (SELECT string_agg(column_name, ',') 
         FROM information_schema.key_column_usage kcu
         JOIN information_schema.table_constraints tc 
             ON kcu.constraint_name = tc.constraint_name
         WHERE tc.table_name = p_table_name 
           AND tc.constraint_type = 'PRIMARY KEY'),
        (SELECT string_agg(column_name, ',') 
         FROM information_schema.key_column_usage kcu
         JOIN information_schema.table_constraints tc 
             ON kcu.constraint_name = tc.constraint_name
         WHERE tc.table_name = p_table_name 
           AND tc.constraint_type = 'PRIMARY KEY'),
        p_table_name
    );
END;
$$ LANGUAGE plpgsql;

-- Run for specific table
SELECT generate_table_checksum('customer');
```

#### 7.2.2 Sample Data Validation

```sql
-- Compare sample rows between systems
-- SQL Server: Get sample rows
SELECT TOP 100 * FROM Customer ORDER BY CustomerID;

-- PostgreSQL: Get same rows
SELECT * FROM customer ORDER BY customerid LIMIT 100;

-- Compare each column value manually or programmatically
```

### 7.3 Foreign Key Validation Queries

```sql
-- PostgreSQL: Find missing parent records
SELECT 
    fk.table_name AS child_table,
    fk.column_name AS child_column,
    fk.constraint_name,
    pk.table_name AS parent_table
FROM information_schema.key_column_usage fk
JOIN information_schema.table_constraints tc 
    ON fk.constraint_name = tc.constraint_name
JOIN information_schema.referential_constraints rc 
    ON tc.constraint_name = rc.constraint_name
JOIN information_schema.key_column_usage pk 
    ON rc.unique_constraint_name = pk.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
    AND fk.table_schema = 'public';

-- Find orphaned records (if any)
-- For each foreign key, run:
SELECT c.customerid, c.customername
FROM customer c
LEFT JOIN country ct ON c.countryid = ct.countryid
WHERE ct.countryid IS NULL
  AND c.countryid IS NOT NULL;
```

### 7.4 Index Validation Queries

```sql
-- List all indexes in PostgreSQL
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- Compare with SQL Server
-- SQL Server:
SELECT 
    t.name AS table_name,
    i.name AS index_name,
    i.type_desc AS index_type,
    i.is_unique AS is_unique,
    i.is_primary_key AS is_primary
FROM sys.indexes i
JOIN sys.tables t ON i.object_id = t.object_id
WHERE t.is_ms_shipped = 0
ORDER BY t.name, i.name;
```

### 7.5 Procedure Existence Verification

```sql
-- PostgreSQL: List all functions
SELECT 
    routine_name,
    routine_type,
    data_type AS return_type
FROM information_schema.routines
WHERE routine_schema = 'public'
ORDER BY routine_name;

-- List all procedures (PostgreSQL treats functions same)
SELECT 
    proname AS procedure_name,
    pronargs AS argument_count,
    proargnames AS argument_names
FROM pg_proc
WHERE pronamespace = 'public'::regnamespace;

-- Compare with SQL Server:
SELECT 
    name AS procedure_name,
    type_desc,
    create_date,
    modify_date
FROM sys.procedures
ORDER BY name;
```

### 7.6 Sequence Value Validation

```sql
-- PostgreSQL: Check sequence values
SELECT 
    sequence_name,
    start_value,
    last_value,
    increment_by,
    max_value,
    min_value
FROM information_schema.sequences;

-- Find sequences with gaps (common after migration)
-- Compare with max values in ID columns:
SELECT 
    sequence_name,
    last_value AS sequence_last,
    (SELECT MAX(column_name) FROM table_name) AS table_max
FROM information_schema.sequences
WHERE sequence_name = 'table_name_column_name_seq';

-- If gaps are unacceptable, reset sequence:
-- SELECT setval('sequence_name', (SELECT MAX(id) FROM table_name));
```

### 7.7 LOB Validation Approach

```sql
-- PostgreSQL: Check LOB column handling
SELECT 
    table_name,
    column_name,
    data_type,
    character_maximum_length,
    is_nullable
FROM information_schema.columns
WHERE data_type IN ('text', 'bytea', 'xml')
    AND table_schema = 'public';

-- Validate LOB content integrity
-- Compare LOB lengths between source and target
SELECT 
    table_name,
    column_name,
    COUNT(*) AS total_rows,
    SUM(OCTET_LENGTH(column_name)) AS total_lob_size
FROM table_name
GROUP BY table_name, column_name;
```

### 7.8 DMS Validation Feature Usage

```sql
-- DMS automatically creates validation tables
-- These are created in target database:

-- DMS_VALIDATION_STATUS: Overall task validation status
SELECT * FROM dms_validation_status;

-- DMS_VALIDATION_HISTORY: Historical validation runs
SELECT * FROM dms_validation_history;

-- DMS_VALIDATION_SUMMARY: Summary by table
SELECT * FROM dms_validation_summary;

-- To check validation status via CLI:
aws dms describe-table-statistics \
    --replication-task-arn <task-arn> \
    --output json

-- Example output:
{
    "ReplicationTaskStatistics": {
        "FullLoadProgressPercent": 100,
        "TablesInProgress": 0,
        "TablesCompleted": 450,
        "TablesErrored": 0,
        "RowsLoaded": 50000000,
        "RowsLoading": 0,
        "Inserts": 45000000,
        "Updates": 5000000,
        "Deletes": 0,
        "DDLStatements": 0,
        "ValidationPendingRecords": 0,
        "ValidationFailedRecords": 0,
        "ValidationSuspendedRecords": 0,
        "ValidationNotCheckedRecords": 0
    }
}
```

### 7.9 Reconciliation Report Method

#### 7.9.1 Create Reconciliation Report Template

```python
#!/usr/bin/env python3
"""
Generate comprehensive reconciliation report
"""
import datetime

class MigrationReconciliation:
    def __init__(self, source_db, target_db):
        self.source = source_db
        self.target = target_db
        self.report = []
    
    def add_header(self, title):
        self.report.append(f"\n{'='*60}")
        self.report.append(f"  {title}")
        self.report.append(f"{'='*60}\n")
    
    def add_section(self, title, data):
        self.report.append(f"\n{title}")
        self.report.append("-" * 40)
        for row in data:
            self.report.append(str(row))
    
    def add_summary(self, checks_passed, checks_failed):
        self.report.append(f"\n\nSUMMARY")
        self.report.append("=" * 40)
        self.report.append(f"Checks Passed: {checks_passed}")
        self.report.append(f"Checks Failed: {checks_failed}")
        
        if checks_failed == 0:
            self.report.append("\n✓ MIGRATION VALIDATION PASSED")
        else:
            self.report.append("\n✗ MIGRATION VALIDATION FAILED")
    
    def save_report(self, filename):
        with open(filename, 'w') as f:
            f.write('\n'.join(self.report))
        return filename

# Generate report with:
# 1. Row counts for all tables
# 2. Checksum validation results
# 3. Foreign key validation results
# 4. Index comparison
# 5. Sequence status
# 6. LOB data validation
# 7. Stored procedure/function count
# 8. Trigger validation
```

---

## 8. Monitoring & Handling Errors

### 8.1 CloudWatch Metrics

#### 8.1.1 Key DMS Metrics

| Metric | Description | Normal Range | Alert Threshold |
|--------|-------------|--------------|-----------------|
| `CDCChangesDiskCache` | Changes cached on disk | 0 MB | > 1 GB |
| `CDCChangesMemoryCache` | Changes cached in memory | < 100 MB | > 500 MB |
| `CDCLatencySource` | CDC lag at source | 0-30 sec | > 300 sec |
| `CDCLatencyTarget` | CDC lag at target | 0-30 sec | > 300 sec |
| `CPUUtilization` | DMS instance CPU | < 70% | > 80% |
| `FreeStorageSpace` | DMS storage | > 20 GB | < 10 GB |
| `FullLoadThroughputBandwidthTarget` | MB/s to target | Varies | < 1 MB/s |
| `FullLoadThroughputRowsTarget` | Rows/s to target | Varies | 0 |
| `MemoryUtilization` | DMS memory usage | < 80% | > 90% |
| `NetworkBandwidthReceiptKbps` | Inbound network | Varies | < 100 Kbps |
| `NetworkBandwidthTransmitKbps` | Outbound network | Varies | < 100 Kbps |

#### 8.1.2 Key RDS Metrics

| Metric | Description | Normal Range | Alert Threshold |
|--------|-------------|--------------|-----------------|
| `ReadIOPS` | Read operations/sec | < 1000 | > 5000 |
| `WriteIOPS` | Write operations/sec | < 1000 | > 5000 |
| `ReadLatency` | Read latency (ms) | < 5 ms | > 20 ms |
| `WriteLatency` | Write latency (ms) | < 5 ms | > 20 ms |
| `DatabaseConnections` | Active connections | < 100 | > 400 |
| `CPUUtilization` | CPU usage | < 60% | > 80% |
| `FreeStorageSpace` | Free disk space | > 100 GB | < 50 GB |
| `NetworkReceiveThroughput` | Network in | < 50 MB/s | > 100 MB/s |
| `NetworkTransmitThroughput` | Network out | < 50 MB/s | > 100 MB/s |

### 8.2 DMS Task States

```
                    ┌─────────────────┐
                    │    CREATED      │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │    RUNNING      │
                    │  (Full Load)    │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              ▼              ▼
      ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
      │  LOAD        │ │  LOAD        │ │   ERROR      │
      │  COMPLETED   │ │  COMPLETED   │ │              │
      └──────┬───────┘ └──────┬───────┘ └──────────────┘
             │                │
             │  CDC Starts    │
             ▼                ▼
      ┌──────────────┐ ┌──────────────┐
      │   CDC        │ │   CDC        │
      │   REPLICATING│ │   SYNCED     │
      │   (Lagging)  │ │  (Zero Lag)  │
      └──────────────┘ └──────────────┘
                               │
                               ▼
                       ┌──────────────┐
                       │   STOPPED    │
                       │  (Complete)  │
                       └──────────────┘
```

### 8.3 Handling Replication Lag

#### 8.3.1 Identifying Lag

```bash
# Check lag via AWS CLI
aws dms describe-replication-task \
    --replication-task-arn <task-arn> \
    --query 'ReplicationTask.Status'

# Get detailed statistics
aws dms describe-table-statistics \
    --replication-task-arn <task-arn> \
    --output table
```

#### 8.3.2 Common Causes and Solutions

| Cause | Symptoms | Solution |
|-------|----------|----------|
| **Large transaction on source** | CDC lag increasing | Wait for transaction to commit |
| **Network latency** | Consistent lag | Increase bandwidth |
| **Target write bottleneck** | Target lag > Source lag | Increase instance size |
| **Lock contention** | Slow progress | Review target indexes |
| **LOB large size** | Slow LOB processing | Increase LOB chunk size |
| **Resource constraints** | High CPU/Memory | Scale DMS instance |

#### 8.3.3 Reducing Lag

```json
{
  "FullLoadSettings": {
    "MaxFullLoadSubTasks": 64,
    "CommitRate": 20000
  },
  "TargetMetadata": {
    "ParallelLoadBuffering": true,
    "ParallelLoadThreads": 32
  }
}
```

### 8.4 Identifying Data Truncation

#### 8.4.1 Warning Signs

- DMS task warnings in logs
- Validation failures
- Application errors after cutover

#### 8.4.2 Prevention and Detection

1. **Before Migration**: Review column sizes
```sql
-- SQL Server: Find columns that might truncate
SELECT 
    c.name AS column_name,
    t.name AS data_type,
    c.max_length,
    c.precision,
    c.scale
FROM sys.columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
WHERE c.max_length > 8000;
```

2. **During Migration**: Enable detailed logging
```json
{
  "Logging": {
    "EnableLogging": true,
    "LogComponents": [
      {
        "Id": "TARGET_LOAD",
        "Severity": "LOGGER_SEVERITY_DETAILED_DEBUG"
      }
    ]
  }
}
```

3. **After Migration**: Validate data
```sql
-- PostgreSQL: Check for truncated data
SELECT * FROM table 
WHERE LENGTH(column) > expected_max_length;
```

### 8.5 Resolving Type Conversion Failures

#### 8.5.1 Common Conversion Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `Invalid character value` | Collation mismatch | Check character encoding |
| `Numeric value out of range` | Precision loss | Change target column type |
| `Date/time out of range` | Date format | Use TIMESTAMP instead of DATE |
| `Boolean conversion failed` | BIT != BOOLEAN | Review BIT to BOOLEAN mapping |

#### 8.5.2 Handling Specific Errors

```sql
-- Fix: NVARCHAR to VARCHAR size
ALTER TABLE table_name 
ALTER COLUMN column_name TYPE VARCHAR(new_size);

-- Fix: Add missing timezone
ALTER TABLE table_name 
ALTER COLUMN column_name TYPE TIMESTAMPTZ;

-- Fix: Handle NULL in BOOLEAN
UPDATE table_name 
SET column_name = NULL 
WHERE column_name NOT IN ('0', '1', 'true', 'false');
```

### 8.6 Managing Long-Running Transactions

#### 8.6.1 Identifying Long Transactions

```sql
-- SQL Server: Find long-running transactions
SELECT 
    s.session_id,
    s.login_name,
    s.host_name,
    s.program_name,
    s.status,
    s.last_request_start_time,
    r.blocking_session_id,
    t.text AS query_text
FROM sys.dm_exec_sessions s
LEFT JOIN sys.dm_exec_requests r ON s.session_id = r.session_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t
WHERE s.is_user_process = 1
    AND s.status = 'running';
```

#### 8.6.2 Best Practices

1. **Schedule large transactions** during low-usage periods
2. **Break large batches** into smaller chunks
3. **Use bulk operations** instead of row-by-row
4. **Monitor actively** during migration

---

## 9. Cutover Strategy with Full Verification

### 9.1 Pre-Cutover Checklist (Completed Before Freeze)

- [ ] Full Load completed for all tables
- [ ] CDC latency < 60 seconds for at least 1 hour
- [ ] All schema objects converted and validated
- [ ] All row counts match (±0.01%)
- [ ] All foreign key validations pass
- [ ] All stored procedures/functions deployed and tested
- [ ] All triggers deployed and enabled
- [ ] Application team ready for cutover
- [ ] Rollback plan documented and tested
- [ ] Communication plan executed

### 9.2 Freeze Writes

#### Step 1: Coordinate with Application Team

```
Timeline:
T-24h: Send cutover notification
T-12h: Begin read-only testing
T-2h:  Final application backup
T-1h:  Disable write access (application-level)
T-0h:  Verify no writes occur
```

#### Step 2: Application-Level Freeze

```sql
-- SQL Server: Disable write access
-- Option 1: Revoke write permissions
REVOKE INSERT, UPDATE, DELETE ON schema::dbo TO application_user;

-- Option 2: Use application configuration
-- Set connection string to Read-Only

-- Option 3: Database-level (last resort)
ALTER DATABASE Mods SET READ_ONLY WITH ROLLBACK IMMEDIATE;
```

### 9.3 Confirm Zero CDC Lag

#### Step 3: Verify CDC is Caught Up

```bash
# Check CDC latency
aws dms describe-replication-task \
    --replication-task-arn <task-arn> \
    --query 'ReplicationTask.Status'

# Check in CloudWatch
# CDCLatencySource = 0
# CDCLatencyTarget = 0

# Alternative: Query DMS API
aws dms describe-table-statistics \
    --replication-task-arn <task-arn> \
    --output json | jq '.TableStatistics[] | {TableState: .TableState, ValidationState: .ValidationState}'
```

Expected result:
- `TableState` = "TableCompleted"
- `ValidationState` = "Validated" (if validation enabled)
- `CDCChangesPending` = 0

### 9.4 Final Validation Queries

#### Step 4: Run Final Validation

```sql
-- 1. Final row count check
SELECT 
    'Mods' AS database_name,
    COUNT(*) AS table_count,
    SUM(n_live_tup) AS total_rows
FROM pg_stat_user_tables
WHERE schemaname = 'public';

-- 2. Verify no pending changes
SELECT * FROM dms_validation_summary 
WHERE ValidationStatus != 'validated';

-- 3. Check for any errors in logs
-- CloudWatch → DMS → Errors
```

### 9.5 Application Connection String Change

#### Step 5: Update Application Configuration

**Before (SQL Server):**
```xml
<connectionStrings>
    <add name="Mods" 
         connectionString="Data Source=sqlserver.onprem.local;Initial Catalog=Mods;User ID=app_user;Password=***;"/>
    <add name="Modsdw" 
         connectionString="Data Source=sqlserver.onprem.local;Initial Catalog=Modsdw;User ID=app_user;Password=***;"/>
</connectionStrings>
```

**After (PostgreSQL):**
```xml
<connectionStrings>
    <add name="Mods" 
         connectionString="Host=postgres-mods.xxxx.us-east-1.rds.amazonaws.com;Port=5432;Database=mods;Username=app_user;Password=***;"/>
    <add name="Modsdw" 
         connectionString="Host=postgres-modsdw.xxxx.us-east-1.rds.amazonaws.com;Port=5432;Database=modsdw;Username=app_user;Password=***;"/>
</connectionStrings>
```

#### Step 6: Enable Write Access

```sql
-- PostgreSQL: Enable write access
-- Simply update connection string; PostgreSQL doesn't need
-- additional commands to enable writes
```

### 9.6 Smoke Testing

#### Step 7: Execute Smoke Tests

| Test | Expected Result | Status |
|------|-----------------|--------|
| Login to application | Success | |
| View customer list | Data loads | |
| Add new customer | Record saved | |
| Edit existing record | Changes persist | |
| Delete record | Record removed | |
| Run report | Report generates | |
| Check logs | No errors | |

### 9.7 Rollback Plan

#### Rollback Triggers (When to Rollback)

| Condition | Threshold | Action |
|-----------|-----------|--------|
| CDC Lag | > 30 min | Evaluate |
| Data Validation Failures | > 0.1% | Rollback |
| Application Errors | > 1% of requests | Rollback |
| Performance | > 3x slower | Rollback |

#### Rollback Procedure

```
If rollback required:

1. STOP all application connections to PostgreSQL

2. RE-ENABLE SQL Server access:
   ALTER DATABASE Mods SET READ_OFF;

3. RESTORE write permissions:
   GRANT INSERT, UPDATE, DELETE TO application_user;

4. REVERT connection strings to SQL Server

5. VERIFY application works against SQL Server

6. INVESTIGATE root cause

7. SCHEDULE retry
```

---

## 10. Performance Optimization & Cost Planning

### 10.1 Recommended Instance Classes

#### DMS Replication Instance

| Workload Size | Instance Class | vCPU | RAM | Notes |
|---------------|----------------|------|-----|-------|
| < 100GB | dms.r6g.xlarge | 4 | 32 GB | Minimum recommended |
| 100-200GB | dms.r6g.2xlarge | 8 | 64 GB | Standard for this project |
| 200-500GB | dms.r6g.4xlarge | 16 | 128 GB | Selected |
| > 500GB | dms.r6g.4xlarge + | 16+ | 128++ | Consider multiple instances |

#### RDS PostgreSQL (Mods - 120GB)

| Purpose | Instance Class | vCPU | RAM | Storage | Use Case |
|---------|----------------|------|-----|---------|----------|
| Development | db.r6g.xlarge | 4 | 32 GB | 200 GB gp3 | Testing |
| Production | db.r6g.4xlarge | 16 | 128 GB | 500 GB gp3 | Selected |
| Very High I/O | db.r6g.4xlarge | 16 | 128 GB | 500 GB io1 (10K IOPS) | Large queries |

#### RDS PostgreSQL (Modsdw - 40GB)

| Purpose | Instance Class | vCPU | RAM | Storage | Use Case |
|---------|----------------|------|-----|---------|----------|
| Development | db.r6g.large | 2 | 16 GB | 100 GB gp3 | Testing |
| Production | db.r6g.2xlarge | 8 | 64 GB | 200 GB gp3 | Selected |

### 10.2 Storage Type Selection

| Storage Type | Use Case | IOPS | Throughput | Cost |
|--------------|----------|------|-------------|------|
| **gp3** (Selected) | General purpose | 3,000 (configurable) | 125 MB/s | $0.08/GB |
| gp2 | Legacy | 3,000 (fixed) | 250 MB/s | $0.10/GB |
| io1 | High I/O | 64,000 (max) | 1,000 MB/s | $0.125/GB + $0.10/IOPS |
| io2 | Latest high I/O | 64,000 (max) | 1,000 MB/s | $0.10/GB + $0.08/IOPS |

**Selection Rationale:**
- gp3 provides best cost/performance for 160GB workload
- Can tune IOPS independently from storage size
- Sufficient for CDC write patterns

### 10.3 IOPS Planning

#### Calculation

```
Full Load Performance:
- Target: 40,000 rows/second
- Average row size: 200 bytes
- Required IOPS: (40,000 × 200) / 4096 = ~2,000 IOPS

CDC Performance:
- Peak writes: 5,000 rows/second
- Required IOPS: (5,000 × 200) / 4096 = ~250 IOPS

Total Peak IOPS: ~2,500 IOPS

Recommendation: 3,000 IOPS (gp3)
```

### 10.4 Parallel Load Configuration

```json
{
  "FullLoadSettings": {
    "MaxFullLoadSubTasks": 32,
    "CommitRate": 10000,
    "FastLoadSwapPhase": true
  },
  "TargetMetadata": {
    "ParallelLoadBuffering": true,
    "ParallelLoadThreads": 16
  }
}
```

| Parameter | Recommended Value | Notes |
|-----------|-------------------|-------|
| MaxFullLoadSubTasks | 32 | Parallel table loading |
| CommitRate | 10,000-20,000 | Rows per transaction |
| ParallelLoadThreads | 16-32 | Threads per table |
| ParallelLoadBuffering | true | Enable buffering |

### 10.5 Index Rebuild Timing

```sql
-- Create indexes AFTER full load, BEFORE CDC
-- This reduces full load time significantly

-- After full load completes:
CREATE INDEX CONCURRENTLY idx_table_column ON table(column);

-- For unique indexes:
CREATE UNIQUE INDEX CONCURRENTLY idx_table_unique ON table(column);
```

### 10.6 Cost Considerations

#### Monthly Cost Estimate

| Component | Configuration | Monthly Cost (US-East) |
|-----------|---------------|----------------------|
| **DMS** | | |
| Replication Instance | dms.r6g.4xlarge Multi-AZ | ~$1,200/month |
| Storage | 50 GB | ~$4/month |
| Data Transfer | ~500 GB | ~$45/month |
| **RDS (Mods)** | | |
| Instance | db.r6g.4xlarge Multi-AZ | ~$1,800/month |
| Storage | 500 GB gp3 (3K IOPS) | ~$40/month |
| **RDS (Modsdw)** | | |
| Instance | db.r6g.2xlarge Multi-AZ | ~$900/month |
| Storage | 200 GB gp3 (3K IOPS) | ~$16/month |
| **Networking** | | |
| NAT Gateway | 2 × $32/month | ~$64/month |
| Data Transfer | Variable | ~$100/month |
| **TOTAL** | | **~$4,169/month** |

#### Cost Optimization Tips

1. **Use dev instances for testing**: Dev RDS can use single-AZ
2. **Stop DMS when not needed**: Stop between migrations
3. **Use Reserved Instances**: 1-year commitment saves ~40%
4. **Right-size storage**: Don't over-provision
5. **Use S3 for scripts**: Free if < 5GB

---

## 11. Final Go-Live Checklist

### Pre-Cutover (24 Hours Before)

- [ ] **Schema Verification**
  - [ ] All tables created in PostgreSQL
  - [ ] All primary keys present
  - [ ] All foreign keys present
  - [ ] All indexes created
  - [ ] All sequences created and initialized
  - [ ] All views deployed and functional
  - [ ] All stored procedures deployed
  - [ ] All functions deployed
  - [ ] All triggers deployed and enabled
  - [ ] All constraints applied

- [ ] **Data Validation**
  - [ ] All row counts match (source vs target)
  - [ ] Checksum validation passed
  - [ ] Foreign key integrity verified
  - [ ] LOB data validated
  - [ ] No truncated data found

- [ ] **Migration Status**
  - [ ] Full Load completed (100%)
  - [ ] CDC lag < 60 seconds
  - [ ] No errors in DMS task
  - [ ] DMS validation passed

### Cutover Window

- [ ] **Application Freeze**
  - [ ] Application notified
  - [ ] Write access disabled (application level)
  - [ ] No active transactions in SQL Server
  - [ ] Final backup completed

- [ ] **Final Synchronization**
  - [ ] CDC latency confirmed at zero
  - [ ] All pending changes applied

- [ ] **Cutover Execution**
  - [ ] Connection strings updated
  - [ ] Write access enabled to PostgreSQL
  - [ ] Application restarted
  - [ ] Smoke tests executed

### Post-Cutover (24 Hours After)

- [ ] **Verification**
  - [ ] Application functioning normally
  - [ ] No errors in application logs
  - [ ] No errors in RDS PostgreSQL logs
  - [ ] No errors in CloudWatch
  - [ ] Performance acceptable

- [ ] **Monitoring**
  - [ ] CloudWatch dashboards active
  - [ ] Alarms configured
  - [ ] Team on-call

- [ ] **Documentation**
  - [ ] Migration report generated
  - [ ] Issues documented
  - [ ] Lessons learned recorded

### Rollback Readiness (Just in Case)

- [ ] **Rollback Plan Validated**
  - [ ] SQL Server backup available
  - [ ] Rollback procedure documented
  - [ ] Rollback tested (dry run)
  - [ ] Rollback authorized

---

## 12. SQL Server Specific Features Migration

### 12.1 Linked Servers

SQL Server linked servers allow querying remote data sources. PostgreSQL doesn't have a direct equivalent, but there are several migration strategies.

#### 12.1.1 Assessment and Inventory

```sql
-- SQL Server: Find all linked servers
SELECT 
    s.name AS linked_server_name,
    s.product,
    s.data_source,
    s.provider,
    s.catalog
FROM sys.servers s
WHERE s.server_id != 0
ORDER BY s.name;

-- Find all queries using linked servers
SELECT 
    OBJECT_NAME(object_id) AS object_name,
    definition
FROM sys.sql_modules
WHERE definition LIKE '%OPENQUERY%'
   OR definition LIKE '%EXECUTE%';
```

#### 12.1.2 Migration Strategies

| Strategy | Use Case | Implementation |
|----------|----------|----------------|
| **Foreign Data Wrapper (FDW)** | Cross-database queries | Use `postgres_fdw` extension |
| **dblink** | Ad-hoc remote queries | Use `dblink` extension |
| **Application-level** | Complex integrations | Move logic to application |
| **ETL Pipeline** | Data synchronization | Use AWS Glue or DMS |

#### 12.1.3 PostgreSQL FDW Implementation

```sql
-- Install postgres_fdw extension
CREATE EXTENSION IF NOT EXISTS postgres_fdw;

-- Create foreign server (for another PostgreSQL)
CREATE SERVER remote_mods
    FOREIGN DATA WRAPPER postgres_fdw
    OPTIONS (
        host 'remote-host.example.com',
        port '5432',
        dbname 'mods'
    );

-- Create user mapping
CREATE USER MAPPING FOR dbadmin
    SERVER remote_mods
    OPTIONS (
        user 'remote_user',
        password 'remote_password'
    );

-- Import foreign schema
IMPORT FOREIGN SCHEMA public
    FROM SERVER remote_mods
    INTO public;

-- Query remote table
SELECT * FROM remote_table LIMIT 100;
```

#### 12.1.4 Using dblink for Ad-Hoc Queries

```sql
-- Install dblink extension
CREATE EXTENSION IF NOT EXISTS dblink;

-- Query remote PostgreSQL
SELECT * 
FROM dblink(
    'host=remote.example.com dbname=mods user=user password=pass',
    'SELECT id, name FROM customer WHERE active = true'
) AS remote_data(
    id INTEGER,
    name VARCHAR(100)
);

-- Create wrapper function for easier access
CREATE OR REPLACE FUNCTION get_remote_customers()
RETURNS TABLE(
    id INTEGER,
    name VARCHAR(100)
) AS $
BEGIN
    RETURN QUERY
    SELECT * 
    FROM dblink(
        'host=remote.example.com dbname=mods user=user password=pass',
        'SELECT id, name FROM customer'
    ) AS remote_data(id INTEGER, name VARCHAR(100));
END;
$ LANGUAGE plpgsql;
```

### 12.2 SQL Server Integration Services (SSIS) Packages

SSIS packages handle ETL operations, data transformations, and workflow automation. Migration requires a different approach.

#### 12.2.1 SSIS Package Inventory

```sql
-- Find SSIS packages in MSDB
SELECT 
    p.name AS package_name,
    p.description,
    p.package_type,
    p.created_date,
    p.modified_date,
    s.folder_name
FROM msdb.dbo.sysssispackages p
JOIN msdb.dbo.sysssispackagesfolders s 
    ON p.folderid = s.folderid;

-- Find packages with specific tasks
SELECT 
    p.name AS package_name,
    pc.task_type,
    pc.task_name
FROM msdb.dbo.sysssispackages p
CROSS APPLY (
    SELECT 
        CAST(pc.object_data AS XML).value('(//@name)[1]', 'VARCHAR(100)') AS task_name,
        CAST(pc.object_data AS XML).value('(//@taskType)[1]', 'VARCHAR(50)') AS task_type
    FROM msdb.dbo.syspackagelog pc
    WHERE pc.package_id = p.package_id
) pc;
```

#### 12.2.2 Migration Options

| SSIS Component | PostgreSQL Equivalent | Migration Effort |
|----------------|----------------------|------------------|
| Data Flow Task | COPY, INSERT statements | Medium |
| Execute SQL Task | DO blocks, functions | Low |
| File System Task | `COPY` command, `pg_dump` | Low |
| Send Mail Task | `pg_email` extension, external script | Medium |
| Web Service Task | HTTP requests via `curl` or Python | Medium |
| Script Task | Python/Perl scripts | Medium |
| Lookup Transformation | JOIN with staging table | Low |
| Merge Join | SQL JOIN | Low |
| Conditional Split | CASE expressions | Low |
| Aggregate | GROUP BY, aggregate functions | Low |

#### 12.2.3 Example: SSIS Data Flow to PostgreSQL

**SSIS Package (Conceptual):**
```
Data Flow Task:
├── OLE DB Source (SQL Server)
│   └── SELECT CustomerID, Name, Email FROM Customer
├── Data Conversion
│   └── Convert NVARCHAR to VARCHAR
├── Derived Column
│   └── Add: CreatedDate = GETDATE()
└── OLE DB Destination
    └── PostgreSQL Customer table
```

**PostgreSQL Equivalent:**
```sql
-- Create staging table
CREATE TABLE staging_customer (
    customerid INTEGER,
    name VARCHAR(100),
    email VARCHAR(255),
    createddate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Load data from SQL Server via DMS or direct connection
-- Option 1: Use DMS to load to staging
-- Option 2: Use COPY command
COPY staging_customer(customerid, name, email)
FROM '/path/to/customer_data.csv'
WITH (FORMAT csv);

-- Transform and insert to target
INSERT INTO customer (customerid, name, email, createddate)
SELECT 
    customerid,
    name,
    email,
    COALESCE(createddate, CURRENT_TIMESTAMP)
FROM staging_customer
ON CONFLICT (customerid) DO UPDATE
SET name = EXCLUDED.name,
    email = EXCLUDED.email;

-- Clean up staging
TRUNCATE staging_customer;
```

#### 12.2.4 AWS Glue for Complex ETL

For complex SSIS packages, consider AWS Glue:

```python
# AWS Glue ETL Job (Python)
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext

# Create Spark and Glue context
sc = SparkContext()
glueContext = GlueContext(sc)

# Read from SQL Server (source)
source_df = glueContext.read.format("jdbc").option(
    "url", "jdbc:sqlserver://sqlserver:1433;databaseName=Mods"
).option("dbtable", "customer").option(
    "user", "username"
).option("password", "password").load()

# Transform data
transformed_df = source_df.withColumn(
    "createddate", 
    current_timestamp()
).withColumn(
    "name", 
    col("name").cast("string")
)

# Write to PostgreSQL
glueContext.write.from_catalog(
    frame=transformed_df,
    database="target_database",
    table_name="customer"
)
```

### 12.3 SQL Server Replication

SQL Server replication moves data between databases. PostgreSQL has different replication options.

#### 12.3.1 Replication Types in SQL Server

| Replication Type | Description | Migration Consideration |
|-----------------|-------------|------------------------|
| Snapshot | Full copy at point in time | Use DMS Full Load |
| Transactional | Near real-time changes | Use DMS CDC |
| Merge | Bidirectional sync | Custom solution needed |
| Peer-to-Peer | Multi-master | Not supported in PostgreSQL |

#### 12.3.2 Inventory Existing Replication

```sql
-- Find publications
SELECT 
    p.name AS publication_name,
    p.description,
    p.replication_type,
    p.immediate_sync,
    p.allow_anonymous
FROM distribution.dbo.MSpublications p;

-- Find subscriptions
SELECT 
    s.name AS subscriber_name,
    p.publication,
    s.status,
    s.sync_type
FROM distribution.dbo.MSsubscriptions s
JOIN distribution.dbo.MSpublications p 
    ON s.publication_id = p.publication_id;

-- Find replicated articles
SELECT 
    a.article,
    a.source_object,
    a.destination_object,
    a.filter
FROM distribution.dbo.MSarticles a;
```

#### 12.3.3 PostgreSQL Replication Options

| PostgreSQL Feature | Use Case | Configuration |
|-------------------|----------|---------------|
| **Streaming Replication** | Primary-Standby | Built-in, async |
| **Logical Replication** | Selective table replication | pub/sub model |
| **Physical Replication** | Full database copy | WAL shipping |
| **BDR (Bi-Directional)** | Multi-master | 3rd party extension |

#### 12.3.4 Setting Up PostgreSQL Logical Replication

```sql
-- On source (PostgreSQL acting as source for other systems)
-- Enable logical replication
ALTER SYSTEM SET wal_level = logical;
ALTER SYSTEM SET max_replication_slots = 10;
ALTER SYSTEM SET max_wal_senders = 10;

-- Reload configuration
SELECT pg_reload_conf();

-- Create publication
CREATE PUBLICATION mods_publication FOR ALL TABLES;

-- Create subscription (on target)
CREATE SUBSCRIPTION mods_subscription
    CONNECTION 'host=source-postgres port=5432 dbname=mods user=repl password=pass'
    PUBLICATION mods_publication;
```

### 12.4 SQL Server Agent Jobs

SQL Server Agent handles scheduled tasks. PostgreSQL uses different mechanisms.

#### 12.4.1 Job Inventory

```sql
-- List all jobs
SELECT 
    j.job_id,
    j.name AS job_name,
    j.description,
    j.enabled,
    j.category_id,
    j.date_created,
    j.date_modified
FROM msdb.dbo.sysjobs j
ORDER BY j.name;

-- Job steps
SELECT 
    j.name AS job_name,
    js.step_id,
    js.step_name,
    js.subsystem,
    js.command,
    js.database_name
FROM msdb.dbo.sysjobsteps js
JOIN msdb.dbo.sysjobs j ON js.job_id = j.job_id
ORDER BY j.name, js.step_id;

-- Job schedules
SELECT 
    j.name AS job_name,
    js.enabled,
    js.schedule_id,
    ss.name AS schedule_name,
    ss.freq_type,
    ss.freq_interval,
    ss.active_start_time
FROM msdb.dbo.sysjobschedules js
JOIN msdb.dbo.sysjobs j ON js.job_id = j.job_id
JOIN msdb.dbo.sysschedules ss ON js.schedule_id = ss.schedule_id;
```

#### 12.4.2 PostgreSQL Alternatives

| SQL Server Agent | PostgreSQL Alternative | Notes |
|-----------------|----------------------|-------|
| Job Scheduling | `pg_cron` extension | Cron-like scheduling |
| SQL Agent Service | `pgAgent` | Third-party |
| Alerts | Event triggers | Built-in |
| Operators | Notification system | Custom implementation |

#### 12.4.3 Using pg_cron

```sql
-- Install pg_cron extension
CREATE EXTENSION pg_cron;

-- Grant permissions
GRANT USAGE ON SCHEMA cron TO dbadmin;

-- Schedule a job (run daily at midnight)
SELECT cron.schedule(
    'daily-maintenance',
    '0 0 * * *',
    $VACUUM (VERBOSE, ANALYZE) $
);

-- Schedule a job (run every 5 minutes)
SELECT cron.schedule(
    'process-queue',
    '*/5 * * * *',
    $SELECT process_queue()$
);

-- Unschedule a job
SELECT cron.unschedule('daily-maintenance');

-- View job run history
SELECT * FROM cron.job_run_details 
ORDER BY start_time DESC 
LIMIT 20;
```

#### 12.4.4 Custom Job Scheduling with cron

```sql
-- Create a function to be scheduled
CREATE OR REPLACE FUNCTION daily_cleanup()
RETURNS void AS $
BEGIN
    -- Archive old records
    INSERT INTO audit_log_archive
    SELECT * FROM audit_log 
    WHERE created_date < NOW() - INTERVAL '90 days';
    
    DELETE FROM audit_log 
    WHERE created_date < NOW() - INTERVAL '90 days';
    
    -- Log completion
    RAISE NOTICE 'Daily cleanup completed at %', NOW();
END;
$ LANGUAGE plpgsql;

-- Create job schedule table
CREATE TABLE job_schedules (
    job_name VARCHAR(100) PRIMARY KEY,
    schedule VARCHAR(100) NOT NULL,
    function_name VARCHAR(100) NOT NULL,
    enabled BOOLEAN DEFAULT true,
    last_run TIMESTAMP,
    next_run TIMESTAMP
);

-- Insert job definition
INSERT INTO job_schedules (job_name, schedule, function_name)
VALUES 
    ('daily_cleanup', '0 2 * * *', 'daily_cleanup'),
    ('hourly_report', '0 * * * *', 'generate_hourly_report'),
    ('weekly_summary', '0 0 * * 0', 'generate_weekly_summary');
```

### 12.5 SQL Server Service Broker

Service Broker provides reliable messaging. PostgreSQL alternatives include:

#### 12.5.1 Migration Options

| SQL Server Feature | PostgreSQL Alternative |
|-------------------|----------------------|
| Service Broker | `pgmq` extension |
| Queue | PostgreSQL LISTEN/NOTIFY |
| Conversation | Message tables |

#### 12.5.2 Using LISTEN/NOTIFY

```sql
-- Enable notification
NOTIFY 'data_changed';

-- Listen for notifications
LISTEN data_changed;

-- Create trigger for notifications
CREATE OR REPLACE FUNCTION notify_customer_change()
RETURNS TRIGGER AS $
BEGIN
    PERFORM pg_notify(
        'customer_changed',
        JSON_BUILD_OBJECT(
            'operation', TG_OP,
            'table', TG_TABLE_NAME,
            'record', row_to_json(NEW)
        )::text
    );
    RETURN NEW;
END;
$ LANGUAGE plpgsql;

CREATE TRIGGER customer_notify
AFTER INSERT OR UPDATE ON customer
FOR EACH ROW
EXECUTE FUNCTION notify_customer_change();
```

### 12.6 SQL Server Full-Text Search

Full-text search in SQL Server differs from PostgreSQL.

#### 12.6.1 Migration Strategy

```sql
-- SQL Server: Create full-text index
CREATE FULLTEXT INDEX ON Customer
(
    Name LANGUAGE 1033,
    Description LANGUAGE 1033
) KEY INDEX PK_Customer
ON SearchCatalog
WITH (STOPLIST = SYSTEM);

-- SQL Server: Query using full-text search
SELECT * FROM Customer
WHERE CONTAINS(Name, 'John OR Smith');

-- PostgreSQL: Use tsvector and tsquery
-- Create GIN index
CREATE INDEX idx_customer_search 
ON customer 
USING GIN (to_tsvector('english', name || ' ' || COALESCE(description, '')));

-- Query using full-text search
SELECT * FROM customer
WHERE to_tsvector('english', name || ' ' || COALESCE(description, '')) 
    @@ to_tsquery('english', 'John | Smith');

-- More advanced search with ranking
SELECT 
    *,
    ts_rank(to_tsvector('english', name || ' ' || COALESCE(description, '')), 
            to_tsquery('english', 'John & Smith')) AS rank
FROM customer
WHERE to_tsvector('english', name || ' ' || COALESCE(description, '')) 
    @@ to_tsquery('english', 'John & Smith')
ORDER BY rank DESC;
```

### 12.7 SQL Server CLR Integration

CLR stored procedures and functions require complete rewrite.

#### 12.7.1 Assessment

```sql
-- Find CLR assemblies
SELECT 
    name AS assembly_name,
    create_date,
    modify_date,
    assembly_id
FROM sys.assemblies
WHERE is_user_defined = 1;

-- Find CLR procedures
SELECT 
    OBJECT_NAME(object_id) AS proc_name,
    assembly_name,
    assembly_class,
    assembly_method
FROM sys.assembly_modules;
```

#### 12.7.2 Migration Options

| CLR Feature | PostgreSQL Alternative |
|-------------|----------------------|
| Complex calculations | PL/pgSQL functions |
| String manipulation | String functions |
| File I/O | `COPY` command, `pg_read_file` |
| Network calls | External functions (Python, Perl) |
| Cryptography | `pgcrypto` extension |

### 12.8 Database Mail

SQL Server Database Mail sends emails. PostgreSQL alternatives:

```sql
-- Install pgsmtp extension or use external mail
-- Option 1: Use pg_email extension
CREATE EXTENSION pg_email;

-- Send email
SELECT pg_email.send(
    smtp_host => 'smtp.company.com',
    smtp_port => 587,
    smtp_user => 'noreply@company.com',
    smtp_password => 'password',
    from => 'noreply@company.com',
    to => 'user@company.com',
    subject => 'Alert: High CPU Usage',
    body => 'CPU usage exceeded 80%'
);

-- Option 2: Use external script
CREATE OR REPLACE FUNCTION send_alert(
    p_subject TEXT,
    p_message TEXT
) RETURNS void AS $
BEGIN
    PERFORM pg_catalog.pg_advisory_lock(1);
    PERFORM pg_catalog.pg_sleep(1);
    PERFORM pg_catalog.pg_advisory_unlock(1);
END;
$ LANGUAGE plpgsql;
```

---

## 13. Real-World T-SQL to PL/pgSQL Conversion Examples

### 13.1 Cursor Conversions

SQL Server cursors iterate row-by-row. PostgreSQL has several approaches, but set-based operations are preferred.

#### 13.1.1 Basic Cursor Conversion

```sql
-- T-SQL: Cursor Example
DECLARE @CustomerID INT;
DECLARE @CustomerName VARCHAR(100);
DECLARE customer_cursor CURSOR FOR
    SELECT CustomerID, CustomerName 
    FROM Customer 
    WHERE IsActive = 1;

OPEN customer_cursor;
FETCH NEXT FROM customer_cursor INTO @CustomerID, @CustomerName;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Process each customer
    PRINT 'Processing: ' + @CustomerName;
    
    -- Update last processed date
    UPDATE Customer 
    SET LastProcessedDate = GETDATE() 
    WHERE CustomerID = @CustomerID;
    
    FETCH NEXT FROM customer_cursor INTO @CustomerID, @CustomerName;
END

CLOSE customer_cursor;
DEALLOCATE customer_cursor;
```

```plsql
-- PostgreSQL: Set-based approach (preferred)
UPDATE customer
SET lastprocesseddate = CURRENT_TIMESTAMP
WHERE isactive = true;

-- If cursor is absolutely necessary, use FOR loop
DO $
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN 
        SELECT customerid, customername 
        FROM customer 
        WHERE isactive = true
    LOOP
        RAISE NOTICE 'Processing: %', rec.customername;
        
        UPDATE customer
        SET lastprocesseddate = CURRENT_TIMESTAMP
        WHERE customerid = rec.customerid;
    END LOOP;
END $;
```

#### 13.1.2 Cursor with Multiple Tables

```sql
-- T-SQL: Cursor across multiple tables
DECLARE @OrderID INT;
DECLARE @ProductID INT;
DECLARE @Quantity INT;

DECLARE order_cursor CURSOR FOR
    SELECT OrderID, ProductID, Quantity 
    FROM OrderDetails 
    WHERE OrderDate > '2024-01-01';

OPEN order_cursor;
FETCH NEXT FROM order_cursor INTO @OrderID, @ProductID, @Quantity;

WHILE @@FETCH_STATUS = 0
BEGIN
    UPDATE Inventory
    SET QuantityAvailable = QuantityAvailable - @Quantity
    WHERE ProductID = @ProductID;
    
    INSERT INTO InventoryLog (ProductID, ChangeAmount, ChangeDate)
    VALUES (@ProductID, -@Quantity, GETDATE());
    
    FETCH NEXT FROM order_cursor INTO @OrderID, @ProductID, @Quantity;
END

CLOSE order_cursor;
DEALLOCATE order_cursor;
```

```plsql
-- PostgreSQL: Set-based approach
UPDATE inventory i
SET quantityavailable = i.quantityavailable - od.quantity
FROM orderdetails od
WHERE i.productid = od.productid
    AND od.orderdate > '2024-01-01';

-- Log changes
INSERT INTO inventorylog (productid, changeamount, changedate)
SELECT od.productid, -od.quantity, CURRENT_TIMESTAMP
FROM orderdetails od
WHERE od.orderdate > '2024-01-01';
```

### 13.2 While Loop Conversions

#### 13.2.1 Simple Counter Loop

```sql
-- T-SQL: While loop with counter
DECLARE @Counter INT = 1;
DECLARE @MaxID INT;

SELECT @MaxID = MAX(CustomerID) FROM Customer;

WHILE @Counter <= @MaxID
BEGIN
    -- Process customer
    UPDATE Customer
    SET Status = 'Processed'
    WHERE CustomerID = @Counter
        AND Status = 'Pending';
    
    SET @Counter = @Counter + 1;
END
```

```plsql
-- PostgreSQL: Using generate_series
UPDATE customer
SET status = 'Processed'
WHERE customerid IN (
    SELECT generate_series(1, (SELECT MAX(customerid) FROM customer))
)
AND status = 'Pending';

-- Alternative: Using recursive CTE
WITH RECURSIVE counter AS (
    SELECT 1 AS customerid
    UNION ALL
    SELECT customerid + 1
    FROM counter
    WHERE customerid < (SELECT MAX(customerid) FROM customer)
)
UPDATE customer c
SET status = 'Processed'
FROM counter ct
WHERE c.customerid = ct.customerid
    AND c.status = 'Pending';
```

#### 13.2.2 While Loop with Batch Processing

```sql
-- T-SQL: Batch processing with while loop
DECLARE @BatchSize INT = 1000;
DECLARE @ProcessedCount INT = 0;
DECLARE @TotalCount INT;

SELECT @TotalCount = COUNT(*) FROM Customer WHERE Status = 'Pending';

WHILE @ProcessedCount < @TotalCount
BEGIN
    -- Process batch
    UPDATE TOP (@BatchSize) Customer
    SET Status = 'Processed', 
        ProcessedDate = GETDATE()
    WHERE Status = 'Pending';
    
    SET @ProcessedCount = @ProcessedCount + @@ROWCOUNT;
    
    -- Log progress
    PRINT 'Processed ' + CAST(@ProcessedCount AS VARCHAR) + ' of ' + CAST(@TotalCount AS VARCHAR);
END
```

```plsql
-- PostgreSQL: Batch processing using LIMIT
DO $
DECLARE
    v_batch_size INTEGER := 1000;
    v_affected INTEGER := 1;
BEGIN
    WHILE v_affected > 0 LOOP
        UPDATE customer
        SET status = 'Processed',
            processeddate = CURRENT_TIMESTAMP
        WHERE customerid IN (
            SELECT customerid
            FROM customer
            WHERE status = 'Pending'
            LIMIT v_batch_size
        );
        
        GET DIAGNOSTICS v_affected = ROW_COUNT;
        
        RAISE NOTICE 'Processed batch of % rows', v_affected;
    END LOOP;
END $;
```

### 13.3 Temporary Table Conversions

#### 13.3.1 Local Temporary Tables

```sql
-- T-SQL: Local temp table
CREATE TABLE #CustomerOrders (
    OrderID INT,
    CustomerName VARCHAR(100),
    OrderDate DATETIME,
    TotalAmount DECIMAL(18,2)
);

INSERT INTO #CustomerOrders
SELECT o.OrderID, c.CustomerName, o.OrderDate, o.TotalAmount
FROM Orders o
JOIN Customer c ON o.CustomerID = c.CustomerID
WHERE o.OrderDate > '2024-01-01';

SELECT * FROM #CustomerOrders WHERE TotalAmount > 1000;

DROP TABLE #CustomerOrders;
```

```plsql
-- PostgreSQL: Temporary table
CREATE TEMP TABLE customer_orders (
    orderid INTEGER,
    customername VARCHAR(100),
    orderdate TIMESTAMP,
    totalamount DECIMAL(18,2)
);

INSERT INTO customer_orders
SELECT o.orderid, c.customername, o.orderdate, o.totalamount
FROM orders o
JOIN customer c ON o.customerid = c.customerid
WHERE o.orderdate > '2024-01-01';

SELECT * FROM customer_orders WHERE totalamount > 1000;

-- Temp table automatically dropped at session end
-- Or explicitly:
DROP TABLE IF EXISTS customer_orders;
```

#### 13.3.2 Global Temporary Tables

```sql
-- T-SQL: Global temp table
CREATE TABLE ##GlobalConfig (
    ConfigKey VARCHAR(100),
    ConfigValue VARCHAR(500)
);

INSERT INTO ##GlobalConfig VALUES ('AppName', 'MyApp');
```

```plsql
-- PostgreSQL: Use unlogged table or permanent table
-- Option 1: Unlogged table (faster, lost on crash)
CREATE UNLOGGED TABLE global_config (
    configkey VARCHAR(100),
    configvalue VARCHAR(500)
);

-- Option 2: Permanent table with session identifier
CREATE TABLE global_config (
    configkey VARCHAR(100),
    configvalue VARCHAR(500),
    session_id VARCHAR(50)
);

-- Option 3: Use a schema for temp objects
CREATE SCHEMA IF NOT EXISTS temp_schema;
CREATE TEMP TABLE temp_schema.global_config (...);
```

#### 13.3.3 Temp Table for Complex Aggregation

```sql
-- T-SQL: Using temp table for complex logic
-- Step 1: Create and populate
SELECT 
    CustomerID,
    COUNT(*) AS OrderCount,
    SUM(TotalAmount) AS TotalSpent,
    AVG(TotalAmount) AS AvgOrderValue
INTO #CustomerStats
FROM Orders
WHERE OrderDate >= '2024-01-01'
GROUP BY CustomerID;

-- Step 2: Use in joins
SELECT 
    c.CustomerName,
    cs.OrderCount,
    cs.TotalSpent,
    cs.AvgOrderValue
FROM Customer c
JOIN #CustomerStats cs ON c.CustomerID = cs.CustomerID
WHERE cs.TotalSpent > 10000;

-- Step 3: Add more data
ALTER TABLE #CustomerStats ADD LastOrderDate DATETIME;

UPDATE cs
SET LastOrderDate = o.LastOrderDate
FROM #CustomerStats cs
JOIN (
    SELECT CustomerID, MAX(OrderDate) AS LastOrderDate
    FROM Orders
    GROUP BY CustomerID
) o ON cs.CustomerID = o.CustomerID;

DROP TABLE #CustomerStats;
```

```plsql
-- PostgreSQL: Use CTE or subquery (preferred)
WITH customer_stats AS (
    SELECT 
        customerid,
        COUNT(*) AS ordercount,
        SUM(totalamount) AS totalspent,
        AVG(totalamount) AS avgordervalue
    FROM orders
    WHERE orderdate >= '2024-01-01'
    GROUP BY customerid
),
last_orders AS (
    SELECT customerid, MAX(orderdate) AS lastorderdate
    FROM orders
    GROUP BY customerid
)
SELECT 
    c.customername,
    cs.ordercount,
    cs.totalspent,
    cs.avgordervalue,
    lo.lastorderdate
FROM customer c
JOIN customer_stats cs ON c.customerid = cs.customerid
JOIN last_orders lo ON c.customerid = lo.customerid
WHERE cs.totalspent > 10000;
```

### 13.4 Common Table Expressions (CTE) Conversions

#### 13.4.1 Simple CTE

```sql
-- T-SQL: Basic CTE
WITH CustomerOrders AS (
    SELECT 
        CustomerID,
        COUNT(*) AS OrderCount,
        SUM(TotalAmount) AS TotalSpent
    FROM Orders
    WHERE OrderDate >= '2024-01-01'
    GROUP BY CustomerID
)
SELECT 
    c.CustomerName,
    co.OrderCount,
    co.TotalSpent
FROM Customer c
JOIN CustomerOrders co ON c.CustomerID = co.CustomerID
WHERE co.TotalSpent > 5000;
```

```plsql
-- PostgreSQL: Identical syntax (CTEs work the same)
WITH customer_orders AS (
    SELECT 
        customerid,
        COUNT(*) AS ordercount,
        SUM(totalamount) AS totalspent
    FROM orders
    WHERE orderdate >= '2024-01-01'
    GROUP BY customerid
)
SELECT 
    c.customername,
    co.ordercount,
    co.totalspent
FROM customer c
JOIN customer_orders co ON c.customerid = co.customerid
WHERE co.totalspent > 5000;
```

#### 13.4.2 Recursive CTE

```sql
-- T-SQL: Organizational hierarchy
WITH EmployeeHierarchy AS (
    -- Base case: Top-level employees
    SELECT 
        EmployeeID,
        ManagerID,
        FirstName + ' ' + LastName AS FullName,
        1 AS Level
    FROM Employee
    WHERE ManagerID IS NULL
    
    UNION ALL
    
    -- Recursive case
    SELECT 
        e.EmployeeID,
        e.ManagerID,
        e.FirstName + ' ' + e.LastName,
        eh.Level + 1
    FROM Employee e
    JOIN EmployeeHierarchy eh ON e.ManagerID = eh.EmployeeID
)
SELECT * FROM EmployeeHierarchy
ORDER BY Level, ManagerID;
```

```plsql
-- PostgreSQL: Identical recursive CTE syntax
WITH RECURSIVE employee_hierarchy AS (
    -- Base case: Top-level employees
    SELECT 
        employeeid,
        managerid,
        firstname || ' ' || lastname AS fullname,
        1 AS level
    FROM employee
    WHERE managerid IS NULL
    
    UNION ALL
    
    -- Recursive case
    SELECT 
        e.employeeid,
        e.managerid,
        e.firstname || ' ' || e.lastname,
        eh.level + 1
    FROM employee e
    JOIN employee_hierarchy eh ON e.managerid = eh.employeeid
)
SELECT * FROM employee_hierarchy
ORDER BY level, managerid;
```

#### 13.4.3 Multiple CTEs in Sequence

```sql
-- T-SQL: Multiple CTEs chained together
WITH 
ActiveCustomers AS (
    SELECT CustomerID FROM Customer WHERE IsActive = 1
),
CustomerOrders AS (
    SELECT 
        o.CustomerID,
        SUM(o.TotalAmount) AS TotalSpent
    FROM Orders o
    WHERE o.CustomerID IN (SELECT CustomerID FROM ActiveCustomers)
    GROUP BY o.CustomerID
),
TopCustomers AS (
    SELECT CustomerID FROM CustomerOrders WHERE TotalSpent > 10000
)
SELECT 
    c.CustomerName,
    co.TotalSpent
FROM Customer c
JOIN CustomerOrders co ON c.CustomerID = co.CustomerID
WHERE c.CustomerID IN (SELECT CustomerID FROM TopCustomers);
```

```plsql
-- PostgreSQL: Same approach
WITH 
active_customers AS (
    SELECT customerid FROM customer WHERE isactive = true
),
customer_orders AS (
    SELECT 
        o.customerid,
        SUM(o.totalamount) AS totalspent
    FROM orders o
    WHERE o.customerid IN (SELECT customerid FROM active_customers)
    GROUP BY o.customerid
),
top_customers AS (
    SELECT customerid FROM customer_orders WHERE totalspent > 10000
)
SELECT 
    c.customername,
    co.totalspent
FROM customer c
JOIN customer_orders co ON c.customerid = co.customerid
WHERE c.customerid IN (SELECT customerid FROM top_customers);
```

### 13.5 Complex Stored Procedure Examples

#### 13.5.1 Procedure with Multiple Result Sets

```sql
-- T-SQL: Procedure returning multiple result sets
CREATE PROCEDURE GetCustomerReport
    @StartDate DATETIME,
    @EndDate DATETIME
AS
BEGIN
    -- Result Set 1: Customer summary
    SELECT 
        c.CustomerID,
        c.CustomerName,
        COUNT(o.OrderID) AS OrderCount,
        SUM(o.TotalAmount) AS TotalSpent
    FROM Customer c
    LEFT JOIN Orders o ON c.CustomerID = o.CustomerID 
        AND o.OrderDate BETWEEN @StartDate AND @EndDate
    GROUP BY c.CustomerID, c.CustomerName;
    
    -- Result Set 2: Order details
    SELECT 
        o.OrderID,
        c.CustomerName,
        o.OrderDate,
        o.TotalAmount,
        od.ProductID,
        od.Quantity,
        od.UnitPrice
    FROM Orders o
    JOIN Customer c ON o.CustomerID = c.CustomerID
    JOIN OrderDetails od ON o.OrderID = od.OrderID
    WHERE o.OrderDate BETWEEN @StartDate AND @EndDate;
    
    -- Result Set 3: Summary totals
    SELECT 
        COUNT(DISTINCT c.CustomerID) AS TotalCustomers,
        COUNT(o.OrderID) AS TotalOrders,
        SUM(o.TotalAmount) AS GrandTotal
    FROM Customer c
    LEFT JOIN Orders o ON c.CustomerID = o.CustomerID 
        AND o.OrderDate BETWEEN @StartDate AND @EndDate;
END;
```

```plsql
-- PostgreSQL: Use refcursor or return table
-- Option 1: Return multiple result sets using refcursor
CREATE OR REPLACE FUNCTION get_customer_report(
    p_start_date TIMESTAMP,
    p_end_date TIMESTAMP
)
RETURNS SETOF refcursor AS $
DECLARE
    result1 refcursor := 'customer_summary';
    result2 refcursor := 'order_details';
    result3 refcursor := 'grand_totals';
BEGIN
    -- Open first cursor: Customer summary
    OPEN result1 FOR
        SELECT 
            c.customerid,
            c.customername,
            COUNT(o.orderid) AS ordercount,
            COALESCE(SUM(o.totalamount), 0) AS totalspent
        FROM customer c
        LEFT JOIN orders o ON c.customerid = o.customerid 
            AND o.orderdate BETWEEN p_start_date AND p_end_date
        GROUP BY c.customerid, c.customername;
    
    RETURN NEXT result1;
    
    -- Open second cursor: Order details
    OPEN result2 FOR
        SELECT 
            o.orderid,
            c.customername,
            o.orderdate,
            o.totalamount,
            od.productid,
            od.quantity,
            od.unitprice
        FROM orders o
        JOIN customer c ON o.customerid = c.customerid
        JOIN orderdetails od ON o.orderid = od.orderid
        WHERE o.orderdate BETWEEN p_start_date AND p_end_date;
    
    RETURN NEXT result2;
    
    -- Open third cursor: Grand totals
    OPEN result3 FOR
        SELECT 
            COUNT(DISTINCT c.customerid) AS totalcustomers,
            COUNT(o.orderid) AS totalorders,
            COALESCE(SUM(o.totalamount), 0) AS grandtotal
        FROM customer c
        LEFT JOIN orders o ON c.customerid = o.customerid 
            AND o.orderdate BETWEEN p_start_date AND p_end_date;
    
    RETURN NEXT result3;
END;
$ LANGUAGE plpgsql;

-- Call in psql:
-- SELECT get_customer_report('2024-01-01', '2024-12-31');
-- FETCH ALL IN customer_summary;
-- FETCH ALL IN order_details;
-- FETCH ALL IN grand_totals;
```

#### 13.5.2 Procedure with Transaction Handling

```sql
-- T-SQL: Transaction with error handling
CREATE PROCEDURE TransferFunds
    @FromAccount INT,
    @ToAccount INT,
    @Amount DECIMAL(18,2)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Debit source account
        UPDATE Account
        SET Balance = Balance - @Amount
        WHERE AccountID = @FromAccount;
        
        -- Check balance
        IF (SELECT Balance FROM Account WHERE AccountID = @FromAccount) < 0
        BEGIN
            RAISERROR('Insufficient funds', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN -1;
        END
        
        -- Credit destination account
        UPDATE Account
        SET Balance = Balance + @Amount
        WHERE AccountID = @ToAccount;
        
        -- Log transaction
        INSERT INTO TransactionLog (FromAccount, ToAccount, Amount, TransactionDate)
        VALUES (@FromAccount, @ToAccount, @Amount, GETDATE());
        
        COMMIT TRANSACTION;
        RETURN 0;
        
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
        RETURN -1;
    END CATCH
END;
```

```plsql
-- PostgreSQL: Transaction with exception handling
CREATE OR REPLACE FUNCTION transfer_funds(
    p_from_account INTEGER,
    p_to_account INTEGER,
    p_amount DECIMAL(18,2)
)
RETURNS INTEGER AS $
DECLARE
    v_balance DECIMAL(18,2);
BEGIN
    -- Check source account exists
    IF NOT EXISTS (SELECT 1 FROM account WHERE accountid = p_from_account) THEN
        RAISE EXCEPTION 'Source account does not exist';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM account WHERE accountid = p_to_account) THEN
        RAISE EXCEPTION 'Destination account does not exist';
    END IF;
    
    -- Check balance
    SELECT balance INTO v_balance
    FROM account
    WHERE accountid = p_from_account
    FOR UPDATE;  -- Lock row
    
    IF v_balance < p_amount THEN
        RAISE EXCEPTION 'Insufficient funds: available=%, requested=%', v_balance, p_amount;
    END IF;
    
    -- Debit source account
    UPDATE account
    SET balance = balance - p_amount
    WHERE accountid = p_from_account;
    
    -- Credit destination account
    UPDATE account
    SET balance = balance + p_amount
    WHERE accountid = p_to_account;
    
    -- Log transaction
    INSERT INTO transactionlog (fromaccount, toaccount, amount, transactiondate)
    VALUES (p_from_account, p_to_account, p_amount, CURRENT_TIMESTAMP);
    
    RETURN 0;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE;
        RETURN -1;
END;
$ LANGUAGE plpgsql;

-- Example call
SELECT transfer_funds(1001, 1002, 500.00);
```

### 13.6 Table Variable Conversions

```sql
-- T-SQL: Table variable
DECLARE @OrderItems TABLE (
    ItemID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    Quantity INT,
    UnitPrice DECIMAL(18,2)
);

INSERT INTO @OrderItems
SELECT ItemID, ProductName, Quantity, UnitPrice
FROM OrderDetails
WHERE OrderID = 12345;

-- Use in JOIN
SELECT 
    o.OrderID,
    oi.ProductName,
    oi.Quantity,
    oi.UnitPrice,
    oi.Quantity * oi.UnitPrice AS LineTotal
FROM Orders o
JOIN @OrderItems oi ON 1=1
WHERE o.OrderID = 12345;
```

```plsql
-- PostgreSQL: Use temporary table or CTE
-- Option 1: Temp table
CREATE TEMP TABLE order_items (
    itemid INTEGER PRIMARY KEY,
    productname VARCHAR(100),
    quantity INTEGER,
    unitprice DECIMAL(18,2)
);

INSERT INTO temp_order_items
SELECT itemid, productname, quantity, unitprice
FROM orderdetails
WHERE orderid = 12345;

-- Use in JOIN
SELECT 
    o.orderid,
    oi.productname,
    oi.quantity,
    oi.unitprice,
    oi.quantity * oi.unitprice AS linetotal
FROM orders o
JOIN temp_order_items oi ON 1=1
WHERE o.orderid = 12345;

-- Option 2: Array of composite type
CREATE TYPE order_item AS (
    itemid INTEGER,
    productname VARCHAR(100),
    quantity INTEGER,
    unitprice DECIMAL(18,2)
);

-- Option 3: JSON (for passing to functions)
CREATE OR REPLACE FUNCTION process_order_items(p_order_id INTEGER)
RETURNS TABLE(
    itemid INTEGER,
    productname VARCHAR(100),
    quantity INTEGER,
    unitprice DECIMAL(18,2),
    linetotal DECIMAL(18,2)
) AS $
BEGIN
    RETURN QUERY
    SELECT 
        od.itemid,
        od.productname,
        od.quantity,
        od.unitprice,
        (od.quantity * od.unitprice)::DECIMAL(18,2) AS linetotal
    FROM orderdetails od
    WHERE od.orderid = p_order_id;
END;
$ LANGUAGE plpgsql;
```

### 13.7 Dynamic SQL Conversions

```sql
-- T-SQL: Dynamic SQL
CREATE PROCEDURE GetTableData
    @TableName VARCHAR(100),
    @ColumnName VARCHAR(100),
    @Value SQL_VARIANT
AS
BEGIN
    DECLARE @SQL NVARCHAR(MAX);
    
    SET @SQL = 'SELECT * FROM ' + QUOTENAME(@TableName) + 
               ' WHERE ' + QUOTENAME(@ColumnName) + ' = @Value';
    
    EXEC sp_executesql @SQL, 
        N'@Value SQL_VARIANT', 
        @Value = @Value;
END;
```

```plsql
-- PostgreSQL: Dynamic SQL using EXECUTE
CREATE OR REPLACE FUNCTION get_table_data(
    p_table_name VARCHAR,
    p_column_name VARCHAR,
    p_value ANYELEMENT
)
RETURNS SETOF RECORD AS $
DECLARE
    v_sql TEXT;
    v_rec RECORD;
BEGIN
    -- Validate table and column exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = p_table_name 
            AND column_name = p_column_name
    ) THEN
        RAISE EXCEPTION 'Invalid table or column name';
    END IF;
    
    -- Build dynamic SQL
    v_sql := 'SELECT * FROM ' || quote_ident(p_table_name) || 
             ' WHERE ' || quote_ident(p_column_name) || ' = $1';
    
    -- Execute dynamic query
    RETURN QUERY EXECUTE v_sql USING p_value;
END;
$ LANGUAGE plpgsql;

-- Usage
SELECT * FROM get_table_data('customer', 'customerid', 123) AS 
    (customerid INTEGER, customername VARCHAR, ...);
```

---

## 14. Complete Schema Migration Validation & Data Type Mapping

This section provides a comprehensive approach to validating schema migration for all 1,314 objects identified in the OdsObjectInfo.xlsx file.

### 14.1 Schema Migration Validation Framework

#### 14.1.1 Pre-Migration Data Collection (Source SQL Server)

Execute these queries against SQL Server to get complete schema metadata:

```sql
-- ============================================
-- 1. COLLECT ALL TABLE SCHEMAS
-- ============================================
SELECT 
    t.TABLE_SCHEMA AS SchemaName,
    t.TABLE_NAME AS TableName,
    c.COLUMN_NAME AS ColumnName,
    c.DATA_TYPE AS DataType,
    c.CHARACTER_MAXIMUM_LENGTH AS MaxLength,
    c.NUMERIC_PRECISION AS Precision,
    c.NUMERIC_SCALE AS Scale,
    c.IS_NULLABLE AS IsNullable,
    c.COLUMN_DEFAULT AS DefaultValue,
    CASE WHEN pk.COLUMN_NAME IS NOT NULL THEN 'YES' ELSE 'NO' END AS IsPrimaryKey
FROM INFORMATION_SCHEMA.TABLES t
INNER JOIN INFORMATION_SCHEMA.COLUMNS c 
    ON t.TABLE_SCHEMA = c.TABLE_SCHEMA 
    AND t.TABLE_NAME = c.TABLE_NAME
LEFT JOIN (
    SELECT ku.TABLE_SCHEMA, ku.TABLE_NAME, ku.COLUMN_NAME
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
    INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE ku
        ON tc.CONSTRAINT_NAME = ku.CONSTRAINT_NAME
    WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
) pk ON c.TABLE_SCHEMA = pk.TABLE_SCHEMA 
    AND c.TABLE_NAME = pk.TABLE_NAME 
    AND c.COLUMN_NAME = pk.COLUMN_NAME
WHERE t.TABLE_TYPE = 'BASE TABLE'
    AND t.TABLE_NAME NOT LIKE 'sys%'
ORDER BY t.TABLE_SCHEMA, t.TABLE_NAME, c.ORDINAL_POSITION;

-- ============================================
-- 2. COLLECT ALL CONSTRAINTS
-- ============================================
SELECT 
    tc.CONSTRAINT_SCHEMA AS SchemaName,
    tc.CONSTRAINT_NAME AS ConstraintName,
    tc.CONSTRAINT_TYPE AS ConstraintType,
    kcu.COLUMN_NAME AS ColumnName,
    tc.TABLE_NAME AS TableName,
    rc.UNIQUE_CONSTRAINT_SCHEMA AS RefSchema,
    rc.UNIQUE_CONSTRAINT_NAME AS RefConstraint,
    rc2.COLUMN_NAME AS RefColumn
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
    ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
LEFT JOIN INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS rc
    ON tc.CONSTRAINT_NAME = rc.CONSTRAINT_NAME
LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE rc2
    ON rc.UNIQUE_CONSTRAINT_NAME = rc2.CONSTRAINT_NAME
WHERE tc.TABLE_SCHEMA NOT IN ('sys', 'INFORMATION_SCHEMA')
ORDER BY tc.TABLE_NAME, tc.CONSTRAINT_TYPE;

-- ============================================
-- 3. COLLECT ALL INDEXES
-- ============================================
SELECT 
    SCHEMA_NAME(o.schema_id) AS SchemaName,
    o.name AS TableName,
    i.name AS IndexName,
    i.type_desc AS IndexType,
    i.is_unique AS IsUnique,
    i.is_primary_key AS IsPrimaryKey,
    ic.key_ordinal AS KeyOrdinal,
    COL_NAME(ic.object_id, ic.column_id) AS ColumnName
FROM sys.indexes i
INNER JOIN sys.objects o ON i.object_id = o.object_id
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
WHERE o.type = 'U'
    AND i.name NOT LIKE 'PK%'
ORDER BY o.name, i.name, ic.key_ordinal;

-- ============================================
-- 4. COLLECT ALL VIEWS
-- ============================================
SELECT 
    v.TABLE_SCHEMA AS SchemaName,
    v.TABLE_NAME AS ViewName,
    m.definition AS ViewDefinition
FROM INFORMATION_SCHEMA.VIEWS v
LEFT JOIN sys.sql_modules m 
    ON OBJECT_ID(v.TABLE_SCHEMA + '.' + v.TABLE_NAME) = m.object_id
ORDER BY v.TABLE_SCHEMA, v.TABLE_NAME;

-- ============================================
-- 5. COLLECT ALL PROCEDURES
-- ============================================
SELECT 
    r.ROUTINE_SCHEMA AS SchemaName,
    r.ROUTINE_NAME AS ProcedureName,
    r.ROUTINE_TYPE AS RoutineType,
    m.definition AS ProcedureDefinition,
    p.PARAMETER_NAME AS ParameterName,
    p.DATA_TYPE AS ParameterDataType,
    p.PARAMETER_MODE AS ParameterMode,
    p.ORDINAL_POSITION AS ParameterOrder
FROM INFORMATION_SCHEMA.ROUTINES r
LEFT JOIN sys.sql_modules m 
    ON OBJECT_ID(r.ROUTINE_SCHEMA + '.' + r.ROUTINE_NAME) = m.object_id
LEFT JOIN INFORMATION_SCHEMA.PARAMETERS p 
    ON r.ROUTINE_NAME = p.ROUTINE_NAME 
    AND r.ROUTINE_SCHEMA = p.SPECIFIC_SCHEMA
WHERE r.ROUTINE_TYPE IN ('PROCEDURE', 'FUNCTION')
    AND r.ROUTINE_SCHEMA NOT IN ('sys', 'INFORMATION_SCHEMA')
ORDER BY r.ROUTINE_SCHEMA, r.ROUTINE_NAME, p.ORDINAL_POSITION;

-- ============================================
-- 6. COLLECT ALL TRIGGERS
-- ============================================
SELECT 
    t.TABLE_SCHEMA AS TableSchema,
    t.TABLE_NAME AS TableName,
    tr.name AS TriggerName,
    tr.is_disabled AS IsDisabled,
    CASE tr.is_instead_of_trigger 
        WHEN 1 THEN 'INSTEAD OF' 
        ELSE 'AFTER' 
    END AS TriggerType,
    CASE 
        WHEN tr.parent_class = 0 THEN 'DATABASE'
        ELSE 'TABLE'
    END AS ParentClass,
    m.definition AS TriggerDefinition
FROM sys.triggers tr
INNER JOIN sys.tables t ON tr.parent_id = t.object_id
LEFT JOIN sys.sql_modules m ON tr.object_id = m.object_id
ORDER BY t.name, tr.name;
```

## 15. SQL Server Functions, Triggers & Stored Procedures Conversion

This section provides detailed conversion patterns for the 246 stored procedures, 8 functions, and 2 triggers identified in your databases from OdsObjectInfo.xlsx.

### 15.1 Stored Procedure Conversion Patterns

Based on your inventory, many procedures follow naming patterns like `spMerge*`, `spCapacityReport*`, and `spSumo*` used for data aggregation and ETL operations.

#### 15.1.1 Basic Stored Procedure with Parameters

```sql
-- T-SQL: Basic Stored Procedure
CREATE PROCEDURE spGetCustomerOrders
    @CustomerID INT,
    @StartDate DATETIME,
    @EndDate DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        o.OrderID,
        o.OrderDate,
        o.TotalAmount,
        c.CustomerName,
        c.Email
    FROM Orders o
    INNER JOIN Customer c ON o.CustomerID = c.CustomerID
    WHERE o.CustomerID = @CustomerID
        AND o.OrderDate BETWEEN @StartDate AND @EndDate
    ORDER BY o.OrderDate DESC;
END;
```

```plsql
-- PostgreSQL: Function-based approach (procedures in PostgreSQL 11+)
CREATE OR REPLACE PROCEDURE sp_get_customer_orders(
    p_customerid INTEGER,
    p_startdate TIMESTAMP,
    p_enddate TIMESTAMP
)
LANGUAGE plpgsql
AS $
BEGIN
    -- PostgreSQL procedures return results via SELECT
    -- Or use RETURN QUERY in functions instead
    SELECT 
        o.orderid,
        o.orderdate,
        o.totalamount,
        c.customername,
        c.email
    FROM orders o
    INNER JOIN customer c ON o.customerid = c.customerid
    WHERE o.customerid = p_customerid
        AND o.orderdate BETWEEN p_startdate AND p_enddate
    ORDER BY o.orderdate DESC;
END;
$;

-- Alternative: Use function (recommended for PostgreSQL)
CREATE OR REPLACE FUNCTION fn_get_customer_orders(
    p_customerid INTEGER,
    p_startdate TIMESTAMP,
    p_enddate TIMESTAMP
)
RETURNS TABLE(
    orderid INTEGER,
    orderdate TIMESTAMP,
    totalamount NUMERIC(18,2),
    customername VARCHAR(100),
    email VARCHAR(255)
)
LANGUAGE plpgsql
AS $
BEGIN
    RETURN QUERY
    SELECT 
        o.orderid,
        o.orderdate,
        o.totalamount,
        c.customername,
        c.email
    FROM orders o
    INNER JOIN customer c ON o.customerid = c.customerid
    WHERE o.customerid = p_customerid
        AND o.orderdate BETWEEN p_startdate AND p_enddate
    ORDER BY o.orderdate DESC;
END;
$;
```

#### 15.1.2 Stored Procedure with OUTPUT Parameters

```sql
-- T-SQL: Procedure with OUTPUT parameter
CREATE PROCEDURE spGetOrderCount
    @CustomerID INT,
    @OrderCount INT OUTPUT,
    @TotalAmount DECIMAL(18,2) OUTPUT
AS
BEGIN
    SELECT @OrderCount = COUNT(*), 
           @TotalAmount = SUM(TotalAmount)
    FROM Orders
    WHERE CustomerID = @CustomerID;
    
    RETURN 0;
END;

-- Execute with OUTPUT
DECLARE @Count INT, @Total MONEY;
EXEC spGetOrderCount @CustomerID = 100, @OrderCount = @Count OUTPUT, @TotalAmount = @Total OUTPUT;
SELECT @Count AS OrderCount, @Total AS TotalAmount;
```

```plsql
-- PostgreSQL: Using INOUT parameters
CREATE OR REPLACE PROCEDURE sp_get_order_count(
    p_customerid INTEGER,
    INOUT p_ordercount INTEGER DEFAULT 0,
    INOUT p_totalamount NUMERIC(18,2) DEFAULT 0
)
LANGUAGE plpgsql
AS $
BEGIN
    SELECT COUNT(*), COALESCE(SUM(totalamount), 0)
    INTO p_ordercount, p_totalamount
    FROM orders
    WHERE customerid = p_customerid;
END;
$;

-- Call in psql
DO $
DECLARE
    v_count INTEGER := 0;
    v_total NUMERIC(18,2) := 0;
BEGIN
    CALL sp_get_order_count(100, v_count, v_total);
    RAISE NOTICE 'Orders: %, Total: %', v_count, v_total;
END $;
```

#### 15.1.3 Data Merge Procedure (Common Pattern in Your DB)

```sql
-- T-SQL: spMerge pattern (common in your databases)
CREATE PROCEDURE spMergeRaveServerInfo
    @ServerName VARCHAR(100),
    @IPAddress VARCHAR(50),
    @Environment VARCHAR(50),
    @Active BIT
AS
BEGIN
    SET NOCOUNT ON;
    
    IF EXISTS (SELECT 1 FROM RaveServerInfo WHERE ServerName = @ServerName)
    BEGIN
        UPDATE RaveServerInfo
        SET IPAddress = @IPAddress,
            Environment = @Environment,
            Active = @Active,
            LastUpdated = GETDATE()
        WHERE ServerName = @ServerName;
    END
    ELSE
    BEGIN
        INSERT INTO RaveServerInfo (ServerName, IPAddress, Environment, Active, CreatedDate)
        VALUES (@ServerName, @IPAddress, @Environment, @Active, GETDATE());
    END
END;
```

```plsql
-- PostgreSQL: Use UPSERT (INSERT ... ON CONFLICT)
CREATE OR REPLACE PROCEDURE sp_merge_rave_server_info(
    p_servername VARCHAR(100),
    p_ipaddress VARCHAR(50),
    p_environment VARCHAR(50),
    p_active BOOLEAN
)
LANGUAGE plpgsql
AS $
BEGIN
    INSERT INTO rave_serverinfo (
        servername, ipaddress, environment, active, createddate, lastupdated
    )
    VALUES (
        p_servername, p_ipaddress, p_environment, p_active, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
    )
    ON CONFLICT (servername) DO UPDATE SET
        ipaddress = EXCLUDED.ipaddress,
        environment = EXCLUDED.environment,
        active = EXCLUDED.active,
        lastupdated = CURRENT_TIMESTAMP;
END;
$;

-- Call the procedure
CALL sp_merge_rave_server_info('Server01', '192.168.1.1', 'Production', true);
```

### 15.2 Function Conversion Patterns

Your databases have 8 functions (3 inline table-valued + 1 scalar in MODSDW, 3 inline table-valued + 1 scalar in MODS).

#### 15.2.1 Scalar Function

```sql
-- T-SQL: Scalar Function
CREATE FUNCTION fn_CalculateDiscount(
    @Amount DECIMAL(18,2),
    @DiscountPercent DECIMAL(5,2)
)
RETURNS DECIMAL(18,2)
AS
BEGIN
    RETURN @Amount - (@Amount * @DiscountPercent / 100);
END;

-- Usage
SELECT dbo.fn_CalculateDiscount(1000.00, 10.00);  -- Returns 900.00
```

```plsql
-- PostgreSQL: Scalar Function
CREATE OR REPLACE FUNCTION fn_calculate_discount(
    p_amount NUMERIC(18,2),
    p_discount_percent NUMERIC(5,2)
)
RETURNS NUMERIC(18,2)
AS $
BEGIN
    RETURN p_amount - (p_amount * p_discount_percent / 100);
END;
$ LANGUAGE plpgsql;

-- Usage
SELECT fn_calculate_discount(1000.00, 10.00);  -- Returns 900.00
```

#### 15.2.2 Table-Valued Function (Inline)

```sql
-- T-SQL: Inline Table-Valued Function
CREATE FUNCTION fn_GetOrdersByDateRange(
    @StartDate DATETIME,
    @EndDate DATETIME
)
RETURNS TABLE
AS
RETURN (
    SELECT OrderID, CustomerID, OrderDate, TotalAmount
    FROM Orders
    WHERE OrderDate BETWEEN @StartDate AND @EndDate
);

-- Usage
SELECT * FROM fn_GetOrdersByDateRange('2024-01-01', '2024-12-31');
```

```plsql
-- PostgreSQL: Table Function
CREATE OR REPLACE FUNCTION fn_get_orders_by_date_range(
    p_startdate TIMESTAMP,
    p_enddate TIMESTAMP
)
RETURNS TABLE(
    orderid INTEGER,
    customerid INTEGER,
    orderdate TIMESTAMP,
    totalamount NUMERIC(18,2)
)
AS $
BEGIN
    RETURN QUERY
    SELECT o.orderid, o.customerid, o.orderdate, o.totalamount
    FROM orders o
    WHERE o.orderdate BETWEEN p_startdate AND p_enddate;
END;
$ LANGUAGE plpgsql;

-- Usage
SELECT * FROM fn_get_orders_by_date_range('2024-01-01', '2024-12-31');
```

#### 15.2.3 Multi-Statement Table-Valued Function

```sql
-- T-SQL: Multi-Statement Table-Valued Function
CREATE FUNCTION fn_GetCustomerOrdersWithDetails(@CustomerID INT)
RETURNS @Orders TABLE (
    OrderID INT PRIMARY KEY,
    OrderDate DATETIME,
    TotalAmount MONEY,
    ItemCount INT,
    CustomerName VARCHAR(100)
)
AS
BEGIN
    INSERT INTO @Orders
    SELECT 
        o.OrderID,
        o.OrderDate,
        o.TotalAmount,
        (SELECT COUNT(*) FROM OrderDetails WHERE OrderID = o.OrderID) AS ItemCount,
        c.CustomerName
    FROM Orders o
    INNER JOIN Customer c ON o.CustomerID = c.CustomerID
    WHERE o.CustomerID = @CustomerID;
    
    RETURN;
END;
```

```plsql
-- PostgreSQL: Table Function with variable
CREATE OR REPLACE FUNCTION fn_get_customer_orders_with_details(p_customerid INTEGER)
RETURNS TABLE(
    orderid INTEGER,
    orderdate TIMESTAMP,
    totalamount NUMERIC(18,2),
    itemcount BIGINT,
    customername VARCHAR(100)
)
AS $
BEGIN
    RETURN QUERY
    SELECT 
        o.orderid,
        o.orderdate,
        o.totalamount,
        (SELECT COUNT(*) FROM orderdetails WHERE orderid = o.orderid)::BIGINT AS itemcount,
        c.customername
    FROM orders o
    INNER JOIN customer c ON o.customerid = c.customerid
    WHERE o.customerid = p_customerid;
END;
$ LANGUAGE plpgsql;
```

### 15.3 Trigger Conversion Patterns

Your databases have 2 triggers in MODS that need conversion.

#### 15.3.1 AFTER INSERT Trigger

```sql
-- T-SQL: AFTER INSERT Trigger
CREATE TRIGGER tr_InsertAuditLog
ON Customer
AFTER INSERT
AS
BEGIN
    INSERT INTO AuditLog (TableName, Action, RecordID, ActionDate, UserID)
    SELECT 'Customer', 'INSERT', CustomerID, GETDATE(), SUSER_SNAME()
    FROM inserted;
END;
```

```plsql
-- PostgreSQL: AFTER INSERT Trigger
CREATE OR REPLACE FUNCTION fn_trg_insert_auditlog()
RETURNS TRIGGER AS $
BEGIN
    INSERT INTO auditlog (tablename, action, recordid, actiondate, userid)
    VALUES ('customer', 'INSERT', NEW.customerid, CURRENT_TIMESTAMP, current_user);
    RETURN NEW;
END;
$ LANGUAGE plpgsql;

CREATE TRIGGER tr_insert_auditlog
AFTER INSERT ON customer
FOR EACH ROW
EXECUTE FUNCTION fn_trg_insert_auditlog();
```

#### 15.3.2 AFTER UPDATE Trigger

```sql
-- T-SQL: AFTER UPDATE Trigger
CREATE TRIGGER tr_UpdateCustomer
ON Customer
AFTER UPDATE
AS
BEGIN
    IF UPDATE(CustomerName) OR UPDATE(Email)
    BEGIN
        INSERT INTO CustomerChangeLog (CustomerID, FieldName, OldValue, NewValue, ChangeDate)
        SELECT i.CustomerID, 'Name', d.CustomerName, i.CustomerName, GETDATE()
        FROM inserted i
        INNER JOIN deleted d ON i.CustomerID = d.CustomerID
        WHERE d.CustomerName <> i.CustomerName;
        
        INSERT INTO CustomerChangeLog (CustomerID, FieldName, OldValue, NewValue, ChangeDate)
        SELECT i.CustomerID, 'Email', d.Email, i.Email, GETDATE()
        FROM inserted i
        INNER JOIN deleted d ON i.CustomerID = d.CustomerID
        WHERE d.Email <> i.Email;
    END
END;
```

```plsql
-- PostgreSQL: AFTER UPDATE Trigger
CREATE OR REPLACE FUNCTION fn_trg_update_customer()
RETURNS TRIGGER AS $
BEGIN
    IF NEW.customername <> OLD.customername THEN
        INSERT INTO customerchangelog 
            (customerid, fieldname, oldvalue, newvalue, changedate)
        VALUES 
            (NEW.customerid, 'Name', OLD.customername, NEW.customername, CURRENT_TIMESTAMP);
    END IF;
    
    IF NEW.email <> OLD.email THEN
        INSERT INTO customerchangelog 
            (customerid, fieldname, oldvalue, newvalue, changedate)
        VALUES 
            (NEW.customerid, 'Email', OLD.email, NEW.email, CURRENT_TIMESTAMP);
    END IF;
    
    RETURN NEW;
END;
$ LANGUAGE plpgsql;

CREATE TRIGGER tr_update_customer
AFTER UPDATE ON customer
FOR EACH ROW
EXECUTE FUNCTION fn_trg_update_customer();
```

#### 15.3.3 INSTEAD OF Trigger (For Views)

```sql
-- T-SQL: INSTEAD OF Trigger on View
CREATE TRIGGER tr_vw_Customer_INSERT
ON vw_Customer
INSTEAD OF INSERT
AS
BEGIN
    INSERT INTO Customer (CustomerName, Email, Phone)
    SELECT CustomerName, Email, Phone
    FROM inserted;
END;
```

```plsql
-- PostgreSQL: INSTEAD OF Trigger (PostgreSQL uses this for updatable views)
CREATE OR REPLACE FUNCTION fn_vw_customer_insert()
RETURNS TRIGGER AS $
BEGIN
    INSERT INTO customer (customername, email, phone)
    VALUES (NEW.customername, NEW.email, NEW.phone);
    RETURN NEW;
END;
$ LANGUAGE plpgsql;

CREATE TRIGGER tr_vw_customer_insert
INSTEAD OF INSERT ON vw_customer
FOR EACH ROW
EXECUTE FUNCTION fn_vw_customer_insert();
```

### 15.4 Conversion Pattern Summary

| T-SQL Feature | PostgreSQL Equivalent | Notes |
|--------------|---------------------|-------|
| `CREATE PROCEDURE` | `CREATE PROCEDURE` | PostgreSQL 11+ supports procedures |
| `OUTPUT parameter` | `INOUT parameter` | Use INOUT for output |
| `RETURN` (in procedure) | Not used | Use OUTPUT parameters or RETURN QUERY |
| `SET NOCOUNT ON` | Not needed | Default behavior in PostgreSQL |
| `CREATE FUNCTION` | `CREATE FUNCTION` | Same syntax |
| `RETURNS TABLE` | `RETURNS TABLE` | Same concept |
| `RETURNS @table` | Use RETURNS TABLE | Different syntax |
| `CREATE TRIGGER` | `CREATE TRIGGER` | Slightly different syntax |
| `AFTER/BEFORE INSERT` | `AFTER/BEFORE INSERT` | Same concept |
| `INSTEAD OF` | `INSTEAD OF` | Same concept |
| `inserted` table | `NEW` variable | Trigger context |
| `deleted` table | `OLD` variable | Trigger context |
| `@@ERROR` | `GET DIAGNOSTICS` | Error handling |
| `RAISERROR` | `RAISE EXCEPTION` | Error raising |

### 15.5 Migration Priority for Your Objects

Based on your object inventory:

| Object Type | Count | Priority | Complexity |
|------------|-------|----------|------------|
| spMerge* procedures | ~180 | High | Medium |
| spCapacityReport* | ~50 | Medium | Low |
| spSumo* procedures | ~50 | Medium | Medium |
| Diagram procedures | 10 | Low | Low |
| Inline Table-Valued Functions | 6 | High | Medium |
| Scalar Functions | 2 | High | Low |
| Triggers | 2 | High | Medium |

---

### 14.2 SQL Server to PostgreSQL Data Type Mapping Matrix

Based on the actual column types found in your databases, here is the complete mapping:

#### 14.2.1 Numeric Types

| SQL Server Type | PostgreSQL Type | Example Conversion | Notes |
|----------------|-----------------|-------------------|-------|
| `BIGINT` | `BIGINT` | Direct mapping | 8-byte integer |
| `INT` | `INTEGER` | Direct mapping | 4-byte integer |
| `SMALLINT` | `SMALLINT` | Direct mapping | 2-byte integer |
| `TINYINT` | `SMALLINT` | Range: 0-255 | Use SMALLINT as TINYINT |
| `BIT` | `BOOLEAN` | 0=false, 1=true | Use BOOLEAN |
| `DECIMAL(p,s)` | `NUMERIC(p,s)` | Direct mapping | Exact numeric |
| `NUMERIC(p,s)` | `NUMERIC(p,s)` | Direct mapping | Exact numeric |
| `MONEY` | `NUMERIC(19,4)` | Use NUMERIC | MONEY has rounding issues |
| `SMALLMONEY` | `NUMERIC(10,4)` | Use NUMERIC | |
| `FLOAT` | `DOUBLE PRECISION` | 8-byte float | |
| `FLOAT(n)` | `DOUBLE PRECISION` | When n>24 | |
| `REAL` | `REAL` | 4-byte float | |

#### 14.2.2 Date/Time Types

| SQL Server Type | PostgreSQL Type | Example Conversion | Notes |
|----------------|-----------------|-------------------|-------|
| `DATETIME` | `TIMESTAMP(3)` | Millisecond precision | Range: 1753-9999 |
| `DATETIME2(n)` | `TIMESTAMP(n)` | Up to 6 decimals | n=0-7 |
| `DATETIMEOFFSET` | `TIMESTAMPTZ` | Timezone aware | Use TIMESTAMPTZ |
| `DATE` | `DATE` | Direct mapping | Date only |
| `TIME(n)` | `TIME(n)` | Up to 6 decimals | Time only |
| `SMALLDATETIME` | `TIMESTAMP(0)` | Minute precision | Range: 1900-2079 |

#### 14.2.3 String Types

| SQL Server Type | PostgreSQL Type | Example Conversion | Notes |
|----------------|-----------------|-------------------|-------|
| `CHAR(n)` | `CHAR(n)` | Fixed length | |
| `VARCHAR(n)` | `VARCHAR(n)` | Variable length | |
| `VARCHAR(MAX)` | `TEXT` | Use TEXT | No length limit |
| `NVARCHAR(n)` | `VARCHAR(n)` | Unicode | n is in characters |
| `NVARCHAR(MAX)` | `TEXT` | Use TEXT | Unicode |
| `NCHAR(n)` | `CHAR(n)` | Fixed Unicode | |
| `NTEXT` | `TEXT` | Use TEXT | Deprecated |
| `TEXT` | `TEXT` | Direct mapping | Deprecated |
| `XML` | `XML` | Direct mapping | |

#### 14.2.4 Binary Types

| SQL Server Type | PostgreSQL Type | Example Conversion | Notes |
|----------------|-----------------|-------------------|-------|
| `BINARY(n)` | `BYTEA` | Fixed bytes | |
| `VARBINARY(n)` | `BYTEA` | Variable bytes | |
| `VARBINARY(MAX)` | `BYTEA` | Use BYTEA | Binary LOB |
| `IMAGE` | `BYTEA` | Use BYTEA | Deprecated |
| `TIMESTAMP` | `BYTEA` | Row version | Not a date |

#### 14.2.5 Special Types

| SQL Server Type | PostgreSQL Type | Example Conversion | Notes |
|----------------|-----------------|-------------------|-------|
| `UNIQUEIDENTIFIER` | `UUID` | Use UUID | GUID type |
| `GEOGRAPHY` | PostGIS `GEOGRAPHY` | Install PostGIS | Spatial |
| `GEOMETRY` | PostGIS `GEOMETRY` | Install PostGIS | Spatial |
| `HIERARCHYID` | Custom | Not supported | Use recursive CTE |
| `SQL_VARIANT` | Custom | Not supported | Use specific type |

### 14.3 Validation Scripts for All Object Types

#### 14.3.1 Table Structure Validation

```sql
-- PostgreSQL: Validate all tables exist
SELECT 'Tables Validation' AS ValidationCheck,
    (SELECT COUNT(*) FROM information_schema.tables 
     WHERE table_schema = 'public' AND table_type = 'BASE TABLE') AS Expected,
    (SELECT COUNT(*) FROM information_schema.tables 
     WHERE table_schema = 'public' AND table_type = 'BASE TABLE') AS Actual,
    CASE WHEN (SELECT COUNT(*) FROM information_schema.tables 
               WHERE table_schema = 'public' AND table_type = 'BASE TABLE') = 369
         THEN 'PASS' ELSE 'FAIL' END AS Status;

-- Validate each table has columns
SELECT 
    t.table_name,
    COUNT(c.column_name) AS column_count
FROM information_schema.tables t
LEFT JOIN information_schema.columns c 
    ON t.table_name = c.table_name 
    AND t.table_schema = c.table_schema
WHERE t.table_schema = 'public'
    AND t.table_type = 'BASE TABLE'
GROUP BY t.table_name
HAVING COUNT(c.column_name) = 0;

-- Validate column data types match expected
SELECT 
    table_name,
    column_name,
    data_type,
    character_maximum_length,
    numeric_precision,
    numeric_scale
FROM information_schema.columns
WHERE table_schema = 'public'
ORDER BY table_name, ordinal_position;
```

#### 14.3.2 Primary Key Validation

```sql
-- PostgreSQL: Validate all primary keys
SELECT 
    tc.table_name,
    kcu.column_name,
    tc.constraint_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
    ON tc.constraint_name = kcu.constraint_name
    AND tc.table_schema = kcu.table_schema
WHERE tc.constraint_type = 'PRIMARY KEY'
    AND tc.table_schema = 'public'
ORDER BY tc.table_name;

-- Expected: 247 primary keys (83 MODSDW + 164 MODS)
SELECT COUNT(*) AS primary_key_count
FROM information_schema.table_constraints
WHERE constraint_type = 'PRIMARY KEY'
    AND table_schema = 'public';
```

#### 14.3.3 Foreign Key Validation

```sql
-- PostgreSQL: Validate all foreign keys
SELECT 
    tc.table_name AS child_table,
    kcu.column_name AS child_column,
    ccu.table_name AS parent_table,
    ccu.column_name AS parent_column,
    tc.constraint_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
    ON tc.constraint_name = kcu.constraint_name
    AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage ccu 
    ON rc.unique_constraint_name = ccu.constraint_name
JOIN information_schema.referential_constraints rc
    ON tc.constraint_name = rc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
    AND tc.table_schema = 'public'
ORDER BY tc.table_name;

-- Expected: 221 foreign keys (59 MODSDW + 162 MODS)
SELECT COUNT(*) AS foreign_key_count
FROM information_schema.table_constraints
WHERE constraint_type = 'FOREIGN KEY'
    AND table_schema = 'public';
```

#### 14.3.4 Index Validation

```sql
-- PostgreSQL: List all indexes
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- Find missing indexes (indexes not on primary/unique constraints)
SELECT 
    t.table_name,
    i.indexname
FROM pg_indexes i
INNER JOIN information_schema.tables t 
    ON i.tablename = t.table_name
WHERE i.schemaname = 'public'
    AND t.table_schema = 'public'
    AND i.indexname NOT LIKE '%_pkey'
    AND i.indexname NOT LIKE '%_unique'
ORDER BY i.tablename;
```

#### 14.3.5 View Validation

```sql
-- PostgreSQL: Validate all views
SELECT 
    table_name,
    view_definition
FROM information_schema.views
WHERE table_schema = 'public'
ORDER BY table_name;

-- Expected: 182 views (76 MODSDW + 106 MODS)
SELECT COUNT(*) AS view_count
FROM information_schema.views
WHERE table_schema = 'public';

-- Test each view can be queried
DO $
DECLARE
    v_view RECORD;
    v_sql TEXT;
    v_error TEXT;
BEGIN
    FOR v_view IN 
        SELECT table_name 
        FROM information_schema.views 
        WHERE table_schema = 'public'
    LOOP
        BEGIN
            v_sql := 'SELECT 1 FROM ' || v_view.table_name || ' LIMIT 1';
            EXECUTE v_sql;
        EXCEPTION WHEN OTHERS THEN
            RAISE WARNING 'View % failed: %', v_view.table_name, SQLERRM;
        END;
    END LOOP;
END $;
```

#### 14.3.6 Stored Procedure & Function Validation

```sql
-- PostgreSQL: List all functions/procedures
SELECT 
    routine_name,
    routine_type,
    data_type AS return_type,
    routine_definition
FROM information_schema.routines
WHERE routine_schema = 'public'
    AND routine_type IN ('FUNCTION', 'PROCEDURE')
ORDER BY routine_name;

-- Expected: 254 (111 MODSDW procedures + 135 MODS procedures + 8 functions)
SELECT routine_type, COUNT(*)
FROM information_schema.routines
WHERE routine_schema = 'public'
GROUP BY routine_type;

-- Test each function compiles correctly
SELECT 
    p.oid,
    p.proname AS function_name,
    pg_get_functiondef(p.oid) AS definition,
    CASE WHEN pg_get_functiondef(p.oid) IS NOT NULL 
         THEN 'VALID' ELSE 'INVALID' END AS status
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
    AND p.prokind = 'f';
```

#### 14.3.7 Trigger Validation

```sql
-- PostgreSQL: List all triggers
SELECT 
    t.tgname AS trigger_name,
    c.relname AS table_name,
    p.proname AS function_name,
    CASE t.tgtype & 1
        WHEN 1 THEN 'ROW'
        ELSE 'STATEMENT'
    END AS level,
    CASE t.tgtype & 66
        WHEN 2 THEN 'BEFORE'
        WHEN 64 THEN 'INSTEAD OF'
        ELSE 'AFTER'
    END AS action_timing,
    CASE 
        WHEN t.tgtype & 4 = 4 THEN 'INSERT'
        WHEN t.tgtype & 8 = 8 THEN 'DELETE'
        WHEN t.tgtype & 16 = 16 THEN 'UPDATE'
    END AS event_manipulation
FROM pg_trigger t
JOIN pg_class c ON t.tgrelid = c.oid
JOIN pg_proc p ON t.tgfoid = p.oid
WHERE NOT t.tgisinternal
    AND c.relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public');

-- Expected: 2 triggers (from MODS)
SELECT COUNT(*) AS trigger_count
FROM pg_trigger t
JOIN pg_class c ON t.tgrelid = c.oid
WHERE NOT t.tgisinternal
    AND c.relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public');
```

#### 14.3.8 Default Constraint Validation

```sql
-- PostgreSQL: List default values
SELECT 
    table_name,
    column_name,
    column_default,
    is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
    AND column_default IS NOT NULL
ORDER BY table_name, column_name;

-- Expected: 36 default constraints (6 MODSDW + 30 MODS)
SELECT COUNT(*) AS default_count
FROM information_schema.columns
WHERE table_schema = 'public'
    AND column_default IS NOT NULL;
```

### 14.4 Comprehensive Validation Checklist

#### Phase 1: Object Existence Validation

| Object Type | SQL Server Count | PostgreSQL Count | Status |
|-------------|-----------------|-----------------|--------|
| Tables | 369 | | |
| Primary Keys | 247 | | |
| Foreign Keys | 221 | | |
| Views | 182 | | |
| Stored Procedures | 246 | | |
| Functions | 8 | | |
| Triggers | 2 | | |
| Default Constraints | 36 | | |

#### Phase 2: Data Type Validation

```sql
-- Run this for each table to validate types
-- Example: Validate CapacityStats table
SELECT 
    'Column Type Validation: CapacityStats' AS check_name,
    CASE WHEN 
        -- All columns should match expected types
        COUNT(*) = (SELECT COUNT(*) FROM information_schema.columns 
                    WHERE table_name = 'CapacityStats' 
                    AND table_schema = 'public')
    THEN 'PASS' ELSE 'FAIL' END AS status;
```

#### Phase 3: Data Integrity Validation

```sql
-- Verify no orphaned foreign keys
SELECT 
    tc.table_name AS table_with_orphan,
    kcu.column_name AS orphan_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
    ON tc.constraint_name = kcu.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
    AND tc.table_schema = 'public'
    AND NOT EXISTS (
        SELECT 1 
        FROM information_schema.table_constraints tc2
        JOIN information_schema.key_column_usage kcu2
            ON tc2.constraint_name = kcu2.constraint_name
        WHERE tc2.constraint_type = 'PRIMARY KEY'
            AND kcu2.column_name = kcu.column_name
    );
```

#### Phase 4: Functional Validation

```sql
-- Test all views return data
DO $
DECLARE
    v_view RECORD;
    v_count INTEGER;
BEGIN
    FOR v_view IN 
        SELECT table_name FROM information_schema.views 
        WHERE table_schema = 'public'
    LOOP
        EXECUTE 'SELECT COUNT(*) FROM ' || v_view.table_name 
        INTO v_count;
        RAISE NOTICE 'View % has % rows', v_view.table_name, v_count;
    END LOOP;
END $;

-- Test all functions can be called
SELECT 
    routine_name,
    routine_type,
    CASE 
        WHEN routine_type = 'FUNCTION' THEN 'OK'
        ELSE 'NEEDS TEST'
    END AS test_status
FROM information_schema.routines
WHERE routine_schema = 'public';
```

### 14.5 Automated Validation Script

Create a comprehensive validation script:

```python
#!/usr/bin/env python3
"""
Comprehensive Schema Migration Validation Script
Validates all 1,314 objects from SQL Server to PostgreSQL
"""
import psycopg2
from datetime import datetime

# Connect to PostgreSQL
conn = psycopg2.connect(
    host='postgres-mods.xxxx.rds.amazonaws.com',
    database='mods',
    user='dbadmin',
    password='password'
)
cur = conn.cursor()

validation_results = []

def validate_count(description, expected, actual):
    """Validate count matches expected"""
    status = 'PASS' if expected == actual else 'FAIL'
    validation_results.append({
        'description': description,
        'expected': expected,
        'actual': actual,
        'status': status
    })
    print(f"{description}: Expected={expected}, Actual={actual}, Status={status}")

# 1. Validate Tables
cur.execute("""
    SELECT COUNT(*) 
    FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
""")
table_count = cur.fetchone()[0]
validate_count('Tables', 369, table_count)

# 2. Validate Primary Keys
cur.execute("""
    SELECT COUNT(*) 
    FROM information_schema.table_constraints 
    WHERE constraint_type = 'PRIMARY KEY' AND table_schema = 'public'
""")
pk_count = cur.fetchone()[0]
validate_count('Primary Keys', 247, pk_count)

# 3. Validate Foreign Keys
cur.execute("""
    SELECT COUNT(*) 
    FROM information_schema.table_constraints 
    WHERE constraint_type = 'FOREIGN KEY' AND table_schema = 'public'
""")
fk_count = cur.fetchone()[0]
validate_count('Foreign Keys', 221, fk_count)

# 4. Validate Views
cur.execute("""
    SELECT COUNT(*) 
    FROM information_schema.views 
    WHERE table_schema = 'public'
""")
view_count = cur.fetchone()[0]
validate_count('Views', 182, view_count)

# 5. Validate Procedures/Functions
cur.execute("""
    SELECT COUNT(*) 
    FROM information_schema.routines 
    WHERE routine_schema = 'public' 
    AND routine_type IN ('PROCEDURE', 'FUNCTION')
""")
proc_count = cur.fetchone()[0]
validate_count('Procedures/Functions', 254, proc_count)

# 6. Validate Triggers
cur.execute("""
    SELECT COUNT(*) 
    FROM pg_trigger t
    JOIN pg_class c ON t.tgrelid = c.oid
    WHERE NOT t.tgisinternal
    AND c.relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public')
""")
trigger_count = cur.fetchone()[0]
validate_count('Triggers', 2, trigger_count)

# Generate summary
passed = sum(1 for r in validation_results if r['status'] == 'PASS')
failed = sum(1 for r in validation_results if r['status'] == 'FAIL')

print(f"\n=== VALIDATION SUMMARY ===")
print(f"Passed: {passed}")
print(f"Failed: {failed}")
print(f"Total: {len(validation_results)}")

# Save to file
with open('validation_report.txt', 'w') as f:
    f.write(f"Schema Migration Validation Report\n")
    f.write(f"Generated: {datetime.now()}\n")
    f.write("=" * 60 + "\n\n")
    for r in validation_results:
        f.write(f"{r['description']}: {r['status']}\n")
        if r['status'] == 'FAIL':
            f.write(f"  Expected: {r['expected']}, Got: {r['actual']}\n")

cur.close()
conn.close()

print("\nValidation report saved to validation_report.txt")
```

---

## Appendix A: Complete Object Inventory (From OdsObjectInfo.xlsx)

### A.1 MODSDW Database Summary (497 Objects)

| Object Type | Count | Migration Method |
|-------------|-------|------------------|
| USER_TABLE | 157 | DMS Full Load |
| SQL_STORED_PROCEDURE | 111 | Manual (PL/pgSQL) |
| PRIMARY_KEY_CONSTRAINT | 83 | DMS (auto-convert) |
| VIEW | 76 | Manual (CREATE VIEW) |
| FOREIGN_KEY_CONSTRAINT | 59 | DMS (auto-convert) |
| DEFAULT_CONSTRAINT | 6 | DMS (auto-convert) |
| SQL_INLINE_TABLE_VALUED_FUNCTION | 3 | Manual (PL/pgSQL) |
| SQL_SCALAR_FUNCTION | 1 | Manual (PL/pgSQL) |
| UNIQUE_CONSTRAINT | 1 | DMS (auto-convert) |

### A.2 MODS Database Summary (817 Objects)

| Object Type | Count | Migration Method |
|-------------|-------|------------------|
| USER_TABLE | 212 | DMS Full Load |
| PRIMARY_KEY_CONSTRAINT | 164 | DMS (auto-convert) |
| FOREIGN_KEY_CONSTRAINT | 162 | DMS (auto-convert) |
| SQL_STORED_PROCEDURE | 135 | Manual (PL/pgSQL) |
| VIEW | 106 | Manual (CREATE VIEW) |
| DEFAULT_CONSTRAINT | 30 | DMS (auto-convert) |
| SQL_INLINE_TABLE_VALUED_FUNCTION | 3 | Manual (PL/pgSQL) |
| SQL_TRIGGER | 2 | Manual (PL/pgSQL) |
| UNIQUE_CONSTRAINT | 2 | DMS (auto-convert) |
| SQL_SCALAR_FUNCTION | 1 | Manual (PL/pgSQL) |

### A.3 Combined Migration Summary

| Category | Total | DMS Auto | Manual Required |
|----------|-------|----------|-----------------|
| Tables | 369 | 369 | 0 |
| Primary Keys | 247 | 247 | 0 |
| Foreign Keys | 221 | 221 | 0 |
| Stored Procedures | 246 | 0 | 246 |
| Views | 182 | 0 | 182 |
| Functions | 8 | 0 | 8 |
| Triggers | 2 | 0 | 2 |
| Constraints | 39 | 39 | 0 |
| **TOTAL** | **1,314** | **876** | **438** |

### A.4 Migration Priority Matrix

**Phase 1: Critical Path (DMS Auto)**
- 369 Tables (full load)
- 247 Primary Keys
- 221 Foreign Keys
- 39 Default/Unique Constraints

**Phase 2: Manual Migration Required**
- 246 Stored Procedures (highest priority)
- 182 Views (medium priority)
- 8 Functions
- 2 Triggers

### A.5 Key Observations

1. **Stored Procedures**: Both databases have numerous `spMerge*` and `spCapacityReport*` procedures used for data aggregation and ETL-like operations. These will require careful PL/pgSQL conversion.

2. **Views**: Many views follow naming patterns like `vwCapacityReport*`, `vwSumo*`, `vwRave*`, `vwSysdig*` - likely used for reporting.

3. **System Tables**: Both databases contain `__MigrationLog`, `__SchemaSnapshot`, and `sysdiagrams` tables.

4. **Functions**: Minimal - only 4 inline table-valued functions and 2 scalar functions across both databases.

5. **Triggers**: Only 2 triggers in MODS database - relatively simple migration.

---

## Appendix B: Migration Workload Estimation

### B.1 Data Volume
- **MODSDW**: 40GB (157 tables)
- **MODS**: 120GB (212 tables)
- **Total**: 160GB across 369 tables

### B.2 Estimated Migration Timeline

| Phase | Duration | Notes |
|-------|----------|-------|
| Schema Assessment | 1 week | AWS SCT analysis |
| Schema Conversion | 2 weeks | Manual object work |
| DMS Setup | 1 week | Instance, endpoints, tasks |
| Full Load | 4-8 hours | Depending on network |
| CDC Replication | 1-2 weeks | Parallel with testing |
| Validation | 1 week | Data verification |
| Cutover | 30 minutes | Final switch |
| **Total** | **~6 weeks** | |

### B.3 Resource Requirements

| Component | Specification |
|-----------|---------------|
| DMS Instance | dms.r6g.4xlarge |
| PostgreSQL (MODS) | db.r6g.4xlarge, 500GB gp3 |
| PostgreSQL (MODSDW) | db.r6g.2xlarge, 200GB gp3 |
| Network | 500Mbps+ VPN/Direct Connect |

---

## Summary

This migration blueprint provides a complete, production-ready strategy for migrating your Mods (120GB) and Modsdw (40GB) SQL Server databases to Amazon RDS PostgreSQL. Based on the actual inventory from `OdsObjectInfo.xlsx`:

- **1,314 total objects** require migration
- **876 objects** will be automatically handled by DMS
- **438 objects** require manual PL/pgSQL conversion (246 procedures + 182 views + 8 functions + 2 triggers)

**Key Highlights:**

1. **Architecture**: Multi-AZ VPC with private subnets, DMS replication instance, and RDS PostgreSQL clusters
2. **Schema-First Approach**: Convert and validate all 438 manual objects before data migration
3. **Full Load + CDC**: Minimizes downtime to 30 minutes or less
4. **Comprehensive Validation**: Row counts, checksums, foreign keys, LOBs, and DMS validation
5. **Clear Cutover Process**: Step-by-step procedure with rollback plan

**Critical Success Factors:**
- Thorough pre-migration assessment
- Proper instance sizing
- Comprehensive testing before cutover
- Clear rollback plan
- Experienced team

---

*Document Version: 1.1*  
*Based on: OdsObjectInfo.xlsx (MODS: 817 objects, MODSDW: 497 objects)*  
*Created: AWS Migration Best Practices*  
*Last Updated: 2024*

---

Take a deep breath and work on this problem step-by-step.