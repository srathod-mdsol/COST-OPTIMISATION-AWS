import boto3
import json
import os
from decimal import Decimal
from botocore.exceptions import ClientError

# Import constants from central constants module
from core.constants import HOURS_PER_MONTH, HOURS_PER_DAY, HOURS_PER_YEAR

# Pricing JSON file paths - use environment variables or relative paths
# Default to pricing/ subdirectory in project root
import os
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_PRICING_DIR = os.path.join(_project_root, 'pricing')

EC2_PRICING_PATH = os.environ.get('EC2_PRICING_JSON_PATH', os.path.join(DEFAULT_PRICING_DIR, 'ec2_pricing.json'))
RDS_PRICING_PATH = os.environ.get('RDS_PRICING_JSON_PATH', os.path.join(DEFAULT_PRICING_DIR, 'rds_pricing.json'))

# Load pricing data into memory
_pricing_cache = {}

def load_pricing_data(service_code):
    """Load pricing data from JSON file."""
    if service_code in _pricing_cache:
        return _pricing_cache[service_code]
    
    if service_code == "AmazonEC2":
        path = EC2_PRICING_PATH
    elif service_code == "AmazonRDS":
        path = RDS_PRICING_PATH
    else:
        return None
    
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        _pricing_cache[service_code] = data
        return data
    except Exception as e:
        print(f"Warning: Could not load pricing data from {path}: {e}")
        return None


# ==========================================================
# 1️⃣ Base Session
# ==========================================================

def get_base_session(access_key, secret_key, region="us-east-1"):
    return boto3.Session(
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        region_name=region
    )


# ==========================================================
# 2️⃣ Assume Role
# ==========================================================

def assume_role_session(base_session, role_arn, session_name="PricingSession"):

    sts = base_session.client("sts")

    response = sts.assume_role(
        RoleArn=role_arn,
        RoleSessionName=session_name
    )

    creds = response["Credentials"]

    return boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
    )


# ==========================================================
# 3️⃣ Pricing Engine
# ==========================================================

class PricingEngine:

    def __init__(self, session, region):
        self.session = session
        self.region = region
        self.ec2 = session.client("ec2", region_name=region)
        self.rds = session.client("rds", region_name=region)
        self.pricing = session.client("pricing", region_name="us-east-1")

    # ------------------------------------------------------

    # Cache for discovered pricing attributes
    _pricing_attributes_cache = {}

    def get_pricing_attributes(self, service_code):
        """Query AWS Pricing API to get available attributes for a service."""
        if service_code in self._pricing_attributes_cache:
            return self._pricing_attributes_cache[service_code]
        
        try:
            response = self.pricing.describe_services(
                ServiceCode=service_code,
                MaxResults=100
            )
            attributes = {}
            for attr in response.get("Services", [{}])[0].get("AttributeNames", []):
                attributes[attr] = attr
            self._pricing_attributes_cache[service_code] = attributes
            return attributes
        except Exception as e:
            print(f"Warning: Could not get pricing attributes: {e}")
            return {}

    def region_name(self):
        # Try to get the location name from AWS Pricing API dynamically
        try:
            response = self.pricing.get_products(
                ServiceCode="AmazonEC2",
                Filters=[
                    {"Type": "TERM_MATCH", "Field": "regionCode", "Value": self.region}
                ],
                MaxResults=1
            )
            if response.get("PriceList"):
                price_item = json.loads(response["PriceList"][0])
                location = price_item.get("product", {}).get("attributes", {}).get("location")
                if location:
                    return location
        except:
            pass
        
        # Fallback to mapping if API fails
        mapping = {
            "us-east-1": "US East (N. Virginia)",
            "us-east-2": "US East (Ohio)",
            "us-west-1": "US West (N. California)",
            "us-west-2": "US West (Oregon)",
            "eu-west-1": "EU (Ireland)",
            "ap-south-1": "Asia Pacific (Mumbai)",
        }
        return mapping.get(self.region, self.region)

    def get_price(self, service_code, filters, fallback_filters=None):

        def parse_price(price_list, required_attrs=None):
            """Parse price from PriceList, finding the best matching non-zero price."""
            if not price_list:
                return None, None
            
            # If we have required attributes, try to find exact match first
            if required_attrs:
                for pl in price_list:
                    price_item = json.loads(pl)
                    attrs = price_item.get("product", {}).get("attributes", {})
                    
                    # Check if all required attributes match
                    match = True
                    for key, value in required_attrs.items():
                        if attrs.get(key) != value:
                            match = False
                            break
                    
                    if not match:
                        continue
                        
                    terms = price_item.get("terms", {}).get("OnDemand", {})
                    for term_id, term in terms.items():
                        price_dims = term.get("priceDimensions", {})
                        for pd_id, pd in price_dims.items():
                            price_per_unit = pd.get("pricePerUnit", {})
                            usd_price = price_per_unit.get("USD", "0")
                            unit = pd.get("unit", "Hrs")
                            
                            if usd_price == "0" or usd_price == "0.0" or float(usd_price) == 0:
                                continue
                            
                            return Decimal(usd_price), unit
            
            # Fallback: find first non-zero price
            for pl in price_list:
                price_item = json.loads(pl)
                terms = price_item.get("terms", {}).get("OnDemand", {})
                
                for term_id, term in terms.items():
                    price_dims = term.get("priceDimensions", {})
                    
                    for pd_id, pd in price_dims.items():
                        price_per_unit = pd.get("pricePerUnit", {})
                        usd_price = price_per_unit.get("USD", "0")
                        unit = pd.get("unit", "Hrs")
                        
                        # Skip zero prices
                        if usd_price == "0" or usd_price == "0.0" or float(usd_price) == 0:
                            continue
                        
                        return Decimal(usd_price), unit
            
            return None, None

    def get_price(self, service_code, filters, fallback_filters=None):
        """Get price from local JSON pricing data."""
        
        def find_price_in_data(pricing_data, filter_criteria):
            """Find price in pricing data matching the filter criteria."""
            if not pricing_data or 'products' not in pricing_data:
                return None, None
            
            products = pricing_data.get('products', {})
            terms = pricing_data.get('terms', {}).get('OnDemand', {})
            
            best_match = None
            best_match_count = 0
            
            for sku, product in products.items():
                attrs = product.get('attributes', {})
                
                # Count how many filter criteria match
                match_count = 0
                for fc in filter_criteria:
                    field = fc.get('Field')
                    value = fc.get('Value')
                    
                    # Map filter field to attribute key
                    attr_key = field
                    if field == 'location':
                        attr_key = 'location'
                    
                    if attrs.get(attr_key) == value:
                        match_count += 1
                
                # Track best match
                if match_count > best_match_count:
                    # Get price for this product
                    product_terms = terms.get(sku, {})
                    for term_id, term in product_terms.items():
                        price_dims = term.get('priceDimensions', {})
                        for pd_id, pd in price_dims.items():
                            price_per_unit = pd.get('pricePerUnit', {})
                            usd_price = price_per_unit.get('USD', '0')
                            unit = pd.get('unit', 'Hrs')
                            
                            if float(usd_price) > 0:
                                best_match = (Decimal(usd_price), unit)
                                best_match_count = match_count
            
            return best_match

        # Try with primary filters
        pricing_data = load_pricing_data(service_code)
        if pricing_data:
            price, unit = find_price_in_data(pricing_data, filters)
            if price is not None:
                return price, unit
        
        # Try with fallback filters
        if fallback_filters and pricing_data:
            price, unit = find_price_in_data(pricing_data, fallback_filters)
            if price is not None:
                return price, unit
        
        raise Exception(f"No pricing found for {filters}")

    def convert_periods(self, hourly_price):
        # Use Decimal for precise currency calculations
        hourly_decimal = Decimal(str(hourly_price))
        return {
            "hourly": float(hourly_decimal),
            "daily": float(hourly_decimal * HOURS_PER_DAY),
            "monthly": float(hourly_decimal * HOURS_PER_MONTH),
            "yearly": float(hourly_decimal * HOURS_PER_YEAR),
        }

    # ======================================================
    # EC2
    # ======================================================

    def calculate_first_ec2(self):

        paginator = self.ec2.get_paginator("describe_instances")

        for page in paginator.paginate():
            for reservation in page["Reservations"]:
                for instance in reservation["Instances"]:

                    instance_id = instance["InstanceId"]
                    print(f"EC2 Found: {instance_id}")

                    return self._calculate_ec2(instance)

        return None

    def _calculate_ec2(self, instance):

        instance_type = instance["InstanceType"]
        instance_id = instance["InstanceId"]
        tenancy = instance["Placement"]["Tenancy"]
        platform = instance.get("Platform", "Linux")
        os = "Windows" if platform.lower() == "windows" else "Linux"
        state = instance["State"]["Name"]
        az = instance["Placement"]["AvailabilityZone"]

        # Get volume info
        volumes = []
        total_storage_gb = 0
        for block in instance.get("BlockDeviceMappings", []):
            if "Ebs" not in block:
                continue
            vol_id = block["Ebs"]["VolumeId"]
            volume = self.ec2.describe_volumes(VolumeIds=[vol_id])["Volumes"][0]
            vol_size = volume["Size"]
            vol_type = volume["VolumeType"]
            total_storage_gb += vol_size
            volumes.append({"id": vol_id, "type": vol_type, "size_gb": vol_size})

        # Build filters dynamically - only use instance attributes
        primary_filters = [
            {"Type": "TERM_MATCH", "Field": "instanceType", "Value": instance_type},
            {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
            {"Type": "TERM_MATCH", "Field": "operatingSystem", "Value": os},
        ]
        
        # Only add tenancy if it's available and not default
        if tenancy and tenancy != "default":
            primary_filters.append({"Type": "TERM_MATCH", "Field": "tenancy", "Value": tenancy})

        # Fallback filters with minimal restrictions
        fallback_filters = [
            {"Type": "TERM_MATCH", "Field": "instanceType", "Value": instance_type},
            {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
        ]

        compute_price, _ = self.get_price(
            "AmazonEC2",
            primary_filters,
            fallback_filters,
        )

        total_hourly = compute_price

        # EBS volumes
        for block in instance.get("BlockDeviceMappings", []):
            if "Ebs" not in block:
                continue

            vol_id = block["Ebs"]["VolumeId"]
            volume = self.ec2.describe_volumes(VolumeIds=[vol_id])["Volumes"][0]

            size = Decimal(volume["Size"])
            vol_type = volume["VolumeType"]
            iops = Decimal(volume.get("Iops", 0))

            # Primary filters for storage
            storage_primary = [
                {"Type": "TERM_MATCH", "Field": "volumeType", "Value": vol_type},
                {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
            ]

            # Fallback filters - try without volumeType first
            storage_fallback = [
                {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
            ]

            try:
                storage_price, storage_unit = self.get_price(
                    "AmazonEC2",
                    storage_primary,
                    storage_fallback,
                )
                # Convert to hourly if needed (GB-Mo to hourly)
                if storage_unit and "Mo" in storage_unit:
                    monthly_storage = storage_price * size
                    total_hourly += monthly_storage / HOURS_PER_MONTH
                else:
                    monthly_storage = storage_price * size
                    total_hourly += monthly_storage / HOURS_PER_MONTH
            except Exception as e:
                print(f"Warning: Could not get storage price for {vol_type}: {e}")

            # Provisioned IOPS - try to find IOPS pricing dynamically
            if vol_type in ["io1", "io2"] and iops > 0:
                try:
                    # Try to find any IOPS-related pricing
                    iops_price, _ = self.get_price(
                        "AmazonEC2",
                        [
                            {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
                        ],
                    )
                    if iops_price:
                        monthly_iops = iops_price * iops
                        total_hourly += monthly_iops / HOURS_PER_MONTH
                except Exception as e:
                    print(f"Warning: Could not get IOPS price: {e}")

        pricing = self.convert_periods(total_hourly)
        
        return {
            "instance_id": instance_id,
            "instance_type": instance_type,
            "operating_system": os,
            "tenancy": tenancy,
            "state": state,
            "availability_zone": az,
            "volumes": volumes,
            "total_storage_gb": total_storage_gb,
            "pricing": pricing
        }

    # ======================================================
    # RDS
    # ======================================================

    def calculate_first_rds(self):

        paginator = self.rds.get_paginator("describe_db_instances")

        for page in paginator.paginate():
            for db in page["DBInstances"]:

                db_id = db["DBInstanceIdentifier"]
                print(f"RDS Found: {db_id}")

                return self._calculate_rds(db)

        return None

    def _calculate_rds(self, db):

        instance_class = db["DBInstanceClass"]
        db_id = db["DBInstanceIdentifier"]
        engine = db["Engine"]
        engine_version = db.get("EngineVersion", "N/A")
        multi_az = db["MultiAZ"]
        storage_type = db["StorageType"]
        allocated_storage = Decimal(db["AllocatedStorage"])
        iops = Decimal(db.get("Iops", 0))
        db_status = db["DBInstanceStatus"]
        az = db.get("AvailabilityZone", "N/A")

        deployment = "Multi-AZ" if multi_az else "Single-AZ"

        # Try to get pricing with original engine name first, then try variations
        engine_variations = [engine, engine.capitalize(), engine.upper(), engine.lower()]
        
        # Primary filters with all details - try each engine variation
        primary_filters = None
        for eng in engine_variations:
            primary_filters = [
                {"Type": "TERM_MATCH", "Field": "instanceType", "Value": instance_class},
                {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
                {"Type": "TERM_MATCH", "Field": "databaseEngine", "Value": eng},
                {"Type": "TERM_MATCH", "Field": "deploymentOption", "Value": deployment},
            ]
            try:
                test_price, _ = self.get_price("AmazonRDS", primary_filters, None)
                if test_price:
                    break
            except:
                continue

        # Fallback filters - include database engine to get correct pricing
        fallback_filters = [
            {"Type": "TERM_MATCH", "Field": "instanceType", "Value": instance_class},
            {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
        ]

        try:
            compute_price, _ = self.get_price(
                "AmazonRDS",
                primary_filters,
                fallback_filters,
            )
        except Exception as e:
            print(f"Warning: Could not get RDS compute price: {e}")
            compute_price = Decimal("0")

        total_hourly = compute_price

        # Storage pricing - try different volume type variations (only from API)
        vol_type_variations = [storage_type, storage_type.upper(), storage_type.lower(), 
                              storage_type.capitalize()]
        
        storage_primary = None
        for vt in vol_type_variations:
            storage_primary = [
                {"Type": "TERM_MATCH", "Field": "volumeType", "Value": vt},
                {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
                {"Type": "TERM_MATCH", "Field": "deploymentOption", "Value": deployment},
            ]
            try:
                test_price, _ = self.get_price("AmazonRDS", storage_primary, None)
                if test_price:
                    break
            except:
                continue
        
        storage_fallback = [
            {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
            {"Type": "TERM_MATCH", "Field": "deploymentOption", "Value": deployment},
        ]

        try:
            storage_price, storage_unit = self.get_price(
                "AmazonRDS",
                storage_primary,
                storage_fallback,
            )
            # RDS storage is priced per GB-Mo, convert to hourly
            monthly_storage = storage_price * allocated_storage
            total_hourly += monthly_storage / HOURS_PER_MONTH
        except Exception as e:
            print(f"Warning: Could not get RDS storage price: {e}")

        # Provisioned IOPS - try to find IOPS pricing dynamically
        if storage_type in ["io1", "io2"] and iops > 0:
            try:
                iops_price, _ = self.get_price(
                    "AmazonRDS",
                    [
                        {"Type": "TERM_MATCH", "Field": "location", "Value": self.region_name()},
                    ],
                )
                if iops_price:
                    monthly_iops = iops_price * iops
                    total_hourly += monthly_iops / HOURS_PER_MONTH
            except Exception as e:
                print(f"Warning: Could not get RDS IOPS price: {e}")

        pricing = self.convert_periods(total_hourly)
        
        return {
            "db_instance_id": db_id,
            "instance_class": instance_class,
            "engine": engine,
            "engine_version": engine_version,
            "deployment": deployment,
            "storage_type": storage_type,
            "allocated_storage_gb": int(allocated_storage),
            "iops": int(iops) if iops > 0 else None,
            "status": db_status,
            "availability_zone": az,
            "pricing": pricing
        }


# ==========================================================
# 4️⃣ MAIN
# ==========================================================

if __name__ == "__main__":

    # Load credentials from environment variables for security
    import os
    ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID', '')
    SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    
    if not ACCESS_KEY or not SECRET_KEY:
        print("ERROR: AWS credentials not found. Please set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables.")
        exit(1)
    
    ROLE_ARN = os.environ.get('AWS_ROLE_ARN', 'arn:aws:iam::767904627276:role/falcon_readonly')
    REGION = os.environ.get('AWS_REGION', 'us-east-1')

    base_session = get_base_session(ACCESS_KEY, SECRET_KEY)
    account_session = assume_role_session(base_session, ROLE_ARN)

    engine = PricingEngine(account_session, REGION)

    ec2_result = engine.calculate_first_ec2()
    rds_result = engine.calculate_first_rds()

    # Print EC2 Details
    print("\n" + "="*60)
    print("EC2 INSTANCE DETAILS")
    print("="*60)
    if ec2_result:
        print(f"Instance ID:        {ec2_result['instance_id']}")
        print(f"Instance Type:      {ec2_result['instance_type']}")
        print(f"Operating System:   {ec2_result['operating_system']}")
        print(f"Tenancy:            {ec2_result['tenancy']}")
        print(f"State:              {ec2_result['state']}")
        print(f"Availability Zone:  {ec2_result['availability_zone']}")
        print(f"Total Storage:     {ec2_result['total_storage_gb']} GB")
        if ec2_result['volumes']:
            print("Volumes:")
            for vol in ec2_result['volumes']:
                print(f"  - {vol['id']}: {vol['type']}, {vol['size_gb']} GB")
        print("\nPricing:")
        print(f"  Hourly:  ${ec2_result['pricing']['hourly']:.4f}")
        print(f"  Daily:   ${ec2_result['pricing']['daily']:.2f}")
        print(f"  Monthly: ${ec2_result['pricing']['monthly']:.2f}")
        print(f"  Yearly:  ${ec2_result['pricing']['yearly']:.2f}")

    # Print RDS Details
    print("\n" + "="*60)
    print("RDS DATABASE DETAILS")
    print("="*60)
    if rds_result:
        print(f"DB Instance ID:    {rds_result['db_instance_id']}")
        print(f"Instance Class:    {rds_result['instance_class']}")
        print(f"Database Engine:   {rds_result['engine']}")
        print(f"Engine Version:    {rds_result['engine_version']}")
        print(f"Deployment:        {rds_result['deployment']}")
        print(f"Storage Type:      {rds_result['storage_type']}")
        print(f"Allocated Storage: {rds_result['allocated_storage_gb']} GB")
        if rds_result['iops']:
            print(f"IOPS:              {rds_result['iops']}")
        print(f"Status:            {rds_result['status']}")
        print(f"Availability Zone: {rds_result['availability_zone']}")
        print("\nPricing:")
        print(f"  Hourly:  ${rds_result['pricing']['hourly']:.4f}")
        print(f"  Daily:   ${rds_result['pricing']['daily']:.2f}")
        print(f"  Monthly: ${rds_result['pricing']['monthly']:.2f}")
        print(f"  Yearly:  ${rds_result['pricing']['yearly']:.2f}")

    print("\n" + "="*60)